window.addEventListener('load', () => {
const fnRequestCreateClientCore = () => {
try {
chrome.runtime.sendMessage({ cmd: 'CreateClientCorePage' }, () => {
if (chrome.runtime.lastError) {
console.log(`Failed sendMessage() : ${chrome.runtime.lastError.message}`);
}
else {
setTimeout(() => { window.close(); }, 500);
}
});
}
catch (err) {
console.log(`${err?.message || err || '' }`);
setTimeout(() => { window.close(); });
}
};
try {
let target = '';
const tempIndex = document.location.href.indexOf('?');
if (tempIndex > 0) {
const urlArgs = document.location.href.substring(tempIndex + 1).split('&');
urlArgs.forEach((arg) => {
if (arg.startsWith('target='))  target = arg.substring(7);
});
}
if (target === 'core') {
fnRequestCreateClientCore();
}
else if (target === 'waitReboot') {
document.getElementById('pMessage').innerHTML = 'Rebooting Now.';
document.getElementById('divMessage').style.display = 'block';
setTimeout(() => { window.close(); }, 2900);
}
else if (target === 'reload') {
document.getElementById('pMessage').innerHTML = 'Rebooting Now.';
document.getElementById('divMessage').style.display = 'block';
setTimeout(() => {
chrome.runtime.reload();
window.close();
});
}
else if (target === 'waitPolicy') {
document.getElementById('pMessage').innerHTML = 'Wait Policy.';
document.getElementById('divMessage').style.display = 'block';
setTimeout(() => { window.close(); }, 3400);
}
else {
throw new Error('target parameter error');
}
}
catch (err) {
console.log(`${err?.message || err || '' }`);
setTimeout(() => { window.close(); }, 10);
}
});
