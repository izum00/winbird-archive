'use strict';
const JSFILEVER_popup = '3.1.3.1001';
const internalStateClassNames = ['internalStateBlack', 'internalStateYellow', 'internalStateRed', 'internalStateGreen' ];
let thinningOutUpdateStatusDisplayTimerId = TIMER_ID_NONE;
let requestedReloadClickTimeStamp = 0;
let isRequestedReloadClient = false;
let isUnusableClient = false;
const putLog = (message, level=LogLevels.DEBUG) => {
LogManager.putLog(`【popup】${message}`, level);
};
const createBroadcastChannelListener = () => {
var bcReceiver = new BroadcastChannel(BcNames.POPUP_PAGE);
bcReceiver.onmessage = (ev) => {
if (! isRequestedReloadClient) {
if (ev?.data?.cmd === 'ChangedClientStatus') {
if (thinningOutUpdateStatusDisplayTimerId === TIMER_ID_NONE) {
thinningOutUpdateStatusDisplayTimerId = setTimeout(() => {
thinningOutUpdateStatusDisplayTimerId = TIMER_ID_NONE;
updateStatusDisplayContentsAsync(false).then(()=>{});
}, 400);
}
return;
}
if (ev?.data?.cmd === 'ChangedAvailableTime') {
updateAvailableTimeAsync().then(()=>{});
return;
}
}
};
bcReceiver.onmessageerror = (ev) => {
const errorMsg = 'ERROR - BroadcastChannel.onmessage()' + ((ev) ? ` : ${ev.message || ev}` : '');
putLog(errorMsg, LogLevels.FATAL);
};
};
const updateStatusDisplayContentsAsync = (needsRetry) => {
const fnGetSigLibInfoAsync = (needsRetry) => {
return new Promise(async (resolve) => {
let result = null;
const onClickedCheckEscape = (ev) => {
if ((! result) && (! ev.shiftKey) && (ev.ctrlKey) && (ev.altKey))  result = { escape: true };
};
if (needsRetry) {
document.body.addEventListener('click', onClickedCheckEscape);
}
do {
try {
const clientCoreTabId = await ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true);
if (clientCoreTabId === TAB_ID_NONE) {
throw "Can't get ClientCoreTabId";
}
else {
result = await ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, { cmd: 'GetSigLibInfo' }, true);
}
}
catch (err) {
const errorMsg = 'ERROR - updateStatusDisplayContentsAsync() - fnGetSigLibInfoAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
if (needsRetry) {
await new Promise(resolve => setTimeout(resolve, 750));
if (isRequestedReloadClient)  await new Promise(resolve => setTimeout(resolve, 10000));
}
}
} while ((! result) && (needsRetry));
document.body.removeEventListener('click', onClickedCheckEscape);
resolve(result || {});
});
};
return new Promise((resolve) => {
let clientState;
let sigLibInfo;
ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, { cmd: 'GetClientState' })
.then((msgResponse) => {
if (msgResponse === null) {
putLog('ERROR - updateStatusDisplayContentsAsync() : Failed GetClientState send.', LogLevels.INFO);
}
clientState = msgResponse || {};
if (clientState.disabled) {
isUnusableClient = true;
return {};
}
document.getElementById('labelCbtMode').style.display = (clientState.isCbtMode) ? 'block' : 'none';
if (isUnusableClient !== clientState.unusable) {
isUnusableClient = clientState.unusable;
updateAvailableTimeAsync().then(()=>{});
}
if (clientState.unusable) {
return {};
}
return fnGetSigLibInfoAsync(needsRetry);
})
.then((result) => {
if (result?.escape === true) {
document.getElementById('labelClientState').innerHTML = Utils.getLocaleMessage('msg_unknownStatus');
resolve(true);
return;
}
sigLibInfo = result;
const sigLibInitializeState = (sigLibInfo.sigLibInitialize || 0) & 0x3;
const onlineNotificationState = (sigLibInfo.onlineNotification || 0) & 0x3;
const ctrlConnectedState = (sigLibInfo.ctrlConnect || 0) & 0x3;
const labelInternalState1 = document.getElementById('labelInternalState1');
labelInternalState1.className = internalStateClassNames[sigLibInitializeState];
const labelInternalState2 = document.getElementById('labelInternalState2');
labelInternalState2.className = internalStateClassNames[onlineNotificationState];
const labelInternalState3 = document.getElementById('labelInternalState3');
labelInternalState3.innerHTML = (ctrlConnectedState === 0) ? '□' : '■';
labelInternalState3.className = (ctrlConnectedState > 1) ? 'internalStatePlum' : 'internalStateGreen';
const labelClientState = document.getElementById('labelClientState');
labelClientState.innerHTML = '';
let enabledClient = false;
if (clientState.disabled) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_disabledClient');
}
else if (clientState.unusable) {
if (clientState.unusableReason === 1) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_notAvailableDupLogin');
}
else {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_notAvailable');
}
}
else {
enabledClient = true;
if (sigLibInfo.isWaitingOnline) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_pleaseCheckNetwork');
}
else if (! clientState.isVerifiedSigConfig) {
labelClientState.innerHTML = '';
}
else if (clientState.isAvailableTime) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_enabledClient');
}
else {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_notAvailableTime');
}
}
if (clientState.isNightLimited) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_limitedOnNightTimeUse') + '<br>' + labelClientState.innerHTML;
}
const accountContainer = document.getElementById('divAccountContainer');
for (let child = accountContainer.lastChild; child !== null; child = accountContainer.lastChild) {
accountContainer.removeChild(child);
}
if (clientState.systemId) {
const pSystemId = document.createElement('p');
pSystemId.className = 'accountInfo';
pSystemId.innerHTML = Utils.escapeHtmlStr(` Sys-ID： ${clientState.systemId}`);
accountContainer.appendChild(pSystemId);
}
const pEmail = document.createElement('p');
pEmail.className = 'accountInfo';
pEmail.innerHTML = Utils.escapeHtmlStr(` E-Mail： ${(clientState.email) ? clientState.email : ''}`);
accountContainer.appendChild(pEmail);
document.getElementById('fieldsetAccount').style.display = 'block';
const imgOptions = document.getElementById('imgOptions');
imgOptions.src = (enabledClient) ? './assets/icon48.png' : './assets/icon48night.png';
if (clientState.isJoinedClasswork) {
if ((sigLibInitializeState === 3) && (onlineNotificationState === 3)) {
if (ctrlConnectedState === 0) {
imgOptions.style.backgroundColor = 'transparent';
imgOptions.classList.add('blinkImgOptions');
}
else {
imgOptions.classList.remove('blinkImgOptions');
imgOptions.style.backgroundColor = '#f8f8f8a0';
}
}
else {
imgOptions.classList.remove('blinkImgOptions');
imgOptions.style.backgroundColor = '#e00000c0';
putLog(`授業参加状態とSigLib状態の矛盾により状態異常と判断しました.  sigLibInitialize=${sigLibInitializeState}  onlineNotification=${onlineNotificationState}`, LogLevels.INFO);
labelClientState.innerHTML = Utils.getLocaleMessage((clientState.osType === OsTypes.WINDOWS) ? 'msg_abnormalStatus2' : 'msg_abnormalStatus1');
}
}
else {
imgOptions.classList.remove('blinkImgOptions');
imgOptions.style.backgroundColor = 'transparent';
}
if ((ctrlConnectedState === 1) || (! clientState.isSupportedBrowser) || (! clientState.isAvailableTime) ||
(clientState.disabled) || (clientState.isCbtMode) ||
((clientState.unusable) && (clientState.unusableReason === 1))) {
document.getElementById("buttonJoin").disabled = true;
}
else {
document.getElementById("buttonJoin").disabled = false;
}
resolve(true);
});
});
};
const updateAvailableTimeAsync = () => {
const fnCleanupAvailableTimeContainer = () => {
const container = document.getElementById('divAvailableTimeContainer');
for (let child = container.lastChild; child !== null; child = container.lastChild) {
container.removeChild(child);
}
return container;
};
return new Promise((resolve) => {
ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true)
.then((clientCoreTabId) => {
if ((clientCoreTabId !== TAB_ID_NONE) && (! isUnusableClient)) {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'GetAvailableTimeInfo'
}, true);
}
return { enabled: false };
})
.then((msgResponse) => {
const availableTimeContainer = fnCleanupAvailableTimeContainer();
if ((msgResponse) && (msgResponse.enabled)) {
if (msgResponse.availableTimes.length === 0) {
const pInfo = document.createElement('p');
const msg = Utils.getLocaleMessage('msg_nothing');
pInfo.className = 'availableTimeMessage';
pInfo.innerHTML = Utils.escapeHtmlStr(msg);
availableTimeContainer.appendChild(pInfo);
}
else {
for (const data of msgResponse.availableTimes) {
const msg = `${Utils.getLocaleMessage('msg_dayOfWeek_' + data.dayOfWeek)} :  ${data.timeRangeText}`;
const pInfo = document.createElement('p');
pInfo.className = 'availableTimeMessage';
pInfo.innerHTML = Utils.escapeHtmlStr(msg);
availableTimeContainer.appendChild(pInfo);
}
}
document.getElementById('fieldsetAvailableTime').style.display = 'inline';
}
else {
document.getElementById('fieldsetAvailableTime').style.display = 'none';
}
resolve();
})
.catch((err) => {
const errorMsg = 'ERROR - updateAvailableTime()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
fnCleanupAvailableTimeContainer();
resolve();
});
});
};
const reloadSelfExtension = (isShowToPleaseWait, caller, cause=null) => {
const fnReloadExtension = () => {
let kickerWindowId = WINDOW_ID_NONE;
const logMsg = `【popup】${(cause) ? `${cause}により、` : ''}クライアント機能をリロードします. ${(caller) ? `(${caller})` : ''}`;
LogManager.putLogAsync(logMsg, LogLevels.FATAL)
.then(() => {
return ApiWrappers.readSessionStorageValueAsync({ BrowserMajorVersion: -1 });
})
.then((majorVersion) => {
if (majorVersion >= 130) {
return null;
}
return ApiWrappers.createWindowAsync({
url: `${chrome.runtime.getURL(PageHtmlNames.CLIENT_KICKER)}?target=waitReboot`,
focused : false,
type: 'popup', state: 'normal',
left: 0, top: 0, width: 140, height: 100
});
})
.then((wnd) => {
if (wnd) {
kickerWindowId = wnd.id;
}
return CountManager.exchangeAsync('startClientAsync', 2);
})
.then(() => {
return CountManager.exchangeAsync('checkExtensionPolicyAsync', 2);
})
.then(() => {
if (kickerWindowId !== WINDOW_ID_NONE) {
return ApiWrappers.updateWindowAsync(kickerWindowId, { state: 'minimized' });
}
})
.then(() => {
return CountManager.readAsync(null);
})
.catch((err) => {
const errorMsg = '【popup】ERROR - reloadSelfExtension()' + ((err) ? ` ${err.message || err}` : '');
return LogManager.putLogAsync(errorMsg, LogLevels.INFO);
})
.then(() => {
return LogManager.putLogAsync('【popup】★★★ chrome.runtime.reload() 呼び出し.', LogLevels.INFO);
})
.finally(() => {
setTimeout(() => { chrome.runtime.reload(); });
});
};
isRequestedReloadClient = true;
document.getElementById('labelInternalState1').className = 'internalStateHideen';
document.getElementById('labelInternalState2').className = 'internalStateHideen';
document.getElementById('labelInternalState3').className = 'internalStateHideen';
document.getElementById('fieldsetAccount').style.display = 'none';
document.getElementById('fieldsetAvailableTime').style.display = 'none';
document.getElementById("buttonJoin").disabled = true;
document.getElementById("buttonClosePage").disabled = true;
if (isShowToPleaseWait) {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_pleaseWait');
}
else {
labelClientState.innerHTML = Utils.getLocaleMessage('msg_rebootingClient');
}
setTimeout(fnReloadExtension, 5000);
CountManager.deleteAsync('startClientAsync')
.then(() => {
return ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, {
cmd: 'ReloadSelfExtension',
caller: caller,
cause: `【popup】${(cause || '')}`
}, true);
})
.catch(() => {
fnReloadExtension();
});
};
const initializeAsync = async () => {
const isProhibitClient = (true === await ApiWrappers.readLocalStorageValueAsync({ ProhibitClient: false }));
const isCheckingSignedUserEmail = (true === await ApiWrappers.readSessionStorageValueAsync({ IsCheckingSignedUserEmail: false }));
if (isCheckingSignedUserEmail) {
document.getElementById('labelClientState').innerHTML = Utils.getLocaleMessage('msg_pleaseSyncAccount');
}
else {
document.getElementById('labelClientState').innerHTML = Utils.getLocaleMessage('msg_checkingStatus');
if (! isProhibitClient) {
const now = Date.now();
let isInitialized = false;
let isEscape = false
const onClickedCheckEscape = (ev) => {
if ((! isEscape) && (! ev.shiftKey) && (ev.ctrlKey) && (ev.altKey))  isEscape = true;
};
let retryCount;
for (retryCount = 0; ((retryCount < 20) && (! isInitialized) && (! isEscape)); retryCount++) {
isInitialized = await ApiWrappers.readSessionStorageValueAsync({ IsInitialized: false });
if (! isInitialized) {
putLog(`初期化済み確認失敗  retryCount=${retryCount}`);
if (retryCount === 0) {
document.body.addEventListener('click', onClickedCheckEscape);
}
await new Promise(resolve => setTimeout(resolve, 250));
}
}
document.body.removeEventListener('click', onClickedCheckEscape);
if (! isInitialized) {
if (! isEscape) {
reloadSelfExtension(false, '9A', '未初期化状態検出');
return;
}
putLog('初期化済み確認処理をエスケープしました.', LogLevels.INFO);
}
else if (retryCount <= 1) {
const storage = await ApiWrappers.readSessionStorageDataAsync({
LastClickedPopupIconTime: 0,
IsActivedMessenger: false,
ClientCoreTabId: TAB_ID_NONE,
});
if (! storage) {
window.close();
return;
}
const elapsedTime = (storage.LastClickedPopupIconTime !== 0) ? Math.trunc(now - storage.LastClickedPopupIconTime) : -1;
await ApiWrappers.saveSessionStorageDataAsync({ LastClickedPopupIconTime: Date.now() });
if ((storage.IsActivedMessenger) && (storage.ClientCoreTabId !== TAB_ID_NONE)) {
if ((elapsedTime < 0) || (elapsedTime > 2700)) {
ApiWrappers.sendInternalMsgAsync(true, storage.ClientCoreTabId, { cmd: 'OpenMessengerPage', delay: 400, isReopen: true });
window.close();
return;
}
}
await ApiWrappers.removeSessionStorageDataAsync('LastClickedPopupIconTime');
}
}
let timeoutTimerId = setTimeout(reloadSelfExtension, 4800, false, '9B', 'クライアント状態取得異常');
let result = await updateStatusDisplayContentsAsync(true);
clearTimeout(timeoutTimerId);
if (! result) {
reloadSelfExtension(false, '9C', 'クライアント状態取得異常');
return;
}
}
if (! isProhibitClient) {
await updateAvailableTimeAsync();
createBroadcastChannelListener();
}
document.getElementById('buttonOptions').addEventListener('click', (ev) => {
requestedReloadClickTimeStamp = 0;
if ((ev.shiftKey) && (! ev.ctrlKey) && (! ev.altKey)) {
ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, {
cmd: 'CreateOptionsPage',
left: window.screen.availLeft,
top: window.screen.availTop,
width: Math.trunc(window.screen.availWidth * 0.75),
height: window.screen.availHeight
}, true)
.then((msgResponse) => {
if (msgResponse?.accepted === true) {
window.close();
}
})
.catch((err) => {
const errorMsg = 'ERROR - Failed CreateOptionsPage send.' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
});
}
});
};
window.addEventListener('DOMContentLoaded', () => {
ApiWrappers.readSessionStorageDataAsync({
IsEnabledClient: false,
InitializeTime: Date.now(),
}, true)
.then((storage) => {
if (storage.IsEnabledClient) {
const elapsed = Date.now() - storage.InitializeTime;
if ((elapsed > -1000) && (elapsed < 4500)) {
window.close();
}
}
});
});
window.addEventListener('load', async () => {
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verMessenger = (typeof JSFILEVER_popup === 'string') ? JSFILEVER_popup : 'Undefined';
if (verMessenger === currentVersion) {
logMsg = `★Program file check <9> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <9> -- [currentVer=${currentVersion}]  popup.js=${verMessenger}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【popup】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
const fnAdjustWindowSize = (tryCount=0) => {
tryCount++;
if (window.outerWidth < Math.trunc(window.innerWidth * 0.25)) {
if (tryCount < 15) {
setTimeout((count) => { fnAdjustWindowSize(count); }, 100, tryCount);
}
else {
putLog(`ウィンドウサイズの調整断念.  innerWidth=${window.innerWidth}  outerWidth=${window.outerWidth}`, LogLevels.INFO);
document.getElementById('divMain').style.visibility = 'visible';
}
}
else {
putLog(`TryCount=${tryCount}  innerWidth=${window.innerWidth}  outerWidth=${window.outerWidth}`);
if ('zoom' in document.body.style) {
const adjustedValue = (window.innerWidth === window.outerWidth) ? 0 : 14;
document.body.style.zoom = (window.innerWidth / (window.outerWidth - adjustedValue));
putLog(`ocument.body.style.zoom=${document.body.style.zoom}`);
}
document.getElementById('divMain').style.visibility = 'visible';
}
};
try {
let programVersionCheckedFlags = await ApiWrappers.readLocalStorageValueAsync({ ProgramVersionCheckedFlags: 0 }, true);
if (0 === (programVersionCheckedFlags & 0x100)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x100) | 0x100;
await ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags });
if (! Utils.isSkipCheckProgramFileVersion()) {
await fnCheckProgramFileVersionAsync();
}
}
document.title = Utils.getLocaleMessage('ext_title');
document.oncontextmenu = () => { return false; };
document.body.oncontextmenu = 'return false;';
document.getElementById('divMain').style.visibility = 'hidden';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) {
document.getElementById('labelVersion').innerHTML = Utils.escapeHtmlStr(`Ver. ${manifestData.version}`);
}
document.getElementById('legendClientState').innerHTML = Utils.getLocaleMessage('ext_title');
document.getElementById('legendAccountInfo').innerHTML = Utils.getLocaleMessage('msg_accountInfo');
document.getElementById('legendAvailableTime').innerHTML = Utils.getLocaleMessage('msg_availableTimeList');
const buttonJoin = document.getElementById('buttonJoin');
buttonJoin.innerHTML = Utils.getLocaleMessage('msg_joinClasswork');
buttonJoin.addEventListener('click', (ev) => {
document.getElementById("buttonJoin").disabled = true;
document.getElementById("buttonClosePage").disabled = true;
reloadSelfExtension(true, '9D', '[参加する]によるリロード要求');
});
const buttonClosePage = document.getElementById('buttonClosePage');
buttonClosePage.innerHTML = Utils.getLocaleMessage('msg_close');
buttonClosePage.addEventListener('click', (ev) => {
const disabledButtonJoin = (document.getElementById("buttonJoin")?.disabled === true);
if ((disabledButtonJoin) && (ev.shiftKey) && (ev.ctrlKey) && (! ev.altKey)) {
if ((requestedReloadClickTimeStamp > 0) && ((ev.timeStamp - requestedReloadClickTimeStamp) <= 1000)) {
document.getElementById("buttonJoin").disabled = true;
document.getElementById("buttonClosePage").disabled = true;
reloadSelfExtension(false, '9E', '強制リロード要求');
}
else {
requestedReloadClickTimeStamp = ev.timeStamp;
}
}
else {
window.close();
}
});
if (true === await ApiWrappers.readLocalStorageValueAsync({ NotSupportedBrowserVersion: false })) {
const imgOptions = document.getElementById('imgOptions');
imgOptions.src = './assets/icon48night.png';
document.getElementById('labelClientState').innerHTML = Utils.getLocaleMessage('msg_unsupportedBrowserVersion');
}
else {
initializeAsync().then(()=>{});
}
setTimeout(() => { fnAdjustWindowSize(0); }, 100);
}
catch (err) {
const errorMsg = '【popup】WINDOW - load()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
});
window.addEventListener('error', (ev) => {
const errorMsg = '【popup】WINDOW ERROR (Popup) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
