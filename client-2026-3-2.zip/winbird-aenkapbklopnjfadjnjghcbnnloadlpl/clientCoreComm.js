'use strict';
const JSFILEVER_clientCoreComm = '3.1.3.1001';
import * as WbSigLib from './library/WbSigLib.js';
import { WbBTGamen } from './library/WbBTGamen.js';
export class ClientCoreComm {
static getJsFileVersion() {
return (typeof JSFILEVER_clientCoreComm === 'string') ? JSFILEVER_clientCoreComm : 'Undefined';
}
constructor(cData, cAux, timer) {
this._cData = cData;
this._cAux = cAux;
this._timer = timer;
this._failedConnectSigLibCounter = 0;
this._domainSystemId = null;
this._signalingType = 0;
this._lastSigLibLogMessage = null;
this._isBusyStartClassProsess = false;
this._receivedCommandCallbackMethod = () => {};
this._disconnectCtrlAsyncCallbackMethod = () => Promise.resolve(false);
this._putLog = this._putLog.bind(this);
this._makeLogStringCommMessage = this._makeLogStringCommMessage.bind(this);
this._extractSigConfig = this._extractSigConfig.bind(this);
this._disableClient = this._disableClient.bind(this);
this._stopClient = this._stopClient.bind(this);
this._sendLatestClientState = this._sendLatestClientState.bind(this);
this._stopGamenJunshi = this._stopGamenJunshi.bind(this);
this._startWatchAvailableTime = this._startWatchAvailableTime.bind(this);
this._stopWatchAvailableTime = this._stopWatchAvailableTime.bind(this);
this._startWatchNightLimit = this._startWatchNightLimit.bind(this);
this._stopWatchNightLimit = this._stopWatchNightLimit.bind(this);
this._leaveClasswork= this._leaveClasswork.bind(this);
this._reloadClient = this._reloadClient.bind(this);
this._stopConnectionAsync = this._stopConnectionAsync.bind(this);
this._checkExistMyFirebaseNodeAsync = this._checkExistMyFirebaseNodeAsync.bind(this);
this._notifyJoinLobbyFirebase = this._notifyJoinLobbyFirebase.bind(this);
this._onReceivedFirebaseMessage = this._onReceivedFirebaseMessage.bind(this);
this._onReceivedPeerMessage = this._onReceivedPeerMessage.bind(this);
this._onChangedChannelState = this._onChangedChannelState.bind(this);
this._onReceivedGamen = this._onReceivedGamen.bind(this);
this._deliverQueuingIceCandidate = this._deliverQueuingIceCandidate.bind(this);
this._sendIceCandidate = this._sendIceCandidate.bind(this);
this._setAnswer = this._setAnswer.bind(this);
this._addIceCandidate = this._addIceCandidate.bind(this);
this._setCodecVP8 = this._setCodecVP8.bind(this);
this._enqueueSendSignalingMessage = this._enqueueSendSignalingMessage.bind(this);
this._sendSignalingMessage = this._sendSignalingMessage.bind(this);
this._putSignalingLog = this._putSignalingLog.bind(this);
this.setSigLibLogLevel = this.setSigLibLogLevel.bind(this);
this.getLastSigLibLogMessage = this.getLastSigLibLogMessage.bind(this);
this.sendClientState = this.sendClientState.bind(this);
this.sendClientCapturedResult = this.sendClientCapturedResult.bind(this);
this.sendApplyAntiCheatResponse = this.sendApplyAntiCheatResponse.bind(this);
this.sendMessengerResponse = this.sendMessengerResponse.bind(this);
this.sendMessengerRequest = this.sendMessengerRequest.bind(this);
this.sendGamenBinaryToCtrl = this.sendGamenBinaryToCtrl.bind(this);
this.terminateAllGamenBinaryTransfer = this.terminateAllGamenBinaryTransfer.bind(this);
this.clearReconnectFirebaseTimer = this.clearReconnectFirebaseTimer.bind(this);
this.clearEmittoJoinLobbyTimeoutTimer = this.clearEmittoJoinLobbyTimeoutTimer.bind(this);
this.setCheckExistMyFirebaseNodeTimer = this.setCheckExistMyFirebaseNodeTimer.bind(this);
this.clearCheckExistMyFirebaseNodeTimer = this.clearCheckExistMyFirebaseNodeTimer.bind(this);
this.clearJuageFailedStartCounterResetTimer = this.clearJuageFailedStartCounterResetTimer.bind(this);
this.prepareNewConnection = this.prepareNewConnection.bind(this);
this.getSigConfigInfoAsync = this.getSigConfigInfoAsync.bind(this);
this.connectFirebase = this.connectFirebase.bind(this);
this.offlineFirebase = this.offlineFirebase.bind(this);
this.watchSignalingCtrl = this.watchSignalingCtrl.bind(this);
this.sendFirebaseMessage = this.sendFirebaseMessage.bind(this);
this.sendSdpOffer = this.sendSdpOffer.bind(this);
if (typeof WbSigLib.setSigLibLogCallback === 'function') {
WbSigLib.setSigLibLogCallback((message) => {
if (typeof message === 'string') {
this._lastSigLibLogMessage = message;
LogManager.putLog(message, LogLevels.INFO);
}
});
}
}
set receivedCommandCallback(method) {
this._receivedCommandCallbackMethod = (typeof method === 'function') ? method : () => {};
}
set disconnectCtrlAsyncCallback(method) {
this._disconnectCtrlAsyncCallbackMethod = (typeof method === 'function') ? method : () => Promise.resolve(false);
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
_extractSigConfig(getInfoResult) {
let sigConfig = null;
try {
if ((getInfoResult) && (getInfoResult.res === 0)) {
const configKey = Object.keys(getInfoResult).find(key => /^\d{3}$/.test(key));
if (configKey) {
const configObj = getInfoResult[configKey];
sigConfig = {
limitClient: (typeof configObj.limitClient === 'number') ? configObj.limitClient : 1,
};
if (this._cData.isDeveloperMode) {
let debugLimitClientValue = (this._cAux.getDebugTestMode('C') & 0x0C) >> 2;
if ((debugLimitClientValue !== 0) && (sigConfig.limitClient !== debugLimitClientValue)) {
sigConfig.limitClient = debugLimitClientValue;
}
}
}
}
}
catch (err) {
const errorMsg = 'ERROR - _extractSigConfig()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
}
return sigConfig;
}
_makeLogStringCommMessage(messageObj) {
let result = JSON.stringify(messageObj);
if (this._cData.debugTraceLevel !== TraceLevels.DEBUG) {
if (((messageObj.type === 'cmd') && (messageObj.cmd === '14')) ||
((messageObj.type === 'cmd') && (messageObj.cmd === '15'))) {
let tempData = Object.assign({}, messageObj);
if ('msg' in tempData)  tempData.msg = '[SECRET]';
result = JSON.stringify(tempData);
}
}
return result;
}
_disableClient() {
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, {
cmd: 'SetEnabledClient',
value: false
})
.catch((err) => {
const errorMsg = 'ERROR - _disableClient()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
});
}
_stopClient() {
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, {
cmd: 'StopClient',
windowId: this._cData.selfWindowId
}, true)
.catch((err) => {
const errorMsg = 'ERROR - _stopClient()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
});
}
_sendLatestClientState(ctrlMail=null) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'SendLatestClientState',
mailAddress: (ctrlMail) ? ctrlMail : null
});
}
_stopGamenJunshi(ctrlMail) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'StopGamenJunshi',
mailAddress: ctrlMail
});
}
_startWatchAvailableTime() {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'StartWatchAvailableTime'
});
}
_stopWatchAvailableTime() {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'StopWatchAvailableTime'
});
}
_startWatchNightLimit() {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'StartWatchNightLimit'
});
}
_stopWatchNightLimit() {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'StopWatchNightLimit'
});
}
_leaveClasswork(isStopAllConnection, doneNoticeUniqueCode=-1) {
const message = {
cmd: 'LeaveClasswork',
stopAllConnection: isStopAllConnection
};
if (doneNoticeUniqueCode >= 0) {
message.doneNoticeBcName = BcNames.CLIENT_CORE;
message.doneNoticeUniqueCode = doneNoticeUniqueCode;
}
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, message);
}
_reloadClient(caller, cause=null) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ReloadClient',
caller: caller,
cause: cause
});
}
_stopConnectionAsync(ctrlMail, cause=null) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
try {
return this._disconnectCtrlAsyncCallbackMethod(ctrlMail, cause);
}
catch (err) {
const errorMsg = 'ERROR - _stopConnectionAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
}
}
return Promise.resolve(false);
}
_checkExistMyFirebaseNodeAsync() {
Utils.assert((typeof WbSigLib.existsMyReceiveNode === 'function'), 'Implementation Error. -- Not found WbSigLib.existsMyReceiveNode function');
return new Promise((resolve) => {
try {
if (this._cData.onlineNotificationState === 3) {
WbSigLib.existsMyReceiveNode((result) => {
if (this._cData.onlineNotificationState === 3) {
if (result?.res === 0) {
this._putLog('自身の受信用Firebaseノードの存在を確認しました.', LogLevels.INFO);
}
else {
this._putLog(`自身の受信用Firebaseノードの存在が確認できなかったため、クライアントコアページを再作成します.  (${result?.res})`, LogLevels.FATAL);
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'CreateClientCorePage' }).then(()=>{});
}
}
resolve();
});
}
else {
resolve();
}
}
catch (err) {
const errorMsg = 'ERROR - _checkExistMyFirebaseNodeAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve();
}
});
}
_notifyJoinLobbyFirebase() {
if (this._cData.isChangedDomainSystemId) {
this._reloadClient('4A', 'ポリシー設定のドメイン識別IDの変更');
return;
}
this._stopWatchAvailableTime();
if (! this._cData.isConnectingFirebase) {
this._putLog('Firebaseとの接続処理キャンセルによりオンライン通知送信をスキップします.', this._cData.getTraceLogLevel());
this._cAux.notifyChangedClientStatus();
return;
}
this._putLog('オンライン通知(join_lobby)を送信します.', LogLevels.INFO);
this._cData.onlineNotificationState = 1;
this.clearEmittoJoinLobbyTimeoutTimer();
this._cData.emittoJoinLobbyTimeoutTimerId = setTimeout(() => {
this._cData.emittoJoinLobbyTimeoutTimerId = TIMER_ID_NONE;
if (this._cData.isConnectingFirebase) {
this._reloadClient('4B', 'オンライン通知(join_lobby)のemitTo無応答エラー<Timeout>検出');
}
}, Constants.TIMEOUT_EMIT_TO_JOIN_LOBBY);
WbSigLib.emitTo(null, {
type: 'join_lobby',
mail: this._cData.signedUserEmail
}, (result) => {
if ((! this.clearEmittoJoinLobbyTimeoutTimer()) && (this._cData.isConnectingFirebase))  return;
if ((result) && (result.res === 0)) {
this._putLog('****  オンライン通知(join_lobby) 送信成功', LogLevels.INFO);
this._cData.onlineNotificationState = 3;
this._cAux.notifyChangedClientStatus();
if (typeof WbSigLib.existsMyReceiveNode === 'function') {
this.setCheckExistMyFirebaseNodeTimer(Constants.CHECK_EXIST_FIREBASE_MY_NODE_DELAY);
WbSigLib.setOnConnectChange((result) => {
if (result?.res === 1) {
this.clearCheckExistMyFirebaseNodeTimer();
}
else if ((result?.res === 0) && (this._cData.onlineNotificationState === 3)) {
this.setCheckExistMyFirebaseNodeTimer(Constants.CHECK_EXIST_FIREBASE_MY_NODE_DELAY);
}
});
}
const resetRunMSec = Constants.TIMEOUT_SIGNALING + Constants.WATCH_SIGNALING_CTRL_INTERVAL + 10000;
this._cData.juageFailedStartCounterResetTimerId = this._timer.addTimer(resetRunMSec, false, () => {
if (this._cData.isReceivedStartClassWithoutTime) {
this._putLog(`オンライン通知から ${Math.round(resetRunMSec/1000)}秒経過により、授業開始失敗カウンタをリセットします.`, LogLevels.INFO);
CountManager.deleteAsync('FailedStart#*')
.catch((err) => {
const errorMsg = `ERROR - _notifyJoinLobbyFirebase() - ` + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
});
}
});
WbSigLib.setOnDisconnect(this._cData.signedUserEmail, (disconectedEmail) => {
this._putLog(`Firebaseとの切断検出.  (setOnDisconnectによりコールバックされた  onlineState:${this._cData.onlineNotificationState})`, LogLevels.INFO);
if (this._cData.onlineNotificationState === 0) {
this._putLog('シグナリングサーバ非オンライン状態でのFirebaseとの切断検出を無視しました.', LogLevels.INFO);
return;
}
this.clearEmittoJoinLobbyTimeoutTimer();
this.clearCheckExistMyFirebaseNodeTimer();
this._cData.onlineNotificationState = 0;
WbSigLib.setOnDisconnect(disconectedEmail, null);
this._cAux.notifyChangedClientStatus();
this.clearJuageFailedStartCounterResetTimer();
this._leaveClasswork(true);
this._stopWatchAvailableTime();
if (! this._cData.isChromeLockedScreen) {
WbSigLib.releaseSigLibDatabase();
this._cData.isInitializedSigLib = false;
this._cData.isWaitingBrowserOnline = false;
this._cData.isWaitingExtensionPolicy = false;
this._cAux.notifyChangedClientStatus();
if (this._cData.osType === OsTypes.CHROME) {
const delaySeconds = this._cData.isExperiencedSleep ? 5 : 24;
this._putLog(`Firebaseとの切断検出により再接続処理を ${delaySeconds}秒後にスケジュールします.`, LogLevels.INFO);
this.clearReconnectFirebaseTimer();
this._cData.reconnectFirebaseTimerId = this._timer.addTimer((delaySeconds * 1000), false, () => {
this._cData.isConnectingFirebase = true;
this.connectFirebase();
});
}
else {
this._putLog(`Firebaseとの切断検出により再接続処理をスケジュールします.`, LogLevels.INFO);
this.clearReconnectFirebaseTimer();
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(0, false, () => {
this._cData.isConnectingFirebase = true;
this.connectFirebase();
});
}
}
if (this._cData.osType === OsTypes.CHROME) {
this._cData.isExperiencedSleep = true;
}
});
this._cData.isConnectingFirebase = false;
}
else {
if (this._cData.isConnectingFirebase) {
this._putLog(`****  オンライン通知(join_lobby) 送信エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this.clearReconnectFirebaseTimer();
this._putLog('オンライン通知の送信失敗により再接続処理をスケジュールします.', LogLevels.INFO);
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(Constants.FIREBASE_RECONNECT_INTERVAL, false, () => { this.connectFirebase(); });
}
}
if (this._cData.isChangedDomainSystemId) {
this._reloadClient('4C', 'ポリシー設定のドメイン識別IDの変更');
return;
}
this._startWatchAvailableTime();
});
}
_onReceivedFirebaseMessage(message) {
try {
if ((typeof message !== 'object') || (typeof message.type !== 'string')) {
this._putLog('シグナリングサーバ(Firebase)から異常なメッセージを受信...', LogLevels.INFO);
return;
}
if ((this._cData.onlineNotificationState !== 3) && (this._cData.onlineNotificationState !== 1)) {
this._putLog(`シグナリングサーバ非オンライン状態(${this._cData.onlineNotificationState})時の受信メッセージを破棄.  ${Utils.truncateStr(JSON.stringify(message), 100)}`, LogLevels.INFO);
return;
}
const ctrlMail = (typeof message.mail === 'string') ? message.mail : null;
if ((message.type === 'candidate') || (message.type === 'answer')) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`受信  ${JSON.stringify(message)}`, LogLevels.INFO);
this._putLog(`_onReceivedFirebaseMessage() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
return;
}
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
targetCtrlInfo.addSignalingLog('受信', JSON.stringify(message));
}
else {
this._putLog(`シグナリング( ${ctrlMail} )受信  ${JSON.stringify(message)}`, LogLevels.INFO);
}
if (message.type === 'candidate') {
if ('ice' in message) {
const candidate = new RTCIceCandidate(message.ice);
this._addIceCandidate(ctrlMail, candidate);
}
else if ((targetCtrlInfo.compareProtocolVersion(1, 3) >= 0) && ('ices' in message)) {
for (let ice of message.ices) {
const candidate = new RTCIceCandidate(ice);
this._addIceCandidate(ctrlMail, candidate);
}
}
}
else {
CountManager.deleteAsync(`FailedStart#${ctrlMail}#*`)
.then(() => {
this._putLog(`コントローラ( ${ctrlMail} )からanswer受信のため(存在確認OK)、授業開始失敗カウンタを削除しました.`, LogLevels.INFO);
});
if (typeof message.btver === 'string') {
targetCtrlInfo.peerBinTransferVersion = WbBTGamen.testAvailableBTVer(message.btver);
if (targetCtrlInfo.isGamenBinaryTransfer()) {
targetCtrlInfo.createPeerBinChannel(this._onChangedChannelState);
targetCtrlInfo.activeTabJunshiStream = this._cData.activeTabJunshiDummyCanvas.captureStream();
if (targetCtrlInfo.gamenJunshiType !== 'screen') {
const width = this._cData.activeTabJunshiDummyCanvas.width;
const aspectRatio = this._cData.activeTabJunshiDummyCanvas.width / this._cData.activeTabJunshiDummyCanvas.height;
Utils.setVideoStreamConstraints(targetCtrlInfo.activeTabJunshiStream, width, aspectRatio, (result) => {
if (result) {
Utils.replacePeerVideoStream(targetCtrlInfo.peerConnection, targetCtrlInfo.activeTabJunshiStream);
}
});
}
}
}
const answer = new window.RTCSessionDescription({
type: 'answer',
sdp: message.sdp
});
this._setAnswer(ctrlMail, answer);
}
}
else if ((message.type === 'cmd') || (message.type === 'ans')) {
const logReceivedMessage = this._makeLogStringCommMessage(message);
this._putLog(`コントローラ( ${ctrlMail} )からFireBaseメッセージを受信...  MSG: ${logReceivedMessage}`,
LogLevels.INFO, ((this._cData.debugTraceLevel === TraceLevels.UNSET) ? 250 : 0));
this._receivedCommandCallbackMethod(message);
}
else if (message.type === 'start_class') {
this._putLog(`コントローラ( ${ctrlMail} )から授業開始通知メッセージを受信...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
if (! ctrlMail) {
this._putLog('異常なコントローラメールアドレスの授業開始通知を破棄しました.', LogLevels.INFO);
}
else {
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
this._stopConnectionAsync(ctrlMail, '同一コントローラからの授業開始通知の受信')
.then(()=> {
this._putLog(`同一コントローラからの授業開始通知の受信により、授業開始通知メッセージ受信の再処理を 2秒後にスケジュールします.`, LogLevels.INFO);
this._timer.addTimer(1950, false, this._onReceivedFirebaseMessage, message);
});
return;
}
if (this._isBusyStartClassProsess) {
this._putLog(`授業開始通知の処理中により、授業開始通知メッセージ受信の再処理を 0.5秒後にスケジュールします.`, LogLevels.INFO);
this._timer.addTimer(450, false, this._onReceivedFirebaseMessage, message);
return;
}
const fnStartClassProsessAsync = async (message) => {
try {
const startClassEntryTime = (typeof message.entryTime === 'string') ? message.entryTime : '';
if (! startClassEntryTime)  this._cData.isReceivedStartClassWithoutTime = true;
const failedStartCount = await CountManager.readAsync(`FailedStart#${ctrlMail}#${startClassEntryTime}`);
const controllerSeqNo = await CountManager.incrementAsync('ControllerSeqNo');
if (failedStartCount > Constants.MAX_RETRY_WHEN_SIGNALING_FAILED) {
this._putLog(`コントローラ( ${ctrlMail} )との授業開始通知によるシグナリング失敗が継続(${failedStartCount}回)しているため、授業開始通知を破棄しました.`, LogLevels.INFO);
return;
}
if (this._cData.connectedCtrlInfos.length === 0) {
this._cData.isNeedsConfirmingJoinClasswork = false;
WbBTGamen.initialize(false, this._onReceivedGamen);
}
const classworkName = message.roomName || '';
const classworkTeacherName = message.teacherName || '';
targetCtrlInfo = new ControllerInfo(controllerSeqNo, ctrlMail, classworkTeacherName);
targetCtrlInfo.startClassEntryTime = startClassEntryTime;
this._cData.connectedCtrlInfos.push(targetCtrlInfo);
this._cAux.notifyChangedClientStatus();
if (typeof message.cver === 'string') {
const verParts = message.cver.split('.');
const majorVer = Number(verParts[0]);
if (! isNaN(majorVer)) { targetCtrlInfo.commProtocolMajorVersion = majorVer; }
if (verParts.length >= 2) {
const minorVer = Number(verParts[1]);
if (! isNaN(minorVer)) { targetCtrlInfo.commProtocolMinorVersion = minorVer; }
}
if ((this._signalingType === 1) ||
((this._signalingType === 0) && (targetCtrlInfo.compareProtocolVersion(1, 3) >= 0))) {
targetCtrlInfo.signalingSendIceQueue = [];
}
}
if (! this._cData.isCbtMode) {
targetCtrlInfo.firstGamenJunshiType = message.capType;
}
if (this._cData.connectedCtrlInfos.length === 1) {
const fnWaitDoneAsync = async (uniqueCode, timeout) => {
return new Promise(async (resolve) => {
try {
let timeoutTimerId = this._timer.addTimer(timeout, false, () => {
timeoutTimerId = TIMER_ID_NONE;
this._cData.doneLeaveClassworkNotifiedCode = uniqueCode;
});
while (this._cData.doneLeaveClassworkNotifiedCode < uniqueCode) {
await new Promise((resolve2) => this._timer.addTimer(100, false, resolve2, true));
}
if (timeoutTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(timeoutTimerId);
timeoutTimerId = TIMER_ID_NONE;
resolve(true);
}
else {
resolve(false);
}
}
catch (err) {
const errorMsg = 'ERROR - fnWaitDoneAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve(false);
}
});
};
this._cData.doneLeaveClassworkNotifiedCode = -1;
const uniqueCode = Date.now();
this._leaveClasswork(false, uniqueCode);
await fnWaitDoneAsync(uniqueCode, 7000);
}
targetCtrlInfo.peerConnectionState = PeerStates.PARTICIPATION_PRECEDURE;
if (this._cData.isNeedsConfirmingJoinClasswork) {
return;
}
if (this._cData.connectedCtrlInfos.length === 1) {
if ((! this._cData.isCbtMode) && (message.confirm)) {
this._cData.isNeedsConfirmingJoinClasswork = true;
}
this._cData.classworkName = classworkName;
this._cData.classworkTeacherName = classworkTeacherName;
await ApiWrappers.saveSessionStorageDataAsync({
ClassworkName: classworkName,
ClassworkTeacherName: classworkTeacherName,
});
if (this._cData.isNeedsConfirmingJoinClasswork) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, { cmd: 'ConfirmJoinClasswork' });
}
else {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'JoinClasswork',
flashClientCore: (targetCtrlInfo?.firstGamenJunshiType !== 'screen')
});
}
}
else {
targetCtrlInfo.isAlreadyJoinAnswered = true;
this.prepareNewConnection(targetCtrlInfo.mailAddress);
}
}
catch (err) {
const errorMsg = 'ERROR - _onReceivedFirebaseMessage() start_class' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
this._reloadClient('4D', '授業開始通知の処理異常');
}
};
this._isBusyStartClassProsess = true;
fnStartClassProsessAsync(message)
.finally(() => { this._isBusyStartClassProsess = false; });
}
}
else if (message.type === 'end_class') {
this._putLog(`コントローラ( ${ctrlMail} )の授業終了通知メッセージを受信...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
this._stopConnectionAsync(ctrlMail, '授業終了通知の受信').then(() => {});
}
else if (message.type === 'expulsion_lobby') {
this._putLog(`退出指示メッセージを受信...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
const unusableReasonCode = (typeof message.reason === 'number') ? message.reason : 0;
ApiWrappers.saveSessionStorageDataAsync({ UnusableReasonCode: unusableReasonCode }).then(() => {});
this._disableClient();
if (unusableReasonCode === 1) {
this._putLog('退出指示(二重ログイン検知)により、クライアント機能を無効にしました.', LogLevels.FATAL);
}
else {
this._putLog('退出指示により、クライアント機能を無効にしました.', LogLevels.FATAL);
}
this._leaveClasswork(true);
this._stopWatchAvailableTime();
this.clearEmittoJoinLobbyTimeoutTimer();
this.clearCheckExistMyFirebaseNodeTimer();
this._putLog('setOnDisconnect()を取り消します.', LogLevels.INFO);
WbSigLib.setOnDisconnect(this._cData.signedUserEmail, null);
WbSigLib.releaseSigLibDatabase();
this._cData.isInitializedSigLib = false;
this._cData.isConnectingFirebase = false;
this._cData.failedInitializeSigLibCounter = 0;
this._cData.isWaitingBrowserOnline = false;
this._cData.isWaitingExtensionPolicy = false;
this._cData.onlineNotificationState = 0;
this._cAux.notifyChangedClientStatus();
}
else {
this._putLog(`シグナリングサーバ(Firebase)から未対応メッセージを受信...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
catch (err) {
const errorMsg = 'ERROR - _onReceivedFirebaseMessage()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
}
}
_onReceivedPeerMessage(ctrlMail, data) {
try {
const receivedData = JSON.parse(data);
const logReceivedMessage = this._makeLogStringCommMessage(receivedData);
this._putLog(`コントローラ( ${ctrlMail} )からP2Pメッセージを受信...  MSG: ${logReceivedMessage}`,
LogLevels.INFO, ((this._cData.debugTraceLevel === TraceLevels.UNSET) ? 250 : 0));
if ((receivedData.type === 'cmd') || (receivedData.type === 'ans')) {
this._receivedCommandCallbackMethod(receivedData);
}
else {
throw new Error(`Invalid ReceiveMessage Type: ${receivedData.type}`);
}
}
catch (err) {
const errorMsg = 'ERROR - _onReceivedPeerMessage()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
}
}
_onChangedChannelState(ctrlMail, channelType, readyState) {
const fnCheckPeerConnectFinished = (targetCtrlInfo) => {
if (targetCtrlInfo.peerConnectionState !== PeerStates.CONNECTED) {
if ((targetCtrlInfo.isOpenedReceiveChannel) && (targetCtrlInfo.isOpenedSendChannel)) {
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )とのシグナリング接続(P2P)成功.`, LogLevels.INFO);
targetCtrlInfo.peerConnectionState = PeerStates.CONNECTED;
targetCtrlInfo.gamenJunshiFrameRate = 0;
targetCtrlInfo.clearSignalingSendMessageQueue();
targetCtrlInfo.clearSignalingLog();
this._cAux.notifyChangedClientStatus();
this._sendLatestClientState(targetCtrlInfo.mailAddress);
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ConnectedController',
mailAddress: targetCtrlInfo.mailAddress,
isP2P: true
});
}
}
};
this._putLog(`**_onChangedChannelState() - Mail=${ctrlMail}  Type=${channelType}  State=${readyState}`);
switch (channelType) {
case 'receiveMsg':
if (readyState.toLowerCase() === 'closed') {
this._putLog('P2PデータチャネルのClosed を検出.', LogLevels.INFO);
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
targetCtrlInfo.isOpenedReceiveChannel = false;
}
}
else if (readyState.toLowerCase() === 'open') {
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
targetCtrlInfo.isOpenedReceiveChannel = true;
fnCheckPeerConnectFinished(targetCtrlInfo);
}
}
break;
case 'receivebin':
break;
case 'sendMsg':
if (readyState.toLowerCase() === 'closed') {
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
targetCtrlInfo.isOpenedSendChannel = false;
}
}
else if (readyState.toLowerCase() === 'open') {
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
targetCtrlInfo.isOpenedSendChannel = true;
fnCheckPeerConnectFinished(targetCtrlInfo);
}
}
break;
case 'sendBin':
if (readyState.toLowerCase() === 'open') {
let targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
WbBTGamen.addMember(ctrlMail, targetCtrlInfo.peerSendBinChannel, targetCtrlInfo.peerBinTransferVersion);
}
}
else if (readyState.toLowerCase() === 'closed') {
WbBTGamen.removeMember(ctrlMail);
}
break;
}
}
_onReceivedGamen(gamenData) {
if ((this._cData.ctrlRequestedGamenTeijiMail) && (gamenData.email === this._cData.ctrlRequestedGamenTeijiMail)) {
if (this._cData.isGamenTeijiMode) {
this._cData.currentGamenTeijiImageBase64 = gamenData.imageBase64 || '';
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, {
cmd: 'ChangedTeijiImage',
isResend: false,
imageBase64: this._cData.currentGamenTeijiImageBase64
})
.then(() => {
});
}
}
else {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(gamenData.email);
if ((! targetCtrlInfo) || (! targetCtrlInfo.isRejectedGamenTeiji)) {
this._putLog(`画面提示中でないコントローラ(${gamenData.email})の画面フレーム(${gamenData.frameCode})を破棄しました.  imageBase64Len=${gamenData.imageBase64.length}`, LogLevels.INFO);
}
}
}
_deliverQueuingIceCandidate(ctrlMail) {
this._putLog('Called _deliverQueuingIceCandidate()', this._cData.getTraceLogLevel(true));
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
if (targetCtrlInfo.signalingSendIceQueuingTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(targetCtrlInfo.signalingSendIceQueuingTimerId);
targetCtrlInfo.signalingSendIceQueuingTimerId = TIMER_ID_NONE;
}
if (Array.isArray(targetCtrlInfo.signalingSendIceQueue)) {
if (targetCtrlInfo.compareProtocolVersion(1, 3) >= 0) {
let ices = [];
while (targetCtrlInfo.signalingSendIceQueue.length > 0) {
ices.push(targetCtrlInfo.signalingSendIceQueue.shift());
if (ices.length >= Constants.MAX_ICE_COUNT_IN_CANDIDATE_MESSAGE) {
this._sendIceCandidate(ctrlMail, ices);
ices = [];
}
}
if (ices.length > 0) {
this._sendIceCandidate(ctrlMail, ices);
}
}
else {
while (targetCtrlInfo.signalingSendIceQueue.length > 0) {
this._sendIceCandidate(ctrlMail, targetCtrlInfo.signalingSendIceQueue.shift());
}
}
targetCtrlInfo.signalingSendIceQueue = null;
}
}
}
_sendIceCandidate(ctrlMail, candidates) {
ApiWrappers.readSessionStorageValueAsync({ IsEnabledClient: false })
.then((isEnabledClient) => {
if (isEnabledClient) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog('Connection not exist or already closed. so skip candidate', LogLevels.INFO)
}
else {
const message = {
type: 'candidate',
mail: this._cData.signedUserEmail
};
if (Array.isArray(candidates)) {
message.ices = candidates;
}
else {
message.ice = candidates;
}
this._enqueueSendSignalingMessage(targetCtrlInfo, message);
}
}
});
}
_setAnswer(ctrlMail, sessionDescription) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`_setAnswer() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
return;
}
const peerConnection = targetCtrlInfo.peerConnection;
if (! peerConnection) {
this._putLog(`_setAnswer() - peerConnection not exist.  Mail=${targetCtrlInfo.mailAddress}`, LogLevels.INFO);
return;
}
peerConnection.setRemoteDescription(sessionDescription)
.then(() => {
this._putLog('peerConnection.setRemoteDescription(sessionDescription)  succsess in promise');
})
.catch((err) => {
const errorMsg = 'ERROR - peerConnection.setRemoteDescription(sessionDescription)' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
this._putSignalingLog(ctrlMail);
}
});
}
_addIceCandidate(ctrlMail, candidate) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`_addIceCandidate() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
return;
}
const peerConnection = targetCtrlInfo.peerConnection;
if (! peerConnection) {
this._putLog(`_addIceCandidate() - peerConnection not exist.  Mail=${targetCtrlInfo.mailAddress}`, LogLevels.INFO);
return;
}
peerConnection.addIceCandidate(candidate)
.then(() => {
if (this._signalingType === 1) {
if ((targetCtrlInfo.signalingSendIceQueuingTimerId !== TIMER_ID_NONE) &&
(Array.isArray(targetCtrlInfo.signalingSendIceQueue))) {
this._timer.removeTimer(targetCtrlInfo.signalingSendIceQueuingTimerId);
targetCtrlInfo.signalingSendIceQueuingTimerId = TIMER_ID_NONE;
setTimeout(this._deliverQueuingIceCandidate, 0, ctrlMail);
}
}
})
.catch((err) => {
this._putLog(`_addIceCandidate() - addIceCandidate() Exception.  ${err.name}  Mail=${targetCtrlInfo.mailAddress}`, LogLevels.INFO);
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
this._putSignalingLog(targetCtrlInfo.mailAddress);
}
});
}
_setCodecVP8(peer) {
const transceiverList = peer.getTransceivers();
transceiverList.forEach((tc) => {
tc.setCodecPreferences([
{
clockRate: 90000,
mimeType: 'video/VP8',
scalabilityModes: ['L1T2','L1T3']
},
{
clockRate: 90000,
mimeType: 'video/rtx',
},
{
clockRate: 90000,
mimeType: 'video/H264',
sdpFmtpLine: 'packetization-mode=1;profile-level-id=42001f;level-asymmetry-allowed=1'
},
{
clockRate: 90000,
mimeType: 'video/rtx',
},
]);
});
}
_enqueueSendSignalingMessage(targetCtrlInfo, message) {
if (1 === targetCtrlInfo.enqueueSignalingSendMessage(message)) {
this._sendSignalingMessage(targetCtrlInfo);
}
}
_sendSignalingMessage(targetCtrlInfo) {
const message = targetCtrlInfo.dequeueSignalingSendMessage();
if (message != null) {
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
targetCtrlInfo.addSignalingLog('送信要求', JSON.stringify(message));
}
else {
this._putLog(`シグナリング( ${targetCtrlInfo.mailAddress} )送信要求  ${JSON.stringify(message)}`, LogLevels.INFO);
}
const target = { target: targetCtrlInfo.mailAddress };
WbSigLib.emitTo(target, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
this._sendSignalingMessage(targetCtrlInfo);
}
else {
this._putLog(`****  シグナリングメッセージ(${message.type})送信エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
this._putSignalingLog(targetCtrlInfo.mailAddress);
}
if ((targetCtrlInfo.peerConnectionState === PeerStates.SIGNALING_STARTED) ||
(targetCtrlInfo.peerConnectionState === PeerStates.SIGNALING)) {
targetCtrlInfo.peerConnectionState = PeerStates.SIGNALING_FAILED;
if (! targetCtrlInfo.isAbortedSignaling) {
targetCtrlInfo.isAbortedSignaling = true;
const ctrlMail = targetCtrlInfo.mailAddress;
const startClassEntryTime = targetCtrlInfo.startClassEntryTime;
this._stopConnectionAsync(ctrlMail, `${message.type}のFirebase送信失敗`)
.then(() => {
return CountManager.incrementAsync(`FailedStart#${ctrlMail}#${startClassEntryTime}`);
})
.then((count) => {
this._putLog(`コントローラ( ${ctrlMail} )の授業開始失敗カウンタを ${count} にインクリメントしました.`, this._cData.getTraceLogLevel());
if (count <= Constants.MAX_RETRY_WHEN_SIGNALING_FAILED) {
if (count === 1) {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラー検出(1回目)により、クライアントコアページを再作成します.`, LogLevels.INFO);
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'CreateClientCorePage' }).then(()=>{});
}
else {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラー検出(${count}回目)により、クライアントのリロードを 4秒後にスケジュールします.`, LogLevels.INFO);
this._timer.addTimer(3950, false, this._reloadClient, '4E', 'シグナリング通信エラー<Send>検出');
}
}
else {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラーの検出が ${count}回継続したため、シグナリングの再試行を断念しました.`, LogLevels.INFO);
}
});
}
}
}
});
}
}
_putSignalingLog(ctrlMail) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
const logs = targetCtrlInfo.getSignalingLogs();
if (logs.length > 0) {
targetCtrlInfo.clearSignalingLog();
this._putLog('=====< シグナリング通信ログ >=====', LogLevels.INFO);
logs.forEach((log) => {
this._putLog(`===  ${log}`, LogLevels.INFO);
});
}
}
}
setSigLibLogLevel(level) {
let result = false;
if (typeof WbSigLib.setSigLibLogLevel === 'function') {
result = WbSigLib.setSigLibLogLevel(level);
if (result) {
this._putLog(`シグナリングサーバライブラリのログレベルに ${level} を設定しました.`, LogLevels.INFO);
}
}
return result;
}
getLastSigLibLogMessage() {
return this._lastSigLibLogMessage || '';
}
sendClientState(ctrlMail=null) {
ApiWrappers.readSessionStorageDataAsync({
IsEnabledClient: false,
IsActivedMessenger: false,
})
.then((storage) => {
if ((storage) && (storage.IsEnabledClient)) {
const message = {
type: 'status',
mail: this._cData.signedUserEmail,
mouse_lock: this._cData.isGamenLockMode,
web_limit: (this._cData.appliedBrowserSeigen === BrowserSeigens.CONTROLLER),
web_limit_ext: (this._cData.appliedBrowserSeigen === BrowserSeigens.CBTMODE) || (this._cData.appliedBrowserSeigen === BrowserSeigens.NIGHT),
antiCheat: this._cData.isCbtMode,
messenger: storage.IsActivedMessenger,
battery: {
charging: this._cData.currentBatteryCharging,
level: this._cData.currentBatteryLevel,
},
active_tab: {
favicon: this._cData.currentActiveTabFaviconUrl,
title: this._cData.currentActiveTabTitle,
},
capType: this._cData.currentGamenJunshiType,
};
if (! this._cData.currentActiveTabFaviconUrl) {
if (this._cData.currentActiveTabUrl.startsWith(this._cData.markerPageAbsoluteUrl)) {
message.active_tab.url = 'wb:marker';
}
else if (! this._cData.currentActiveTabUrl.startsWith(this._cData.selfExtensionPrefixUrl)) {
message.active_tab.url = this._cData.currentActiveTabUrl;
}
else {
message.active_tab.url = '';
if ((this._cData.currentActiveTabUrl.startsWith(this._cData.classworkPageAbsoluteUrl)) ||
(this._cData.currentActiveTabTitle.startsWith(this._cData.classworkPageAbsoluteUrl))) {
if (! this._cData.isConfirmingJoinClasswork) {
message.active_tab.url = 'wb:confirmScreen';
message.active_tab.title = Utils.getLocaleMessage('title_waitingDesktopSharingApproval');
}
}
else if (this._cData.currentActiveTabUrl.startsWith(this._cData.attentionPageAbsoluteUrl)) {
if (this._cData.isGamenLockMode) {
message.active_tab.url = 'wb:lock';
message.active_tab.title = Utils.getLocaleMessage('title_nowInLocked');
}
else if (this._cData.isGamenTeijiMode) {
message.active_tab.url = 'wb:teiji';
message.active_tab.title = Utils.getLocaleMessage('title_nowInGamenTeiji');
}
}
else if (this._cData.currentActiveTabUrl.startsWith(this._cData.blockedPageAbsoluteUrl)) {
if (this._cData.appliedBrowserSeigen !== BrowserSeigens.NONE) {
message.active_tab.url = 'wb:block';
message.active_tab.title = Utils.getLocaleMessage('title_nowInBlockedPage');
}
else {
message.active_tab.favicon = '';
message.active_tab.title = '';
}
}
else if (this._cData.currentActiveTabUrl.startsWith(this._cData.messengerPageAbsoluteUrl)) {
message.active_tab.url = 'wb:messenger';
message.active_tab.title = Utils.getLocaleMessage('title_messengerPage');
}
else if (this._cData.currentActiveTabUrl.startsWith(this._cData.optionsPageAbsoluteUrl)) {
message.active_tab.url = 'wb:option';
message.active_tab.title = Utils.getLocaleMessage('ext_title');
}
}
}
if (ctrlMail) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
if (targetCtrlInfo.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! targetCtrlInfo.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'クライアント状態のP2P送信失敗').then(() => {});
}
else if (! targetCtrlInfo.isSentFirstClientState) {
targetCtrlInfo.isSentFirstClientState = true;
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )に初回のクライアント状態を送信しました.`, LogLevels.INFO);
this.sendClientCapturedResult(targetCtrlInfo);
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )に初回のクライアント画面キャプチャ成否結果を送信しました.`, LogLevels.INFO);
}
}
else if (targetCtrlInfo.peerConnectionState === PeerStates.ENTRUST_FIREBASE) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(targetCtrlInfo.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
targetCtrlInfo.refreshLastCommunicationTime();
if (! targetCtrlInfo.isSentFirstClientState) {
targetCtrlInfo.isSentFirstClientState = true;
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )に初回のクライアント状態を送信しました.`, LogLevels.INFO);
if (targetCtrlInfo.isFirebaseJunshi) {
this.sendClientCapturedResult(targetCtrlInfo);
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )に初回のクライアント画面キャプチャ成否結果を送信しました.`, LogLevels.INFO);
}
}
}
else {
this._putLog(`****  クライアント状態のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'クライアント状態のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${targetCtrlInfo.mailAddress} )へのクライアント状態のFirebase送信を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
}
else {
this._cData.connectedCtrlInfos.forEach((info) => {
if (info.isSentFirstClientState) {
if (info.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! info.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(info.mailAddress, 'クライアント状態のP2P送信失敗').then(() => {});
}
}
else if (info.peerConnectionState === PeerStates.ENTRUST_FIREBASE) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(info.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
info.refreshLastCommunicationTime();
}
else {
this._putLog(`****  クライアント状態のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(info.mailAddress, 'クライアント状態のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${info.mailAddress} )へのクライアント状態のFirebase送信失敗を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
});
}
}
});
}
sendClientCapturedResult(targetCtrlInfo) {
const isCaptured = (this._cData.isConfirmingScreenSharing) ? false : (!! targetCtrlInfo.isJunshiCaptured);
const message = {
type: 'event',
mail: this._cData.signedUserEmail,
cap_res: isCaptured,
};
if (targetCtrlInfo.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! targetCtrlInfo.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, '画面キャプチャ結果通知のP2P送信失敗').then(() => {});
}
}
else if ((targetCtrlInfo.peerConnectionState === PeerStates.ENTRUST_FIREBASE) && (targetCtrlInfo.isFirebaseJunshi)) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(targetCtrlInfo.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
targetCtrlInfo.refreshLastCommunicationTime();
}
else {
this._putLog(`****  画面キャプチャの成否結果のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(targetCtrlInfo.mailAddress, '画面キャプチャの成否結果のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${targetCtrlInfo.mailAddress} )への画面キャプチャの成否結果のFirebase送信を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
sendApplyAntiCheatResponse(targetCtrlInfo, ansCode) {
const message = {
type: 'ans',
cmd: '10',
ans: ansCode,
mail: this._cData.signedUserEmail,
};
if (targetCtrlInfo?.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! targetCtrlInfo.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'カンニング対応応答のP2P送信失敗').then(() => {});
}
}
else if (targetCtrlInfo?.peerConnectionState === PeerStates.ENTRUST_FIREBASE) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(targetCtrlInfo.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
targetCtrlInfo.refreshLastCommunicationTime();
}
else {
this._putLog(`****  カンニング対応応答のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'カンニング対応応答のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${targetCtrlInfo.mailAddress} )へのカンニング対応応答のFirebase送信を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
sendMessengerResponse(targetCtrlInfo, requestId, ansCode) {
const message = {
type: 'ans',
cmd: '14',
reqId: requestId,
ans: ansCode,
mail: this._cData.signedUserEmail,
};
if (targetCtrlInfo?.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! targetCtrlInfo.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'Ctrメッセンジャー応答のP2P送信失敗').then(() => {});
}
}
else if (targetCtrlInfo?.peerConnectionState === PeerStates.ENTRUST_FIREBASE) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(targetCtrlInfo.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
targetCtrlInfo.refreshLastCommunicationTime();
}
else {
this._putLog(`****  Ctrメッセンジャー応答のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'Ctrメッセンジャー応答のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${targetCtrlInfo.mailAddress} )へのCtrメッセンジャー応答のFirebase送信を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
sendMessengerRequest(targetCtrlInfo, requestId, msgString) {
const message = {
type: 'cmd',
cmd: '15',
reqId: requestId,
msg: msgString,
mail: this._cData.signedUserEmail,
};
if (targetCtrlInfo?.peerConnectionState === PeerStates.CONNECTED) {
const logMessageString = this._makeLogStringCommMessage(message);
if (! targetCtrlInfo.sendMessage(message, logMessageString)) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'Cliメッセンジャー要求のP2P送信失敗').then(() => {});
}
}
else if (targetCtrlInfo?.peerConnectionState === PeerStates.ENTRUST_FIREBASE) {
if (this._cData.onlineNotificationState === 3) {
this.sendFirebaseMessage(targetCtrlInfo.mailAddress, message, (result) => {
if ((result) && (result.res === 0) && ((! result.offline) || (result.offline.length === 0))) {
targetCtrlInfo.refreshLastCommunicationTime();
}
else {
this._putLog(`****  Cliメッセンジャー要求のFirebase送信失敗エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'Cliメッセンジャー要求のFirebase送信失敗').then(() => {});
}
});
}
else {
this._putLog(`オンライン通知済み状態でないため、コントローラ( ${targetCtrlInfo.mailAddress} )へのCliメッセンジャー要求のFirebase送信を断念...  MSG: ${JSON.stringify(message)}`, LogLevels.INFO);
}
}
}
sendGamenBinaryToCtrl(targetCtrlInfo) {
if (! targetCtrlInfo.isGamenBinaryTransfer()) {
Utils.assert(false, 'Implementation Error. -- sendGamenBinaryToCtrl()');
return;
}
if (targetCtrlInfo.gamenJunshiType === 'tab') {
if (targetCtrlInfo.activeTabJunshiCanvas) {
let reductionRate = 0;
if (targetCtrlInfo.activeTabJunshiRealWidth > 0) {
reductionRate = targetCtrlInfo.activeTabJunshiCanvas.width / targetCtrlInfo.activeTabJunshiRealWidth;
}
targetCtrlInfo.lastJunshiWidthReductionRate = reductionRate;
WbBTGamen.sendGamenToController(targetCtrlInfo.activeTabJunshiCanvas, reductionRate, targetCtrlInfo.mailAddress);
}
}
else if (targetCtrlInfo.gamenJunshiType === 'screen') {
if (targetCtrlInfo.desktopJunshiCanvas) {
const reductionRate = targetCtrlInfo.desktopJunshiCanvas.width / this._cData.desktopCapturedWidth;
targetCtrlInfo.lastJunshiWidthReductionRate = reductionRate;
WbBTGamen.sendGamenToController(targetCtrlInfo.desktopJunshiCanvas, reductionRate, targetCtrlInfo.mailAddress);
}
}
}
terminateAllGamenBinaryTransfer() {
WbBTGamen.terminate();
}
clearReconnectFirebaseTimer() {
if (this._cData.reconnectFirebaseTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._cData.reconnectFirebaseTimerId);
this._cData.reconnectFirebaseTimerId = TIMER_ID_NONE;
return true;
}
return false;
}
clearEmittoJoinLobbyTimeoutTimer() {
if (this._cData.emittoJoinLobbyTimeoutTimerId !== TIMER_ID_NONE) {
clearTimeout(this._cData.emittoJoinLobbyTimeoutTimerId);
this._cData.emittoJoinLobbyTimeoutTimerId = TIMER_ID_NONE;
return true;
}
return false;
}
setCheckExistMyFirebaseNodeTimer(delay=0) {
this.clearCheckExistMyFirebaseNodeTimer();
if (typeof WbSigLib.existsMyReceiveNode === 'function') {
this._cData.checkExistMyFirebaseNodeTimerId = setTimeout(() => {
this._cData.checkExistMyFirebaseNodeTimerId = TIMER_ID_NONE;
this._checkExistMyFirebaseNodeAsync().then(() => {});
}, delay);
}
}
clearCheckExistMyFirebaseNodeTimer() {
if (this._cData.checkExistMyFirebaseNodeTimerId !== TIMER_ID_NONE) {
clearTimeout(this._cData.checkExistMyFirebaseNodeTimerId);
this._cData.checkExistMyFirebaseNodeTimerId = TIMER_ID_NONE;
return true;
}
return false;
}
clearJuageFailedStartCounterResetTimer() {
if (this._cData.juageFailedStartCounterResetTimerId !== TIMER_ID_NONE) {
this._putLog('授業開始失敗カウンタリセット判定タイマを解除します.', LogLevels.INFO);
this._timer.removeTimer(this._cData.juageFailedStartCounterResetTimerId);
this._cData.juageFailedStartCounterResetTimerId = TIMER_ID_NONE;
return true;
}
return false;
}
prepareNewConnection(ctrlMail) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`prepareNewConnection() -- コントローラ( ${ctrlMail} )の情報が見つかりませんでした.`, LogLevels.INFO);
return null;
}
targetCtrlInfo.clearSignalingLog();
targetCtrlInfo.clearSignalingSendMessageQueue();
targetCtrlInfo.refreshLastCommunicationTime();
targetCtrlInfo.peerConnectionState = PeerStates.SIGNALING_STARTED;
const pc_config = {
iceServers: [
{ urls: 'stun:stun.l.google.com:19302' },
]
};
const peer = targetCtrlInfo.createPeerConnection(
pc_config, WbBTGamen.receivedBinMessage, this._onReceivedPeerMessage, this._onChangedChannelState);
if (! peer) {
this._putLog(`prepareNewConnection() -- コントローラ( ${ctrlMail} )とのWebRTCコネクションが作成できませんでした.`, LogLevels.FATAL);
return null;
}
peer.ontrack = (ev) => {
if ((ev.streams) && (ev.streams.length > 0)) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
targetCtrlInfo.gamenTeijiStream = ev.streams[0];
}
Utils.assert((targetCtrlInfo), `prepareNewConnection() - peer.ontrack() - Not found ControllerInfo.  Mail=${ctrlMail}`);
}
};
peer.onicecandidate = (ev) => {
if (ev.candidate) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
if (targetCtrlInfo.signalingSendIceQueue === null) {
this._sendIceCandidate(ctrlMail, ev.candidate);
}
else {
targetCtrlInfo.signalingSendIceQueue.push(ev.candidate);
if (this._signalingType === 0) {
if (targetCtrlInfo.signalingSendIceQueue.length === 1) {
targetCtrlInfo.signalingSendIceQueuingTimerId = this._timer.addTimer(950, false, this._deliverQueuingIceCandidate, ctrlMail);
}
else if (targetCtrlInfo.signalingSendIceQueue.length === Constants.MAX_ICE_COUNT_IN_CANDIDATE_MESSAGE) {
this._deliverQueuingIceCandidate(ctrlMail);
}
}
else if (this._signalingType === 1) {
if (targetCtrlInfo.signalingSendIceQueue.length === 1) {
targetCtrlInfo.signalingSendIceQueuingTimerId = this._timer.addTimer(6950, false, this._deliverQueuingIceCandidate, ctrlMail);
}
}
}
}
}
else {
}
};
peer.onnegotiationneeded = (ev) => {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (targetCtrlInfo) {
this._setCodecVP8(targetCtrlInfo.peerConnection);
targetCtrlInfo.peerConnection.createOffer()
.then((sessionDescription) => {
this._putLog('peerConnection.createOffer() 1 succsess in promise');
return targetCtrlInfo.peerConnection.setLocalDescription(sessionDescription);
})
.then(() => {
this._putLog('peerConnection.createOffer() 2 succsess in promise');
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )とのシグナリング開始(初期SDP送信).`, LogLevels.INFO);
this.sendSdpOffer(true, targetCtrlInfo, targetCtrlInfo.peerConnection.localDescription.sdp);
})
.catch((err) => {
this._putLog(`ERROR: peer.onnegotiationneeded()` + ((err) ? ` : ${err.message || err}` : ''), LogLevels.FATAL);
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )とのシグナリング開始失敗(授業参加拒否で初期SDP送信).`, LogLevels.INFO);
this.sendSdpOffer(false, targetCtrlInfo, null);
});
}
else {
this._putLog(`peer.onnegotiationneeded() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
}
};
peer.onicecandidateerror = (ev) => {
if ((ev.errorCode) && (ev.errorCode === 701)) {
}
else {
this._putLog('ICE Candidate ERROR: ' + JSON.stringify(ev), LogLevels.INFO);
}
};
peer.onsignalingstatechange = () => {
this._putLog(`peer.onsignalingstatechange - Signaling State=${peer.signalingState}`, this._cData.getTraceLogLevel(true));
};
peer.oniceconnectionstatechange = () => {
this._putLog(`peer.oniceconnectionstatechange - ICE Connection State=${peer.iceConnectionState}`, this._cData.getTraceLogLevel(true));
};
peer.onicegatheringstatechange = () => {
this._putLog(`peer.onicegatheringstatechange - ICE Gathering State=${peer.iceGatheringState}`, this._cData.getTraceLogLevel(true));
};
peer.onconnectionstatechange = () => {
this._putLog(`peer.onconnectionstatechange - Connection State=${peer.connectionState}`, this._cData.getTraceLogLevel(true));
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
Utils.assert((targetCtrlInfo), `prepareNewConnection() - peer.onconnectionstatechange() - Not found ControllerInfo.  Mail=${ctrlMail}`);
if (targetCtrlInfo) {
if (peer.connectionState === 'connecting') {
if (targetCtrlInfo.peerConnectionState !== PeerStates.SIGNALING_FAILED) {
if (targetCtrlInfo.peerConnectionState !== PeerStates.SIGNALING_STARTED) {
this._putLog(`Connection Stateの想定外変化を検出.  ${targetCtrlInfo.peerConnectionState} -->  ${peer.connectionState}`, LogLevels.INFO);
}
targetCtrlInfo.peerConnectionState = PeerStates.SIGNALING;
}
}
else if (peer.connectionState === 'connected') {
if (targetCtrlInfo.peerConnectionState === PeerStates.CONNECTED) {
this._putLog(`コントローラ( ${ctrlMail} )とのP2P通信が一時的に切断しましたが復帰しました.`, LogLevels.FATAL);
}
else {
if (targetCtrlInfo.peerConnectionState !== PeerStates.SIGNALING) {
this._putLog(`Connection Stateの想定外変化を検出.  ${targetCtrlInfo.peerConnectionState} -->  ${peer.connectionState}`, LogLevels.INFO);
}
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} ) Connection State -->  ${peer.connectionState}`, LogLevels.INFO);
}
}
else if (peer.connectionState === 'disconnected') {
}
else if (peer.connectionState === 'failed') {
if (targetCtrlInfo.peerConnectionState === PeerStates.SIGNALING) {
this._putLog(`コントローラ( ${targetCtrlInfo.mailAddress} )とのシグナリング接続失敗のため、Firebaseのみで通信します.`, LogLevels.INFO);
targetCtrlInfo.peerConnectionState = PeerStates.ENTRUST_FIREBASE;
targetCtrlInfo.clearSignalingSendMessageQueue();
targetCtrlInfo.clearSignalingLog();
targetCtrlInfo.isFirebaseJunshi = (targetCtrlInfo.compareProtocolVersion(1, 4) >= 0);
this._cAux.notifyChangedClientStatus();
this._sendLatestClientState(targetCtrlInfo.mailAddress);
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ConnectedController',
mailAddress: targetCtrlInfo.mailAddress,
isP2P: false
});
}
else if (targetCtrlInfo.peerConnectionState === PeerStates.CONNECTED) {
this._stopConnectionAsync(targetCtrlInfo.mailAddress, 'P2Pの接続状態からの切断')
.then(() => {
if (this._cData.connectedCtrlInfos.length === 0) {
this._putLog('コントローラ切断検出により接続中のコントローラが無くなったため、再接続処理フェーズに入ります...', LogLevels.INFO);
this._stopWatchAvailableTime();
this.offlineFirebase(() => {
this._cData.onlineNotificationState = 0;
this._cData.isConnectingFirebase = true;
this._cAux.notifyChangedClientStatus();
this._putLog('再接続の試みを開始します...', LogLevels.INFO);
this._notifyJoinLobbyFirebase();
});
}
});
}
}
}
};
targetCtrlInfo.activeTabJunshiCanvas = document.createElement('canvas');
targetCtrlInfo.activeTabJunshiCanvas.width = 32;
targetCtrlInfo.activeTabJunshiCanvas.height = 18;
targetCtrlInfo.activeTabJunshiCanvasAspectRatio = targetCtrlInfo.activeTabJunshiCanvas.width / targetCtrlInfo.activeTabJunshiCanvas.height;
targetCtrlInfo.activeTabJunshiStream = targetCtrlInfo.activeTabJunshiCanvas.captureStream();
Utils.addPeerVideoStream(peer, targetCtrlInfo.activeTabJunshiStream);
targetCtrlInfo.appliedActiveTabJunshiWidth = 0;
targetCtrlInfo.appliedActiveTabJunshiAspectRatio = 0;
targetCtrlInfo.appliedMaxPeerVideoFrameRate = 0;
Utils.setVideoStreamConstraints(targetCtrlInfo.activeTabJunshiStream,
targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvasAspectRatio, (result) => {
if (result) {
targetCtrlInfo.appliedActiveTabJunshiWidth = targetCtrlInfo.activeTabJunshiCanvas.width;
targetCtrlInfo.appliedActiveTabJunshiAspectRatio = targetCtrlInfo.activeTabJunshiCanvasAspectRatio;
}
});
return peer;
}
getSigConfigInfoAsync() {
this._putLog('Called getSigConfigInfoAsync()', this._cData.getTraceLogLevel(true));
return new Promise(async (resolve) => {
try {
let waitCount = 0;
while (window.navigator.onLine === false) {
waitCount++;
if (waitCount > 5) {
resolve(-2);
return;
}
if (! this._cData.isWaitingBrowserOnline) {
this._cData.isWaitingBrowserOnline = true;
this._cAux.notifyChangedClientStatus();
}
await new Promise((resolve2) => this._timer.addTimer(950, false, resolve2));
}
this._cData.isWaitingBrowserOnline = false;
this._cAux.notifyChangedClientStatus();
let storage = await ApiWrappers.readSessionStorageDataAsync({
SignedUserEmail: null,
DomainSystemId: null,
});
WbSigLib.getInfo(storage.SignedUserEmail, storage.DomainSystemId, null, (result) => {
if ((result) && (result.res === 0)) {
const sigConfig = this._extractSigConfig(result);
if (sigConfig === null) {
this._putLog('****  シグナリング設定情報の取得失敗.  該当データなし', LogLevels.INFO);
resolve(-9);
}
else {
this._putLog(`****  シグナリング設定情報の取得成功.  ( ${JSON.stringify(sigConfig)} )`, LogLevels.INFO);
resolve(sigConfig);
}
}
else if (result.res === 1) {
const message = Utils.getLocaleMessage('msg_unregisteredDomain');
this._putLog(message, LogLevels.FATAL);
resolve(-1);
}
else if (result.res === 2) {
resolve(-2);
}
else {
const message = Utils.getLocaleMessage('msg_signalingServerAbnormal') + `  (${((result) && ('res' in result)) ? result.res : ''})`;
this._putLog(message, LogLevels.FATAL);
if (this.getLastSigLibLogMessage().includes('Failed get ManageDb instance')) {
resolve(-10);
}
else {
resolve(-9);
}
}
});
}
catch (err) {
const errorMsg = 'ERROR - getSigConfigInfoAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve(-9);
}
});
};
connectFirebase() {
this._putLog('Called connectFirebase()', this._cData.getTraceLogLevel(true));
this.clearReconnectFirebaseTimer();
if (this._cData.isConnectingFirebase) {
try {
if (! this._cData.isInitializedSigLib) {
if (window.navigator.onLine === false) {
if (this._cData.isConnectingFirebase) {
if (! this._cData.isWaitingBrowserOnline) {
this._cData.isWaitingBrowserOnline = true;
this._putLog('ブラウザがオンライン状態になるまで、シグナリングサーバライブラリの初期化を遅延します.', LogLevels.INFO);
}
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(1000, false, () => { this.connectFirebase(); });
}
return;
}
this._cData.isWaitingBrowserOnline = false;
this._putLog('ブラウザはオンライン状態です.', this._cData.getTraceLogLevel());
this._domainSystemId = null;
this._signalingType = null;
ApiWrappers.readLocalStorageDataAsync({
DomainSystemId: null,
ClientSigType: null,
})
.then((storage) => {
if ((storage.DomainSystemId === null) || (storage.ClientSigType === null)) {
if (! this._cData.isWaitingExtensionPolicy) {
this._cData.isWaitingExtensionPolicy = true;
this._putLog('ドメイン管理者がポリシー設定したデータにアクセスできるまで、シグナリングサーバライブラリの初期化を遅延します.', LogLevels.INFO);
}
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(10000, false, () => { this.connectFirebase(); });
if (! this._cData.isShowedWaitPolicyWindow) {
this._cData.isShowedWaitPolicyWindow = true;
ApiWrappers.createWindowAsync({
url: `${chrome.runtime.getURL(PageHtmlNames.CLIENT_KICKER)}?target=waitPolicy`,
focused : false,
type: 'popup', state: 'normal',
left: 0, top: 0, width: 140, height: 64
}).then(() => {});
}
ApiWrappers.readSessionStorageValueAsync({ TimeOfRequestedCheckExtensionPolicy: 0 })
.then((timeValue) => {
const nowValue = window.performance.now();
const elapsedTime = Math.trunc(nowValue - timeValue);
if (elapsedTime > 190000) {
this._putLog(`拡張機能ポリシー設定変更チェックを要求します.  performance.now=${nowValue}`, this._cData.getTraceLogLevel());
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'CheckExtensionPolicy' })
.then(() => {
return ApiWrappers.saveSessionStorageDataAsync({ TimeOfRequestedCheckExtensionPolicy: nowValue });
});
}
});
return;
}
this._cData.isWaitingExtensionPolicy = false;
this._domainSystemId = storage.DomainSystemId;
this._signalingType = storage.ClientSigType;
this._putLog(`シグナリング方式に タイプ${this._signalingType} を適用します.`, LogLevels.INFO);
return Promise.resolve()
.then(() => {
if (this._failedConnectSigLibCounter < 2) {
return this._cAux.flashClientCorePageAsync(true, 200);
}
})
.then(() => {
WbSigLib.releaseSigLibDatabase();
this._putLog(`シグナリングサーバライブラリを初期化します. (initializeWbSigLib) ${this._domainSystemId}`, LogLevels.INFO);
WbSigLib.initializeWbSigLib(false, this._cData.signedUserEmail, this._domainSystemId, this._onReceivedFirebaseMessage, (result) => {
this._putLog(`****  initializeWbSigLib()からのコールバック  result=${JSON.stringify(result)})`, LogLevels.INFO);
if (this._cData.isChangedDomainSystemId) {
this._reloadClient('4F', 'ポリシー設定のドメイン識別IDの変更');
return;
}
if (! result) {
this._cData.isConnectingFirebase = false;
this._cData.failedInitializeSigLibCounter = Constants.MAX_RETRY_WHEN_INITIALIZE_SIGLIB_FAILED;
this._disableClient();
const message = Utils.getLocaleMessage('msg_signalingServerAbnormal');
this._putLog(message, LogLevels.FATAL);
return;
}
if (result.res === 0) {
if (this._cData.isInitializedSigLib) {
this._putLog('初期化済みであるシグナリングサーバライブラリからの初期化完了コールバックを無視しました.', LogLevels.INFO);
return;
}
if (! this._cData.isConnectingFirebase) {
this._putLog('Firebaseとの接続処理キャンセルによりシグナリングサーバライブラリからの初期化完了コールバックを無視しました.', LogLevels.INFO);
WbSigLib.releaseSigLibDatabase();
return;
}
this._cData.isInitializedSigLib = true;
this._cData.failedInitializeSigLibCounter = 0;
this._putLog('****  シグナリングサーバライブラリの初期化成功', LogLevels.INFO);
this._cData.isVerifyingSigConfig = true;
WbSigLib.getInfo(this._cData.signedUserEmail, this._domainSystemId, null, async (result) => {
const sigConfig = this._extractSigConfig(result);
if (sigConfig !== null) {
this._putLog(`****  シグナリング設定情報の取得成功.  ( ${JSON.stringify(sigConfig)} )`, LogLevels.INFO);
if (! this._cData.isConnectingFirebase) {
this._putLog('Firebaseとの接続処理キャンセルによりオンライン通知送信を取りやめました.', this._cData.getTraceLogLevel());
WbSigLib.releaseSigLibDatabase();
this._cData.isInitializedSigLib = false;
this._cAux.notifyChangedClientStatus();
return;
}
this._cAux.notifyChangedClientStatus();
if (typeof WbSigLib.getNetConnectState === 'function') {
const fnWaitSigLibNetConnectAsync = async () => {
const maxRetryCount = 20;
let retryCount;
for (retryCount = 0; retryCount < maxRetryCount; retryCount++) {
if (WbSigLib.getNetConnectState())  break;
if (retryCount === 0) {
this._putLog('Firebaseによるネットワーク接続の検出待ち中です.', LogLevels.INFO);
}
await new Promise((resolve) => this._timer.addTimer(450, false, resolve));
}
if (retryCount >= maxRetryCount) {
this._putLog('Firebaseによるネットワークの接続検出が確認できませんでした.', LogLevels.INFO);
}
};
fnWaitSigLibNetConnectAsync().then(() => { setTimeout(this.connectFirebase, 0); });
}
else {
this.connectFirebase();
}
}
else {
this._putLog(`****  シグナリング設定情報の取得エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
WbSigLib.releaseSigLibDatabase();
if (this._failedConnectSigLibCounter < 10)  this._failedConnectSigLibCounter++;
this._cData.isInitializedSigLib = false;
if (this._cData.isConnectingFirebase) {
this._putLog('シグナリングサーバライブラリのシグナリング設定情報取得エラーにより再接続をスケジュールしました.', this._cData.getTraceLogLevel());
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(Constants.FIREBASE_RECONNECT_INTERVAL, false, () => { this.connectFirebase(); });
}
}
});
}
else if (result.res === 1) {
this._cData.failedInitializeSigLibCounter = Constants.MAX_RETRY_WHEN_INITIALIZE_SIGLIB_FAILED;
this._cData.isConnectingFirebase = false;
this._disableClient();
const message = Utils.getLocaleMessage('msg_unregisteredDomain');
LogManager.putLogAsync(message, LogLevels.FATAL)
.finally(() => {
this._cAux.notifyChangedClientStatus();
ApiWrappers.removeLocalStorageDataAsync('HasRightToUseMarker').then(() => {});
this._stopClient();
});
}
else if (result.res === 2) {
const message = Utils.getLocaleMessage('msg_couldNotConnectServer');
this._putLog(message, LogLevels.INFO);
if (this._failedConnectSigLibCounter < 10)  this._failedConnectSigLibCounter++;
this._cData.failedInitializeSigLibCounter = 0;
if (this._cData.isConnectingFirebase) {
this._putLog('シグナリングサーバライブラリのサーバー接続エラーにより再接続をスケジュールしました.', this._cData.getTraceLogLevel());
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(Constants.FIREBASE_RECONNECT_INTERVAL, false, () => { this.connectFirebase(); });
}
else {
this._putLog('サーバー接続エラーが発生しましたがFirebaseとの接続処理中ではないため再接続をスケジュールしません.', this._cData.getTraceLogLevel());
}
}
else {
const message = Utils.getLocaleMessage('msg_signalingServerAbnormal') + `  (${((result) && ('res' in result)) ? result.res : ''})`;
this._putLog(message, LogLevels.FATAL);
this._cData.failedInitializeSigLibCounter++;
if (this._cData.isConnectingFirebase) {
if (this._cData.failedInitializeSigLibCounter < Constants.MAX_RETRY_WHEN_INITIALIZE_SIGLIB_FAILED) {
this._putLog(`シグナリングサーバライブラリの初期化異常により再試行(${this._cData.failedInitializeSigLibCounter + 1}回目)をスケジュールしました.`, LogLevels.INFO);
this._cData.reconnectFirebaseTimerId = this._timer.addTimer(
(Constants.FIREBASE_RECONNECT_INTERVAL * this._cData.failedInitializeSigLibCounter), false, () => { this.connectFirebase(); });
}
else {
this._cData.isConnectingFirebase = false;
this._disableClient();
this._putLog('シグナリングサーバライブラリの初期化異常により、クライアントは利用できません.', LogLevels.FATAL);
}
}
}
});
});
});
}
else {
this._notifyJoinLobbyFirebase();
}
}
catch (err) {
const errorMsg = 'ERROR - connectFirebase()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
}
}
else {
if (this._cData.isChangedDomainSystemId) {
this._reloadClient('4G', 'ポリシー設定のドメイン識別IDの変更');
return;
}
}
}
offlineFirebase(callback=null) {
try {
this.clearJuageFailedStartCounterResetTimer();
if (this._cData.isInitializedSigLib) {
this._putLog('setOnDisconnect()を取り消します.', LogLevels.INFO);
WbSigLib.setOnDisconnect(this._cData.signedUserEmail, null);
}
if ((this._cData.onlineNotificationState === 3) || (this._cData.onlineNotificationState === 1)) {
this._putLog('オフライン通知(leave_lobby)を送信します.', LogLevels.INFO);
const message = {
type: 'leave_lobby',
mail: this._cData.signedUserEmail
};
WbSigLib.emitTo(null, message, (result) => {
if ((result) && (result.res === 0)) {
this._putLog('****  オフライン通知(leave_lobby) 送信成功', LogLevels.INFO);
}
else {
this._putLog(`****  オフライン通知(leave_lobby) 送信エラー  (${((result) && ('res' in result)) ? result.res : ''})`, LogLevels.INFO);
}
this._cData.onlineNotificationState = 0;
this._cAux.notifyChangedClientStatus();
if (callback)  callback(true);
});
}
else {
if (callback)  callback(true);
}
}
catch (err) {
const errorMsg = 'ERROR - offlineFirebase()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
if (callback)  callback(false);
}
}
watchSignalingCtrl() {
if (this._cData.watchSignalingCtrlTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._cData.watchSignalingCtrlTimerId);
this._cData.watchSignalingCtrlTimerId = TIMER_ID_NONE;
}
if (this._cData.isWatchSignalingCtrl) {
if (this._cData.connectedCtrlInfos.length > 0) {
try {
let timeoutedCtrlIMailAddresses = [];
this._cData.connectedCtrlInfos.forEach((info) => {
switch (info.peerConnectionState) {
case PeerStates.SIGNALING_STARTED:
case PeerStates.SIGNALING:
if (info.elapsedLastCommunication >= Constants.TIMEOUT_SIGNALING) {
info.peerConnectionState = PeerStates.SIGNALING_FAILED;
timeoutedCtrlIMailAddresses.push(info.mailAddress);
}
break;
}
});
timeoutedCtrlIMailAddresses.forEach((ctrlMail) => {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信がタイムアウトしました.`, LogLevels.FATAL);
if (this._cData.debugTraceLevel === TraceLevels.UNSET) {
this._putSignalingLog(ctrlMail);
}
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if ((targetCtrlInfo) && (! targetCtrlInfo.isAbortedSignaling)) {
targetCtrlInfo.isAbortedSignaling = true;
const startClassEntryTime = targetCtrlInfo.startClassEntryTime;
this._stopConnectionAsync(ctrlMail, 'シグナリング通信タイムアウト')
.then(() => {
CountManager.incrementAsync(`FailedStart#${ctrlMail}#${startClassEntryTime}`)
.then((count) => {
this._putLog(`コントローラ( ${ctrlMail} )の授業開始失敗カウンタを ${count} にインクリメントしました.`, this._cData.getTraceLogLevel());
if (count <= Constants.MAX_RETRY_WHEN_SIGNALING_FAILED) {
if (count === 1) {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラー検出(1回目)により、クライアントコアページを再作成します.`, LogLevels.INFO);
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'CreateClientCorePage' }).then(()=>{});
}
else {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラー検出(${count}回目)により、クライアントのリロードを 2秒後にスケジュールします.`, LogLevels.INFO);
this._timer.addTimer(1950, false, this._reloadClient, '4H', 'シグナリング通信エラー<Timeout>検出');
}
}
else {
this._putLog(`コントローラ( ${ctrlMail} )とのシグナリング通信エラーの検出が ${count}回継続したため、シグナリングの再試行を断念しました.`, LogLevels.INFO);
}
});
});
}
});
if (timeoutedCtrlIMailAddresses.length > 0) {
this._leaveClasswork(true);
}
if (this._cData.isWatchSignalingCtrl) {
this._cData.watchSignalingCtrlTimerId = this._timer.addTimer(
Constants.WATCH_SIGNALING_CTRL_INTERVAL, false, () => { this.watchSignalingCtrl(); });
}
}
catch (err) {
const errorMsg = 'ERROR - watchSignalingCtrl()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
}
}
}
}
sendFirebaseMessage(ctrlMail, message, callback) {
try {
const logSendMessage = this._makeLogStringCommMessage(message);
this._putLog(`コントローラ( ${ctrlMail} )にFirebaseメッセージを送信...  MSG: ${logSendMessage}`, LogLevels.INFO);
const target = { target: ctrlMail };
WbSigLib.emitTo(target, message, callback);
}
catch (err) {
const errorMsg = 'ERROR - sendFirebaseMessage()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
if (callback)  callback();
}
}
sendSdpOffer(isJoin, targetCtrlInfo, sdp=null) {
ApiWrappers.readSessionStorageValueAsync({ IsEnabledClient: false })
.then((isEnabledClient) => {
if (isEnabledClient) {
let message = {
type: 'offer',
join: isJoin,
mail: this._cData.signedUserEmail,
pver: this._cData.clientVersion,
cver: COMM_PROTOCOL_VERSION,
btver: WbBTGamen.getSupportedBTVer()
};
if (isJoin) {
message.sdp = sdp;
}
this._enqueueSendSignalingMessage(targetCtrlInfo, message);
}
});
}
}
