"use strict";
export class WbBTGamen {
static initialize(isController, receivedGamenCallback) {
if ((typeof isController === 'boolean') &&
(receivedGamenCallback) && (typeof receivedGamenCallback === 'function')) {
WbBTGamen._stData.isController = isController;
WbBTGamen._stData.memberInfos.splice(0);
WbBTGamen._stData.receivedGamenCallbackMethod = receivedGamenCallback;
WbBTGamen._stData.idelSendMemberStacker.splice(0);
WbBTGamen._stData.waitSendMemberStacker.splice(0);
WbBTGamen._stData.senderActivityStates.splice(0);
for (let i = 0; i < WbBTGamen._MAX_SENDER_COUNT; i++) {
WbBTGamen._stData.senderActivityStates.push(false);
}
WbBTGamen._stData.activeSenderCount = 0;
WbBTGamen._stData.isInitialized = true;
return true;
}
return false;
}
static terminate() {
WbBTGamen._stData.memberInfos.splice(0);
WbBTGamen._stData.receivedGamenCallbackMethod = null;
WbBTGamen._stData.newestControllerChunks = null;
WbBTGamen._stData.idelSendMemberStacker.splice(0);
WbBTGamen._stData.waitSendMemberStacker.splice(0);
WbBTGamen._stData.senderActivityStates.splice(0);
WbBTGamen._stData.activeSenderCount = 0;
WbBTGamen._stData.isInitialized = false;
}
static getSupportedBTVer() {
return WbBTGamen._SUPPORTED_BT_VERSIONS.join();
}
static testAvailableBTVer(partnerBTVer) {
const partnerVers = (partnerBTVer || '').split(',');
for (const v of WbBTGamen._SUPPORTED_BT_VERSIONS) {
if (partnerVers.includes(v)) {
return v;
}
}
return '';
}
static addMember(email, peerSendChannel, btver) {
if (! WbBTGamen._stData.isInitialized)  return false;
if (! WbBTGamen._SUPPORTED_BT_VERSIONS.includes(btver))  return false;
if ((email) && (typeof email === 'string') &&
(peerSendChannel) && (peerSendChannel instanceof RTCDataChannel)) {
let memberIndex = WbBTGamen._stData.memberInfos.findIndex(v => v.email === email);
if (memberIndex === -1) {
const memberInfo = {
email: email,
btver: btver,
isActiveSend: false,
sendingChannel: peerSendChannel,
frameCode: -1,
chunkNumber: -1,
imageBase64: '',
};
if (! WbBTGamen._stData.isController) {
memberInfo.newestSourceImageWidth = 1;
memberInfo.newestSourceImageHeight = 1;
memberInfo.newestSourceImageCheckSums = [];
memberInfo.newestImageEncodeLevel = -1;
memberInfo.newestImageSendTime = new Date(0);
memberInfo.newestFrameCode = 0;
memberInfo.newestChunks = null;
}
memberIndex = WbBTGamen._stData.memberInfos.push(memberInfo) - 1;
}
else {
const memberInfo = WbBTGamen._stData.memberInfos[memberIndex];
if (memberInfo.sendingChannel !== null) {
return false;
}
memberInfo.isActiveSend = false;
memberInfo.sendingChannel = peerSendChannel;
memberInfo.frameCode = -1;
memberInfo.chunkNumber = -1;
memberInfo.imageBase64 = '';
}
if (! WbBTGamen._stData.isController) {
WbBTGamen._stData.memberInfos[memberIndex].isActiveSend = true;
WbBTGamen._stData.idelSendMemberStacker.push(memberIndex);
}
return true;
}
return false;
}
static removeMember(email) {
const memberIndex = WbBTGamen._stData.memberInfos.findIndex(v => v.email === email);
if (memberIndex !== -1) {
WbBTGamen._stData.memberInfos[memberIndex].isActiveSend = false;
if (WbBTGamen._stData.memberInfos[memberIndex].sendingChannel) {
WbBTGamen._stData.memberInfos[memberIndex].sendingChannel.onbufferedamountlow = null;
WbBTGamen._stData.memberInfos[memberIndex].sendingChannel = null;
}
let pos1 = WbBTGamen._stData.idelSendMemberStacker.indexOf(memberIndex);
if (pos1 !== -1) {
WbBTGamen._stData.idelSendMemberStacker.splice(pos1, 1);
}
let pos2 = WbBTGamen._stData.waitSendMemberStacker.indexOf(memberIndex);
if (pos2 !== -1) {
WbBTGamen._stData.waitSendMemberStacker.splice(pos2, 1);
}
return true;
}
return false;
}
static receivedBinMessage(email, data) {
try {
if (! WbBTGamen._stData.isInitialized) {
throw new Error(`invalid called.`);
}
let memberInfo = WbBTGamen._stData.memberInfos.find((v) => v.email === email);
if (! memberInfo) {
throw new Error(`not member.  email=${email}`);
}
if ((!(data instanceof ArrayBuffer)) || (data.byteLength <= 10)) {
throw new Error(`received data error.  email=${email}`);
}
const uint8Chunk = new Uint8Array(data);
const dvChunkHeader = new DataView(data, 0, 10);
let imageFormat = '';
if (dvChunkHeader.getUint16(0, true) === WbBTGamen._CHUNK_HEADER_PNG)  imageFormat = 'png';
else if (dvChunkHeader.getUint16(0, true) === WbBTGamen._CHUNK_HEADER_JPEG)  imageFormat = 'jpeg';
else throw new Error(`received data header error.  email=${email}`);
const dataChunkedSize = dvChunkHeader.getUint16(2, true);
const dataFrameCode = dvChunkHeader.getUint16(4, true);
const dataChunkCount = dvChunkHeader.getUint16(6, true);
const dataChunkNumber = dvChunkHeader.getUint16(8, true);
if (data.byteLength !== (dataChunkedSize + 10)) {
throw new Error(`received data chunk size error.  email=${email}  data.byteLength=${data.byteLength}`);
}
const tempNowTime = new Date();
if (dataChunkNumber === 1) {
memberInfo.frameCode = dataFrameCode;
memberInfo.chunkNumber = dataChunkNumber;
memberInfo.imageBase64 = `data:image/${imageFormat};base64,` + btoa(String.fromCharCode(...uint8Chunk.subarray(10)));
memberInfo.startTime = tempNowTime;
memberInfo.binSize = dataChunkedSize;
}
else {
if ((dataFrameCode === memberInfo.frameCode) && (dataChunkNumber === (memberInfo.chunkNumber + 1))) {
memberInfo.chunkNumber = dataChunkNumber;
memberInfo.imageBase64 += btoa(String.fromCharCode(...uint8Chunk.subarray(10)));
memberInfo.binSize += dataChunkedSize;
}
else {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0020)) {
console.log(`WbBTGamen.receivedBinMessage() > ${email} からの異常なチャンクデータを破棄しました.  Frame=${dataFrameCode}  dataChunkNumber=${dataChunkNumber}`);
}
memberInfo.frameCode = 0;
memberInfo.chunkNumber = 0;
memberInfo.imageBase64 = '';
memberInfo.binSize = 0;
return;
}
}
if (dataChunkNumber === dataChunkCount) {
if (WbBTGamen._stData.receivedGamenCallbackMethod) {
const elapsedTime = tempNowTime.getTime() - memberInfo.startTime.getTime();
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0010)) {
console.log(`WbBTGamen.receivedBinMessage() > ${email} からのFrame( ${memberInfo.frameCode} ) 画像受信完了.  Base64Len=${memberInfo.imageBase64.length}  Time=${elapsedTime}ms`);
}
const gamenData = {
email: memberInfo.email,
frameCode: memberInfo.frameCode,
imageBase64: memberInfo.imageBase64,
binSize: memberInfo.binSize,
time: elapsedTime
}
WbBTGamen._stData.receivedGamenCallbackMethod(gamenData);
memberInfo.frameCode = 0;
memberInfo.imageBase64 = '';
memberInfo.binSize = 0;
}
}
}
catch (err) {
const errorMsg = 'WbBTGamen.receivedBinMessage() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static selectSendTargetMembers(emails) {
try {
if ((! WbBTGamen._stData.isInitialized) || (! WbBTGamen._stData.isController)) {
throw new Error(`invalid called.`);
}
if ((emails) && Array.isArray(emails)) {
for (let memberIndex = 0; memberIndex < WbBTGamen._stData.memberInfos.length; memberIndex++) {
const memberInfo = WbBTGamen._stData.memberInfos[memberIndex];
const isSend = emails.includes(memberInfo.email);
if (isSend !== memberInfo.isActiveSend) {
memberInfo.isActiveSend = isSend;
if (memberInfo.isActiveSend) {
WbBTGamen._stData.idelSendMemberStacker.push(memberIndex);
}
else {
let pos1 = WbBTGamen._stData.idelSendMemberStacker.indexOf(memberIndex);
if (pos1 !== -1) {
WbBTGamen._stData.idelSendMemberStacker.splice(pos1, 1);
}
let pos2 = WbBTGamen._stData.waitSendMemberStacker.indexOf(memberIndex);
if (pos2 !== -1) {
WbBTGamen._stData.waitSendMemberStacker.splice(pos2, 1);
}
}
}
}
}
else {
WbBTGamen._stData.memberInfos.forEach((info) => {
info.isActiveSend = false;
});
WbBTGamen._stData.idelSendMemberStacker.splice(0);
WbBTGamen._stData.waitSendMemberStacker.splice(0);
}
}
catch (err) {
const errorMsg = 'WbBTGamen.selectSendTargetMembers() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static sendGamenToClient(targetGamenCanvas, qualityAdjustment=0, sizeNoticeCallback=null) {
try {
if ((! WbBTGamen._stData.isInitialized) || (! WbBTGamen._stData.isController)) {
throw new Error(`invalid called.`);
}
let imageEncodeLevel = WbBTGamen._IMAGE_ENCODE_HIGH_LEVEL;
if (qualityAdjustment !== 0) {
imageEncodeLevel = Math.round((Math.min(100, Math.max(5, ((imageEncodeLevel * 100) + Math.round(qualityAdjustment)))))) / 100;
}
const workCanvas = new OffscreenCanvas(targetGamenCanvas.width, targetGamenCanvas.height);
const ctx = workCanvas.getContext('2d');
ctx.drawImage(targetGamenCanvas, 0, 0);
const checkSums = WbBTGamen._computeImageCheckSums(workCanvas);
const tempNowTime = new Date();
const elapsedTime = tempNowTime.getTime() - WbBTGamen._stData.newestControllerImageSendTime.getTime();
if ((elapsedTime < WbBTGamen._MAX_IMAGE_SEND_INTERVAL) &&
(imageEncodeLevel === WbBTGamen._stData.newestControllerImageEncodeLevel) &&
(WbBTGamen._compareSourceImageInfo(workCanvas.width, workCanvas.height, checkSums,
WbBTGamen._stData.newestControllerSourceImageWidth, WbBTGamen._stData.newestControllerSourceImageHeight,
WbBTGamen._stData.newestControllerSourceImageCheckSums))) {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0002)) {
console.log(`WbBTGamen.sendGamenToClient() > 画像が前回Frame( ${WbBTGamen._stData.newestControllerFrameCode} )の同画像であるため送信スキップ.`);
}
return;
}
WbBTGamen._stData.newestControllerSourceImageWidth = workCanvas.width;
WbBTGamen._stData.newestControllerSourceImageHeight = workCanvas.height;
WbBTGamen._stData.newestControllerSourceImageCheckSums = checkSums;
WbBTGamen._stData.newestControllerImageEncodeLevel = imageEncodeLevel;
WbBTGamen._stData.newestControllerImageSendTime = tempNowTime;
WbBTGamen._canvasToBlobAsync(workCanvas, imageEncodeLevel)
.then((blob) => {
return (blob) ? blob.arrayBuffer() : Promise.resolve(null);
})
.then((buffer) => {
if (buffer) {
if (typeof sizeNoticeCallback === 'function') {
setTimeout(() => {
sizeNoticeCallback({
binSize: buffer.byteLength,
quality: imageEncodeLevel
});
}, 0);
}
WbBTGamen._sendToClient(buffer, (imageEncodeLevel !== 0));
}
});
}
catch (err) {
const errorMsg = 'WbBTGamen.sendGamenToClient() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static sendBase64GamenToClient(imageBase64) {
try {
if ((! WbBTGamen._stData.isInitialized) || (! WbBTGamen._stData.isController)) {
throw new Error('invalid called.');
}
let isJpegImage;
if (imageBase64.startsWith('data:image/jpeg;base64,')) {
isJpegImage = true;
}
else if (imageBase64.startsWith('data:image/png;base64,')) {
isJpegImage = false;
}
else {
throw new Error('invalid imageBase64.');
}
WbBTGamen._stData.newestControllerSourceImageWidth = -1;
WbBTGamen._stData.newestControllerSourceImageHeight = -1;
WbBTGamen._stData.newestControllerSourceImageCheckSums = [];
WbBTGamen._stData.newestControllerImageEncodeLevel = -1;
WbBTGamen._stData.newestControllerImageSendTime = new Date(0);
let bin = atob(imageBase64.substring((isJpegImage) ? 23 : 22).replace(/^.*,/, ''));
let binArray = new Uint8Array(bin.length);
for (let i = 0; i < bin.length; i++) {
binArray[i] = bin.charCodeAt(i);
}
WbBTGamen._sendToClient(binArray.buffer, isJpegImage);
}
catch (err) {
const errorMsg = 'WbBTGamen.sendBase64GamenToClient() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static sendGamenToController(targetGamenCanvas, reductionRate, email, sizeNoticeCallback=null) {
try {
if ((! WbBTGamen._stData.isInitialized) || (WbBTGamen._stData.isController)) {
throw new Error(`invalid called.`);
}
let targetMemberIndex = -1;
targetMemberIndex = WbBTGamen._stData.memberInfos.findIndex(v => v.email === email);
if (targetMemberIndex === -1) {
throw new Error(`not member.  email=${email}`);
}
const imageEncodeLevel = (reductionRate > 0.2) ? WbBTGamen._IMAGE_ENCODE_HIGH_LEVEL : WbBTGamen._IMAGE_ENCODE_LOW_LEVEL;
const workCanvas = new OffscreenCanvas(targetGamenCanvas.width, targetGamenCanvas.height);
const ctx = workCanvas.getContext('2d');
ctx.drawImage(targetGamenCanvas, 0, 0);
const checkSums = WbBTGamen._computeImageCheckSums(workCanvas);
const tempNowTime = new Date();
const elapsedTime = tempNowTime.getTime() - WbBTGamen._stData.memberInfos[targetMemberIndex].newestImageSendTime.getTime();
if ((elapsedTime < WbBTGamen._MAX_IMAGE_SEND_INTERVAL) &&
(imageEncodeLevel === WbBTGamen._stData.memberInfos[targetMemberIndex].newestImageEncodeLevel) &&
(WbBTGamen._compareSourceImageInfo(workCanvas.width, workCanvas.height, checkSums,
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageWidth,
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageHeight,
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageCheckSums))) {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0002)) {
console.log(`WbBTGamen.sendGamenToController() > ${email} 向けの画像が前回Frame( ${WbBTGamen._stData.memberInfos[targetMemberIndex].newestFrameCode} )の同画像であるため送信スキップ.`);
}
return;
}
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageWidth = workCanvas.width;
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageHeight = workCanvas.height;
WbBTGamen._stData.memberInfos[targetMemberIndex].newestSourceImageCheckSums = checkSums;
WbBTGamen._stData.memberInfos[targetMemberIndex].newestImageEncodeLevel = imageEncodeLevel;
WbBTGamen._stData.memberInfos[targetMemberIndex].newestImageSendTime = tempNowTime;
WbBTGamen._canvasToBlobAsync(workCanvas, imageEncodeLevel)
.then((blob) => {
return (blob) ? blob.arrayBuffer() : Promise.resolve(null);
})
.then((buffer) => {
if ((buffer) && (targetMemberIndex < WbBTGamen._stData.memberInfos.length)) {
const memberInfo = WbBTGamen._stData.memberInfos[targetMemberIndex];
if (memberInfo) {
if (typeof sizeNoticeCallback === 'function') {
setTimeout(() => {
sizeNoticeCallback({
binSize: buffer.byteLength,
quality: imageEncodeLevel
});
}, 0);
}
memberInfo.newestFrameCode++;
if (memberInfo.newestFrameCode >= 0x10000) {
memberInfo.newestFrameCode = 1;
}
WbBTGamen._stData.memberInfos[targetMemberIndex].newestChunks =
WbBTGamen._makeChunks(buffer, (imageEncodeLevel !== 0), memberInfo.newestFrameCode);
}
}
const index = WbBTGamen._stData.idelSendMemberStacker.indexOf(targetMemberIndex);
if (index !== -1) {
WbBTGamen._stData.idelSendMemberStacker.splice(index, 1);
WbBTGamen._stData.waitSendMemberStacker.push(targetMemberIndex);
WbBTGamen._procSend();
}
});
}
catch (err) {
const errorMsg = 'WbBTGamen.sendGamenToController() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static _sendToClient(buffer, isJpegImage) {
try {
if (! (buffer instanceof ArrayBuffer)) {
throw new Error(`buffer is not ArrayBuffer.`);
}
WbBTGamen._stData.newestControllerFrameCode++;
if (WbBTGamen._stData.newestControllerFrameCode >= 0x10000) {
WbBTGamen._stData.newestControllerFrameCode = 1;
}
WbBTGamen._stData.newestControllerChunks =
WbBTGamen._makeChunks(buffer, isJpegImage, WbBTGamen._stData.newestControllerFrameCode);
const idelMembers = WbBTGamen._stData.idelSendMemberStacker.splice(0);
if (idelMembers.length > 0) {
WbBTGamen._stData.waitSendMemberStacker = WbBTGamen._stData.waitSendMemberStacker.concat(idelMembers);
WbBTGamen._procSend();
}
}
catch (err) {
const errorMsg = 'WbBTGamen._sendToClient() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static _makeChunks(buffer, isJpegImage, frameCode) {
const chunks = [];
const binArray = new Uint8Array(buffer);
const size = binArray.length;
const chunkCount = Math.ceil(size / WbBTGamen._CHUNK_MTU);
let chunkNumber = 0;
let start = 0;
while (start < size) {
chunkNumber++;
const end = Math.min(size, start + WbBTGamen._CHUNK_MTU);
const chunkedSize = end - start;
const chunk = new ArrayBuffer(chunkedSize + 10);
const uint8Chunk = new Uint8Array(chunk);
uint8Chunk.set(binArray.subarray(start, end), 10);
const dvChunkHeader = new DataView(chunk, 0, 10);
dvChunkHeader.setUint16(0, ((isJpegImage) ? WbBTGamen._CHUNK_HEADER_JPEG : WbBTGamen._CHUNK_HEADER_PNG), true);
dvChunkHeader.setUint16(2, chunkedSize, true);
dvChunkHeader.setUint16(4, frameCode, true);
dvChunkHeader.setUint16(6, chunkCount, true);
dvChunkHeader.setUint16(8, chunkNumber, true);
chunks.push(chunk);
start = end;
}
return chunks;
}
static _procSend() {
try {
if ((WbBTGamen._stData.waitSendMemberStacker.length > 0) &&
(WbBTGamen._stData.activeSenderCount < WbBTGamen._MAX_SENDER_COUNT)) {
const targetSenderIndex = WbBTGamen._stData.senderActivityStates.findIndex(state => (! state));
if (targetSenderIndex !== -1) {
const targetMemberIndex = WbBTGamen._stData.waitSendMemberStacker.shift();
WbBTGamen._stData.senderActivityStates[targetSenderIndex] = true;
WbBTGamen._stData.activeSenderCount++;
WbBTGamen._startSendChunkData(WbBTGamen._makeSendParam(targetMemberIndex))
.then((sentFrameCode) => {
if (WbBTGamen._stData.isInitialized) {
WbBTGamen._stData.senderActivityStates[targetSenderIndex] = false;
WbBTGamen._stData.activeSenderCount--;
if (WbBTGamen._stData.memberInfos[targetMemberIndex].isActiveSend) {
let isIdelSend = false;
if (WbBTGamen._stData.isController) {
if ((sentFrameCode === -1) || (sentFrameCode === WbBTGamen._stData.newestControllerFrameCode)) {
isIdelSend = true;
}
}
else {
if ((sentFrameCode === -1) || (sentFrameCode === WbBTGamen._stData.memberInfos[targetMemberIndex].newestFrameCode)) {
isIdelSend = true;
}
}
if (isIdelSend) {
WbBTGamen._stData.idelSendMemberStacker.push(targetMemberIndex);
}
else {
WbBTGamen._stData.waitSendMemberStacker.push(targetMemberIndex);
}
WbBTGamen._procSend();
}
}
});
WbBTGamen._procSend();
}
}
}
catch (err) {
const errorMsg = 'WbBTGamen._procSend() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
}
}
static _makeSendParam(memberIndex) {
let memberInfo = WbBTGamen._stData.memberInfos[memberIndex];
let currentChunks;
let sendParam;
if (WbBTGamen._stData.isController) {
currentChunks = WbBTGamen._stData.newestControllerChunks.slice();
sendParam = {
email: memberInfo.email,
memberIndex: memberIndex,
sendingChannel: memberInfo.sendingChannel,
chunks: currentChunks,
frameCode: WbBTGamen._stData.newestControllerFrameCode,
};
}
else {
currentChunks = memberInfo.newestChunks.slice();
sendParam = {
email: memberInfo.email,
memberIndex: memberIndex,
sendingChannel: memberInfo.sendingChannel,
chunks: currentChunks,
frameCode: memberInfo.newestFrameCode,
};
}
if (WbBTGamen._DEBUG_LOG_MASK & 0x0001) {
let tempSize = 0;
for (let i = 0; i < currentChunks.length; i++) {
const dvChunkHeader = new DataView(currentChunks[i], 0, 10);
tempSize += dvChunkHeader.getUint16(2, true);
}
sendParam.imageSize = tempSize;
}
return sendParam;
}
static _startSendChunkData(sendParam) {
return new Promise((resolve) => {
if (('bufferedAmountLowThreshold' in sendParam.sendingChannel) && ('onbufferedamountlow' in sendParam.sendingChannel)) {
sendParam.startTime = new Date();
sendParam.sendingChannel.bufferedAmountLowThreshold = (WbBTGamen._stData.isController) ? 2048 : 0;
sendParam.sendingChannel.onbufferedamountlow = () => {
WbBTGamen._sendChunkData(resolve, sendParam);
};
WbBTGamen._sendChunkData(resolve, sendParam);
}
else {
resolve(-1);
}
});
}
static _sendChunkData(resolve, sendParam) {
try {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0004)) {
console.log(`WbBTGamen._sendChunkData() > CALLED   Mail=${sendParam.email}  Frame=${sendParam.frameCode}  chunks.length=${sendParam.chunks.length}`);
}
if ((! WbBTGamen._stData.isInitialized) || (! WbBTGamen._stData.memberInfos[sendParam.memberIndex].isActiveSend)) {
sendParam.sendingChannel.onbufferedamountlow = null;
resolve(-1);
return;
}
if ((!(sendParam.sendingChannel instanceof RTCDataChannel)) ||
(sendParam.sendingChannel.readyState !== 'open') || (sendParam.chunks.length === 0)) {
sendParam.sendingChannel.onbufferedamountlow = null;
resolve(-1);
return;
}
const bufferedAmount = sendParam.sendingChannel.bufferedAmount;
if (bufferedAmount > sendParam.sendingChannel.bufferedAmountLowThreshold) {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0004)) {
console.log(`*******  WbBTGamen._sendChunkData() > ${sendParam.email} 向けのFrame( ${sendParam.frameCode} ) 送信前の bufferedAmount=${bufferedAmount}`);
}
return;
}
let chunk = sendParam.chunks.shift();
try {
sendParam.sendingChannel.send(chunk);
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0002)) {
console.log(`WbBTGamen._sendChunkData() > ${sendParam.email} 向けのFrame( ${sendParam.frameCode} ) データ送信.  Size=${chunk.byteLength}`);
}
if (sendParam.chunks.length === 0) {
if ((WbBTGamen._DEBUG_LOG_MASK & 0x0001)) {
const tempNowTime = new Date();
const elapsedTime = tempNowTime.getTime() - sendParam.startTime.getTime();
console.log(`WbBTGamen._sendChunkData() > ${sendParam.email} 向けのFrame( ${sendParam.frameCode} ) 画像送信完了.  Size=${sendParam.imageSize}  Time=${elapsedTime}ms`);
}
sendParam.sendingChannel.onbufferedamountlow = null;
resolve(sendParam.frameCode);
}
}
catch (err) {
const errorMsg = `WbBTGamen._sendChunkData() > ERROR ${sendParam.email} 向けの送信失敗.` + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
sendParam.sendingChannel.onbufferedamountlow = null;
resolve(-1);
}
}
catch (err) {
const errorMsg = 'WbBTGamen._sendChunkData() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
if ((sendParam) && (sendParam.sendingChannel)) {
sendParam.sendingChannel.onbufferedamountlow = null;
}
resolve(-1);
}
}
static _computeImageCheckSums(canvas) {
const checkSums = [];
try {
let partitionedRanges;
if ((canvas.width <= 24) || (canvas.height <= 18)) {
partitionedRanges = [{ xs: 0, xe: canvas.width - 1, ys: 0, ye: canvas.height - 1 }];
}
else {
const quarterWidth = Math.floor((canvas.width + 3) / 4);
const quarterHeight = Math.floor((canvas.height + 3) / 4);
partitionedRanges = [
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 3), ye: canvas.height - 1 },
];
}
const ctx = canvas.getContext('2d');
const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
const dataView = new DataView(imageData.data.buffer, 0, imageData.data.byteLength);
for (const range of partitionedRanges) {
let sum32 = 0;
for (let y = range.ys; y <= range.ye; y++) {
let x = range.xs;
if ((x & 1) !== (y & 1))  x++;
while (x <= range.xe) {
let val = dataView.getUint32((y * (imageData.width * 4)) + (x * 4), true);
if (val === 0) {
val = ((y % 11) + 1) * ((x % 13) + 1);
}
else {
val *= ((y % 11) + 1) * ((x % 13) + 1);
}
sum32 += val;
if (sum32 >= 4294967296) {
sum32 -= 4294967296;
}
x += 2;
}
}
checkSums.push(sum32);
}
}
catch (err) {
const errorMsg = 'WbBTGamen._computeImageCheckSums() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
checkSums.length = 0;
}
return checkSums;
}
static _compareSourceImageInfo(nowWidth, nowHeight, nowCheckSums, lastWidth, lastHeight, lastCheckSums) {
if ((nowWidth < 0) || (lastWidth < 0) || (nowWidth !== lastWidth)) {
return false;
}
if ((nowHeight < 0) || (lastHeight < 0) || (nowHeight !== lastHeight)) {
return false;
}
if ((nowCheckSums.length === 0) || (lastCheckSums.length === 0) || (nowCheckSums.length !== lastCheckSums.length)) {
return false;
}
for (let i = 0; i < nowCheckSums.length; i++) {
if (nowCheckSums[i] !== lastCheckSums[i]) {
return false;
}
}
return true;
}
static _canvasToBlobAsync(canvas, encodeLevel) {
return new Promise((resolve) => {
try {
const mimeType = (encodeLevel === 0) ? 'image/png' : 'image/jpeg';
canvas.convertToBlob({ type: mimeType, quality: encodeLevel })
.then((blob) => {
resolve(blob);
})
.catch((err) => {
const errorMsg = 'WbBTGamen._canvasToBlobAsync() > convertToBlob ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
resolve(null);
});
}
catch (err) {
const errorMsg = 'WbBTGamen._canvasToBlobAsync() > ERROR' + ((err) ? ` : ${err.message || err}` : '');
console.log(errorMsg);
resolve(null);
}
});
}
}
WbBTGamen._MAX_SENDER_COUNT = 16;
WbBTGamen._MAX_IMAGE_SEND_INTERVAL = 5900;
WbBTGamen._CHUNK_HEADER_PNG = 0x6731;
WbBTGamen._CHUNK_HEADER_JPEG = 0x6732;
WbBTGamen._CHUNK_MTU = 65526;
WbBTGamen._IMAGE_ENCODE_HIGH_LEVEL = 0.80;
WbBTGamen._IMAGE_ENCODE_LOW_LEVEL = 0.60;
WbBTGamen._SUPPORTED_BT_VERSIONS = ['1'];
WbBTGamen._stData = {
isInitialized: false,
isController: false,
memberInfos: [],
receivedGamenCallbackMethod: null,
newestControllerSourceImageWidth: -1,
newestControllerSourceImageHeight: -1,
newestControllerSourceImageCheckSums: [],
newestControllerImageEncodeLevel: -1,
newestControllerImageSendTime: new Date(0),
newestControllerFrameCode: 0,
newestControllerChunks: null,
idelSendMemberStacker: [],
waitSendMemberStacker: [],
senderActivityStates: [],
activeSenderCount: 0,
};
WbBTGamen._DEBUG_LOG_MASK = 0x0000;
