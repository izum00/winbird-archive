"use strict";
const JSFILEVER_utils = '3.1.3.1001';
class FlexibleMessageInfo {
constructor(messageHtml, messageColor='white', verticalPercent=50, maxFontPercent=10) {
this._messageHtml = messageHtml;
this._messageColor = messageColor;
this._verticalPercent = verticalPercent;
this._maxFontPercent = maxFontPercent;
}
get messageHtml() {
return this._messageHtml;
}
get messageColor() {
return this._messageColor;
}
get verticalPercent() {
return this._verticalPercent;
}
get maxFontPercent() {
return this._maxFontPercent;
}
}
class Utils {
static _isSkipCheckProgramFileVersion = null;
static assert(assertion, failureMsg) {
if (! assertion) {
if (typeof failureMsg === 'string') {
LogManager.putLog(`Assertion failed: ${failureMsg}`, LogLevels.FATAL);
chrome.storage.session.get({ DebugTraceLevel: TraceLevels.UNSET }, (storage) => {
if ((! chrome.runtime.lastError) && (storage?.DebugTraceLevel !== TraceLevels.UNSET)) {
if (typeof window !== 'undefined') {
window.alert(`Assertion failed\n\n${failureMsg}`);
}
}
});
}
}
}
static isSkipCheckProgramFileVersion() {
if (Utils._isSkipCheckProgramFileVersion === null) {
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
const verParts = currentVersion.split('.');
if ((verParts.length === 4) && (verParts[3].length > 3) && (verParts[3].slice(-3, -2) === '8')) {
Utils._isSkipCheckProgramFileVersion = true;
}
else {
Utils._isSkipCheckProgramFileVersion = false;
}
}
catch {
Utils._isSkipCheckProgramFileVersion = false;
}
}
return Utils._isSkipCheckProgramFileVersion;
}
static getUseFontFamiry() {
return '"Lato", "Noto Sans JP", "ヒラギノ角ゴ ProN", "Hiragino Kaku Gothic ProN","メイリオ", "Meiryo", "ＭＳ Ｐゴシック", "MS PGothic", "sans-serif"';
}
static postBroadcastMessage(bcName, message) {
const fnPostMessage = (name, message) => {
if (typeof name === 'string') {
try {
const bc = new BroadcastChannel(name);
if (Array.isArray(message)) {
message.forEach(msg => bc.postMessage(msg));
}
else {
bc.postMessage(message);
}
bc.close();
}
catch (err) {}
}
};
if (Array.isArray(bcName)) {
bcName.forEach(name => fnPostMessage(name, message));
}
else {
fnPostMessage(bcName, message);
}
}
static getLocaleMessage() {
let message = '';
if ((arguments.length > 0) && (arguments.length <= 10)) {
const messageName = arguments[0];
let substitutions = [];
for(let i = 1; i < arguments.length; i++){
substitutions.push(arguments[i]);
}
if (substitutions.length == 0) {
message = chrome.i18n.getMessage(messageName);
}
else {
message = chrome.i18n.getMessage(messageName, substitutions);
}
}
return message;
}
static getJstDateTime(dateTime=null) {
const time = new Date((dateTime) ? dateTime.getTime() : Date.now());
time.setUTCHours(time.getUTCHours() + 9);
const result = {
year: time.getUTCFullYear(),
month: time.getUTCMonth() + 1,
date: time.getUTCDate(),
hours: time.getUTCHours(),
minutes: time.getUTCMinutes(),
seconds: time.getUTCSeconds(),
milliSec: time.getUTCMilliseconds()
};
return result;
}
static getJstDateTimeStr(includeSeparator, dateTime=null) {
const timeObj = Utils.getJstDateTime(dateTime);
const year = String(timeObj.year).padStart(4, '0');
const month = String(timeObj.month).padStart(2, '0');
const date = String(timeObj.date).padStart(2, '0');
const hours = String(timeObj.hours).padStart(2, '0');
const minutes = String(timeObj.minutes).padStart(2, '0');
const seconds = String(timeObj.seconds).padStart(2, '0');
const milliSec = String(timeObj.milliSec).padStart(3, '0');
if (includeSeparator) {
return `${year}/${month}/${date} ${hours}:${minutes}:${seconds}.${milliSec}`;
}
return `${year}${month}${date}${hours}${minutes}${seconds}${milliSec}`;
}
static truncateStr(str, maxLength, isTruncatedMark=true) {
if ((typeof str !== 'string') || (maxLength < 1)) {
return '';
}
if (str.length > maxLength) {
if (isTruncatedMark) {
return str.substring(0, maxLength) + ' ...';
}
return str.substring(0, maxLength);
}
return str;
}
static escapeHtmlStr(str) {
if (typeof str === 'string') {
const escapeHtmlRegex = /[&'`"<> ]/g;
const escapeHtmlPatterns = {
'&': '&amp;',
"'": '&#x27;',
'`': '&#x60;',
'"': '&quot;',
'<': '&lt;',
'>': '&gt;',
' ': '&nbsp;',
};
return str.replace(escapeHtmlRegex, (match) => { return escapeHtmlPatterns[match]; });
}
return '';
}
static unescapeHtmlStr(str) {
if (typeof str === 'string') {
const unescapeHtmlRegex = /&(lt|gt|quot|#x27|#x60|nbsp|amp);/gi;
const unescapeHtmlPatterns = {
'&lt;'   : '<',
'&gt;'   : '>',
'&quot;' : '"',
'&#x27;' : '\'',
'&#x60;' : '`',
'&nbsp;' : ' ',
'&amp;'  : '&'
};
return str.replace(unescapeHtmlRegex, (match) => { return unescapeHtmlPatterns[match]; });
}
return '';
}
static sortObjectProperty(obj) {
const sorted = Object.entries(obj).sort();
for (let i in sorted) {
const v = sorted[i][1];
if (typeof v === 'object') {
sorted[i][1] = Utils.sortObjectProperty(v);
}
}
return sorted;
}
static trimUrlAnkerParameter(url) {
const indexParameter = url.indexOf('?');
if (indexParameter !== -1) {
url = url.substring(0, indexParameter);
}
else {
const indexAnchor = url.indexOf('#');
if (indexAnchor !== -1) {
url = url.substring(0, indexAnchor);
}
}
return url;
}
static classifyUrl(url, isConvLowerCase) {
let result = null;
if (typeof url === 'string') {
if (isConvLowerCase) {
url = url.toLowerCase();
}
url = Utils.trimUrlAnkerParameter(url);
const parts = url.match(/^(https|http|chrome|chrome-untrusted|chrome-extension)?:\/{2,}(.*?)(?:\/|\?|#|$)/);
if ((parts) && (parts.length === 3)) {
let urlSchema = parts[1] + '://';
let hostDomain = parts[2];
if (isConvLowerCase) {
hostDomain = parts[2].replace(/[Ａ-Ｚａ-ｚ０-９]/g, (s) => {
return String.fromCharCode(s.charCodeAt(0) - 0xFEE0);
});
}
let followingPath = url.substring(parts[1].length + parts[2].length + 3);
result = [];
result.push(urlSchema);
result.push(hostDomain);
result.push(followingPath);
}
}
return result;
}
static addFlexibleMessage(divParent, info) {
Utils.assert(divParent, 'Utils.addFlexibleMessage() Parameter error.');
Utils.assert((typeof info === 'object'), 'Utils.addFlexibleMessage() Parameter error.');
const parentWidth = divParent.clientWidth;
const parentHeight = divParent.clientHeight;
const maxWidth = Math.trunc(parentWidth * 0.8);
const fontSize = Utils.computeBastFontSize(maxWidth, parentHeight, (info.messageHtml || ''), info.maxFontPercent);
const tempLines = info.messageHtml.replace(/<br>/gi, '\n').split('\n');
let groupHeight = 0;
for (let i = 0; i < tempLines.length; i++) {
tempLines[i] = tempLines[i].trim();
if (tempLines[i].indexOf('<ruby>') === -1) {
groupHeight += fontSize * 1.48;
}
else {
groupHeight += fontSize * 1.88;
}
}
const y = Math.trunc((parentHeight * info.verticalPercent / 100) - (groupHeight / 2));
const divGroup = document.createElement('div');
divGroup.style.position = 'absolute';
divGroup.style.width = '100%';
divGroup.style.top = `${y}px`;
divGroup.style.textAlign = 'center';
tempLines.forEach(line => {
let paragraph = document.createElement('p');
paragraph.style.fontFamily = Utils.getUseFontFamiry();
paragraph.style.fontSize = `${fontSize}px`;
paragraph.style.fontWeight = 'bold';
paragraph.style.color = info.messageColor;
paragraph.innerHTML = line;
divGroup.appendChild(paragraph);
});
divParent.appendChild(divGroup);
}
static removeFlexibleMessage(divParent) {
while (divParent.firstChild) {
divParent.removeChild(divParent.firstChild);
}
}
static computeBastFontSize(areaWidth, areaHeight, message, maxFontPercent=12) {
const splitRubyParts = (html) => {
let parts = [];
let tempHtml = html;
while (tempHtml.length > 0) {
let index1 = tempHtml.indexOf('<ruby>');
if (index1 === -1) {
parts.push(tempHtml);
break;
}
let index2 = tempHtml.indexOf('</ruby>');
if (index2 === -1) {
break;
}
if (index1 > 0) {
parts.push(tempHtml.substring(0, index1));
}
let rubyHtml = tempHtml.substring(index1 + 6, index2);
tempHtml = tempHtml.substring(index2 + 7);
let index3 = rubyHtml.indexOf('<rt>');
while (index3 !== -1) {
let index4 = rubyHtml.indexOf('</rt>');
if ((index4 === -1) || (index4 < index3)) {
rubyHtml = rubyHtml.substring(0, index3);
break;
}
rubyHtml = rubyHtml.substring(0, index3) + rubyHtml.substring(index4 + 5);
index3 = rubyHtml.indexOf('<rt>');
}
while (rubyHtml.length > 0) {
let index5 = rubyHtml.indexOf('<rb>');
if (index5 === -1) {
parts.push(rubyHtml);
break;
}
if (index5 > 0) {
parts.push(rubyHtml.substring(0, index5));
rubyHtml = rubyHtml.substring(index5);
}
let index6 = rubyHtml.indexOf('</rb>');
if (index6 === -1) {
break;
}
parts.push(rubyHtml.substring(0, index6));
rubyHtml = rubyHtml.substring(index6 + 5);
}
}
return parts;
};
if ((typeof message !== 'string') || (message.length === 0)) {
return 10;
}
let lines = [];
if (message.indexOf('<ruby>') === -1) {
const tempLines = message.split('\n');
for (let lineIndex = 0; lineIndex < tempLines.length; lineIndex++) {
lines.push(Utils.unescapeHtmlStr(tempLines[lineIndex].trim()));
}
}
else {
const tempLines = message.split('<br>');
let rubyLineCount = 0;
for (let lineIndex = 0; lineIndex < tempLines.length; lineIndex++) {
const htmlLine = tempLines[lineIndex].trim();
if (htmlLine.indexOf('<ruby>') === -1) {
lines.push(Utils.unescapeHtmlStr(htmlLine));
}
else {
rubyLineCount++;
let realLine = '';
const rubyParts = splitRubyParts(htmlLine);
for (let i = 0; i < rubyParts.length; i++) {
if (rubyParts[i].startsWith('<rb>')) {
realLine = realLine.concat(rubyParts[i].substring(4));
}
else {
realLine = realLine.concat(Utils.unescapeHtmlStr(rubyParts[i]));
}
}
lines.push(Utils.unescapeHtmlStr(realLine));
}
}
if (rubyLineCount > 0) {
maxFontPercent = maxFontPercent * (1 - (0.3 * (rubyLineCount / tempLines.length)));
}
}
const ctx = document.createElement('canvas').getContext('2d');
let textFontSize = Math.trunc(Math.min(areaWidth, areaHeight) * maxFontPercent / 100);
let longestLineStr;
ctx.beginPath();
ctx.textAlign = 'left';
ctx.textBaseline = 'middle';
if (lines.length == 1) {
longestLineStr = lines[0];
}
else {
ctx.font = `bold ${textFontSize}px ${Utils.getUseFontFamiry()}`;
let tempMaxAreaWidth = 0;
lines.forEach(lineStr => {
const width = ctx.measureText(lineStr).width;
if (tempMaxAreaWidth < width) {
tempMaxAreaWidth = width;
longestLineStr = lineStr;
}
});
}
for (let textAreaWidth = areaWidth + 1; textAreaWidth > areaWidth; textFontSize -= 4) {
ctx.font = `bold ${textFontSize}px ${Utils.getUseFontFamiry()}`;
textAreaWidth = ctx.measureText(longestLineStr).width;
}
return textFontSize;
}
static resizeImage(sourceImage, resizeWidth) {
let resizedImage = null;
try {
let sourceWidth = sourceImage.width || 0;
let sourceHeight = sourceImage.height || 0;
if ((sourceWidth <= 0) || (sourceHeight <= 0)) {
throw new Error('source image size error.');
}
const zoomedCanvas = new OffscreenCanvas(sourceWidth, sourceHeight);
let zoom = resizeWidth / sourceWidth;
let tempCanvas = new OffscreenCanvas(sourceWidth, sourceHeight);
let tempCtx = tempCanvas.getContext('2d');
tempCtx.drawImage(sourceImage, 0, 0);
if (zoom === 1.0) {
resizedImage = tempCanvas;
}
else {
for (let tempZoom = 1; tempZoom > zoom; ) {
if (zoom >= (tempZoom / 2)) {
tempZoom = zoom;
}
else {
tempZoom /= 2;
}
zoomedCanvas.width = sourceWidth * tempZoom;
zoomedCanvas.height = sourceHeight * tempZoom;
zoomedCanvas.getContext('2d').drawImage(tempCanvas, 0, 0, zoomedCanvas.width, zoomedCanvas.height);
tempCanvas.width = zoomedCanvas.width;
tempCanvas.height = zoomedCanvas.height;
tempCtx.drawImage(zoomedCanvas, 0, 0, tempCanvas.width, tempCanvas.height);
resizedImage = zoomedCanvas;
}
}
if (resizedImage === null) {
throw new Error('resizedImage is null.');
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.resizeImage()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
resizedImage = null;
}
return resizedImage;
}
static transferImage(destCanvas, destContext, sourceImage, sx=0, sy=0, sw=-1, sh=-1, dx=-1, dy=-1, dw=-1, dh=-1) {
try {
const ctx = (destCanvas) ? destCanvas.getContext('2d') : destContext;
if (! ctx) {
throw new Error('Invalid destination.');
}
else if (! sourceImage) {
throw new Error('Invalid source.');
}
else if (sw < 0) {
ctx.drawImage(sourceImage, sx, sy);
}
else if (dx < 0) {
ctx.drawImage(sourceImage, sx, sy, sw, sh);
}
else if (dw < 0) {
ctx.drawImage(sourceImage, sx, sy, sw, sh, dx, dy);
}
else {
ctx.drawImage(sourceImage, sx, sy, sw, sh, dx, dy, dw, dh);
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.transferImage()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
}
static addPeerVideoStream(peerConnection, stream) {
try {
const tracks = stream.getTracks();
if (tracks) {
tracks.forEach((track) => {
peerConnection.addTrack(track, stream);
return true;
});
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.addPeerVideoStream()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
return false;
}
static replacePeerVideoStream(peerConnection, stream) {
try {
const tracks = stream.getTracks();
if (tracks) {
if (tracks.length !== 1) {
throw new Error('ストリームのトラック数の異常.');
}
tracks.forEach((track) => {
const sender = peerConnection.getSenders().find((sdr) => sdr.track.kind === track.kind);
sender.replaceTrack(track).then(() => {});
return true;
});
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.replacePeerVideoStream()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
return false;
}
static setMaxPeerVideoFrameRate(peerConnection, frameRate) {
try {
const sender = peerConnection.getSenders().find((sdr) => sdr.track.kind === 'video');
if (sender) {
const maxFramerate = Math.max(1, Math.trunc(frameRate));
const params = sender.getParameters();
params.encodings.forEach((enc) => {
enc.maxFramerate = maxFramerate;
});
sender.setParameters(params);
return true;
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.setMaxPeerVideoFrameRate()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
return false;
}
static setVideoStreamConstraints(stream, width, aspectRatio, opt_callback=null) {
const track = stream.getVideoTracks()[0];
if (! track) {
LogManager.putLog('ERROR - Utils.setVideoStreamConstraints()  Track not exist.', LogLevels.INFO);
if (opt_callback) {
opt_callback(false);
}
return;
}
const constraints = {
width: { min: 16, ideal: width },
height: { min: 16, ideal: Math.round(width / aspectRatio) },
aspectRatio: { ideal: aspectRatio }
};
track.applyConstraints(constraints)
.then(() => {
if (opt_callback) {
opt_callback(true);
}
})
.catch((err) => {
const errorMsg = 'ERROR - Utils.setVideoStreamConstraints()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
if (opt_callback) {
opt_callback(false);
}
});
}
static stopVideoStream(stream) {
if (stream !== null) {
try {
const tracks = stream.getTracks();
if (tracks) {
tracks.forEach((track) => {
track.stop();
});
}
}
catch (err) {
const errorMsg = 'ERROR - Utils.stopVideoStream()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
}
}
}
