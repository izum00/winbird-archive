'use strict';
const JSFILEVER_classwork = '3.1.3.1001';
const DisplayModes = Object.freeze({
INITIAL: 0,
WHITESPACE: 1,
CONFIRM_JOIN: 2,
CONFIRM_SCREEN: 3,
SHARED_SCREEN: 4,
});
const TIMEOUT_CONFIRM_JOIN = 30;
const TIMEOUT_CONFIRM_SCREEN_SHARING = 30;
let selfWindowId = WINDOW_ID_NONE;
let selfPageId = 0;
let isCbtMode = false;
let isCbtModeAlwaysDesktopJunshi = false;
let isDeveloperMode = false;
let debugTraceLevel = TraceLevels.UNSET;
let debugTestMode = [0, 0, 0];
let isPrimaryScreen = false;
let isEnabledClickPage = false;
let isEnabledVideoDesktop = false;
let currentDisplayMode = DisplayModes.INITIAL;
let currentFlexibleMessages = [];
let desktopMediaRequestId = 0;
let classworkName = '';
let classworkTeacherName = '';
let noOperationIntervalTimerId = TIMER_ID_NONE;
let confirmJoinElapsedTime = -1;
let confirmScreenElapsedTime = -1;
let escapeCodeIndex = -1;
const putLog = (message, level=LogLevels.DEBUG) => {
LogManager.putLog(`【classwork】${message}`, level);
};
const createInternalMessageListener = () => {
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
try {
if (request.cmd === 'DestroyExistingPage') {
if ((! isCbtMode) || (! isEnabledVideoDesktop)) {
LogManager.putLogAsync(`【classwork】DestroyExistingPage 受諾.  (Page:${selfPageId}  Primary:${isPrimaryScreen}  WindowId:${selfWindowId})`, LogLevels.INFO)
.then(() => {
window.close();
});
return false;
}
}
if (request.cmd === 'ClosePage') {
LogManager.putLogAsync(`【classwork】ClosePage 受諾.  (Page:${selfPageId}  Primary:${isPrimaryScreen}  WindowId:${selfWindowId})`, (debugTraceLevel === TraceLevels.UNSET) ? LogLevels.DEBUG : LogLevels.INFO)
.then(() => {
if ((request.cancelConfirmScreenSharing === true) && (currentDisplayMode === DisplayModes.CONFIRM_SCREEN)) {
return notifyEndConfirmScreenSharingAsync(false);
}
})
.then(() => {
window.close();
});
return false;
}
if (request.cmd === 'ChangedDebugTraceLevel') {
if (typeof request.level === 'number')  debugTraceLevel = Math.min(2, Math.max(0, Math.trunc(request.level)));
return false;
}
if (request.cmd === 'ChangedDebugTestMode') {
if (typeof request.modeA === 'number')  debugTestMode[0] = request.modeA;
if (typeof request.modeB === 'number')  debugTestMode[1] = request.modeB;
if (typeof request.modeC === 'number')  debugTestMode[2] = request.modeC;
return false;
}
}
catch (err) {
const errorMsg = 'ERROR - Internal.onMessage()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
return false;
});
};
const getDebugTestMode = (modeName) => {
const modeKeys = ['A', 'B', 'C'];
const modeKeyIndex = modeKeys.findIndex(item => item === modeName.toUpperCase());
if (modeKeyIndex !== -1) {
return debugTestMode[modeKeyIndex];
}
return 0;
};
const drawTimeoutClock = (lapseRate) => {
try {
const canvasTimer = document.getElementById('canvasTimer');
const clockRadius = Math.trunc(Math.min(canvasTimer.width, canvasTimer.height) / 20);
const ctx = canvasTimer.getContext('2d');
ctx.clearRect(0, 0, canvasTimer.width, canvasTimer.height);
ctx.beginPath();
let centerX = canvasTimer.width - (clockRadius * 3);
let centerY = clockRadius * 4;
ctx.arc(centerX, centerY, clockRadius, (((270 + (360 * Math.max(lapseRate, 0.01))) % 360) * Math.PI / 180), (270 * Math.PI / 180));
ctx.lineTo(centerX, centerY);
ctx.fillStyle = 'white';
ctx.fill();
ctx.beginPath();
ctx.ellipse(centerX, centerY, clockRadius, clockRadius, 0, 0, (Math.PI * 2), false);
ctx.strokeStyle = 'white';
ctx.stroke();
}
catch (err) {
const errorMsg = 'ERROR - drawTimeoutClock()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
}
};
const updateCurrentMessages = () => {
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
Utils.removeFlexibleMessage(divFlexibleMessages);
currentFlexibleMessages.forEach((info) => {
Utils.addFlexibleMessage(divFlexibleMessages, info);
});
updatePageLayout(currentDisplayMode);
};
const clearCurrentMessages = () => {
currentFlexibleMessages.length = 0;
Utils.removeFlexibleMessage(document.getElementById('divFlexibleMessages'));
};
const addCurrentMessage = (message, color, verticalPar, maxFontPer) => {
currentFlexibleMessages.push(new FlexibleMessageInfo(message, color, verticalPar, maxFontPer));
};
const updatePageLayout = (displayMode) => {
try {
if (displayMode === DisplayModes.CONFIRM_JOIN) {
const buttonCancelJoin = document.getElementById('buttonCancelJoin');
const buttonJoin = document.getElementById('buttonJoin');
let fontSize;
fontSize = Utils.computeBastFontSize((buttonCancelJoin.clientWidth * 0.7),
buttonCancelJoin.clientHeight, buttonCancelJoin.innerHTML, 50);
buttonCancelJoin.style.fontSize = `${fontSize}px`;
fontSize = Utils.computeBastFontSize((buttonJoin.clientWidth * 0.7),
buttonJoin.clientHeight, buttonJoin.innerHTML, 50);
buttonJoin.style.fontSize = `${fontSize}px`;
}
if ((displayMode === DisplayModes.CONFIRM_JOIN) || (displayMode === DisplayModes.CONFIRM_SCREEN)) {
const canvasTimer = document.getElementById('canvasTimer');
canvasTimer.width = document.body.clientWidth;
canvasTimer.height = document.documentElement.clientHeight;
}
}
catch (err) {
const errorMsg = 'ERROR - updatePageLayout()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
}
};
const setEscapeCodeListener = (callback) => {
const fnKeyDownEventHandler = (ev) => {
if ((ev.key !== 'Control') && (ev.key !== 'Alt')) {
if (ev.ctrlKey && ev.altKey) {
escapeCodeIndex = (ev.key.toLowerCase() === 'b') ? 0 : -1;
}
else if ((escapeCodeIndex >= 0) && (! ev.ctrlKey) && (! ev.altKey)) {
const keyIndex = 'break'.indexOf(ev.key.toLowerCase());
if (keyIndex == escapeCodeIndex + 1) {
escapeCodeIndex++;
if (escapeCodeIndex === 4) {
escapeCodeIndex = -1;
if (typeof callback === 'function')  callback();
}
}
else if ((keyIndex < 1) || (keyIndex !== escapeCodeIndex)) {
escapeCodeIndex = -1;
}
}
else {
escapeCodeIndex = -1;
}
}
};
document.body.removeEventListener('keydown', fnKeyDownEventHandler);
if (typeof callback === 'function') {
document.body.addEventListener('keydown', fnKeyDownEventHandler);
}
};
const setDisplayMode = (displayMode) => {
try {
currentDisplayMode = displayMode;
const buttonCancelJoin = document.getElementById('buttonCancelJoin');
const buttonJoin = document.getElementById('buttonJoin');
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
if ((currentDisplayMode === DisplayModes.WHITESPACE) ||
(currentDisplayMode === DisplayModes.SHARED_SCREEN)) {
buttonJoin.style.display = 'none';
buttonJoin.disabled = true;
buttonCancelJoin.style.display = 'none';
buttonCancelJoin.disabled = true;
divFlexibleMessages.style.visibility = 'hidden';
document.title = Utils.getLocaleMessage('title_jyugyoShien');
clearCurrentMessages();
setEscapeCodeListener(null);
if (currentDisplayMode === DisplayModes.SHARED_SCREEN) {
ApiWrappers.getCurrentWindowAsync({}, true)
.then((wnd) => {
if (wnd.state === 'minimized') {
return;
}
const updateInfo = {
state: 'minimized',
focused: false
};
return ApiWrappers.updateWindowAsync(wnd.id, updateInfo, true);
})
.catch((err) => {
const errorMsg = 'ERROR - setDisplayMode()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
});
}
}
else if (currentDisplayMode === DisplayModes.CONFIRM_JOIN) {
buttonJoin.style.display = 'inline-block';
buttonJoin.disabled = false;
buttonCancelJoin.style.display = 'inline-block';
buttonCancelJoin.disabled = false;
divFlexibleMessages.style.visibility = 'visible';
document.title = Utils.getLocaleMessage('title_confirmingJoinClasswork');
clearCurrentMessages();
addCurrentMessage(Utils.getLocaleMessage('msg_confirmJoinClasswork'), 'White', 23, 12);
const language = (window.navigator.languages && window.navigator.languages[0]) || window.navigator.language;
if (language.toLowerCase().indexOf('ja') !== -1) {
addCurrentMessage(classworkName, '#A7e0fb', 68, 8);
addCurrentMessage(classworkTeacherName, '#A7e0fb', 80, 9);
}
updateCurrentMessages();
buttonJoin.addEventListener('mousedown', (ev) => {
if ((ev.which === 1) || (ev.which === 3))  joinClasswork();
});
buttonJoin.addEventListener('touchstart', (ev) => {
if (('touches' in ev) && (ev.touches.length === 1))  joinClasswork();
});
buttonCancelJoin.addEventListener('mousedown', (ev) => {
if ((ev.which === 1) || (ev.which === 3))  cancelJoinClasswork();
});
buttonCancelJoin.addEventListener('touchstart', (ev) => {
if (('touches' in ev) && (ev.touches.length === 1))  cancelJoinClasswork();
});
setEscapeCodeListener(() => {
confirmJoinElapsedTime = -1;
stopNoOperationIntervalTimer();
putLog('授業参加確認中に強制脱出操作が行われました.', LogLevels.INFO);
notifyEndConfirmJoinClasswork(false);
});
}
else if (currentDisplayMode === DisplayModes.CONFIRM_SCREEN) {
buttonJoin.style.display = 'none';
buttonJoin.disabled = true;
buttonCancelJoin.style.display = 'none';
buttonCancelJoin.disabled = true;
divFlexibleMessages.style.visibility = 'visible';
document.title = Utils.getLocaleMessage('title_waitingDesktopSharingApproval');
clearCurrentMessages();
addCurrentMessage(Utils.getLocaleMessage('msg_pleaseDesktopSharingApproval'), 'White', 77, 12);
updateCurrentMessages();
confirmScreenSharing();
setEscapeCodeListener(() => {
confirmScreenElapsedTime = -1;
stopNoOperationIntervalTimer();
putLog('デスクトップ画面共有許諾確認中に強制脱出操作が行われました.', LogLevels.INFO);
if (desktopMediaRequestId) {
chrome.desktopCapture.cancelChooseDesktopMedia(desktopMediaRequestId);
desktopMediaRequestId = 0;
}
notifyEndConfirmScreenSharingAsync(false).then(()=>{});
});
}
}
catch (err) {
const errorMsg = 'ERROR - setDisplayMode()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
};
const startNoOperationIntervalTimer = () => {
document.getElementById('canvasTimer').style.visibility = 'visible';
noOperationIntervalTimerId = setInterval(() => {
const buttonCancelJoin = document.getElementById('buttonCancelJoin');
const buttonJoin = document.getElementById('buttonJoin');
if (confirmJoinElapsedTime >= 0) {
if (! buttonCancelJoin.disabled) {
confirmJoinElapsedTime++;
drawTimeoutClock(confirmJoinElapsedTime / TIMEOUT_CONFIRM_JOIN);
if (confirmJoinElapsedTime >= TIMEOUT_CONFIRM_JOIN) {
confirmJoinElapsedTime = -1;
stopNoOperationIntervalTimer();
putLog('授業参加確認がタイムアウトしました.', LogLevels.INFO);
buttonCancelJoin.disabled = true;
buttonJoin.disabled = true;
notifyEndConfirmJoinClasswork(false);
}
}
}
else if (confirmScreenElapsedTime >= 0) {
confirmScreenElapsedTime++;
drawTimeoutClock(confirmScreenElapsedTime / TIMEOUT_CONFIRM_SCREEN_SHARING);
if (confirmScreenElapsedTime >= TIMEOUT_CONFIRM_SCREEN_SHARING) {
confirmScreenElapsedTime = -1;
stopNoOperationIntervalTimer();
putLog('デスクトップ画面共有許諾確認がタイムアウトしました.', LogLevels.INFO);
if (desktopMediaRequestId) {
chrome.desktopCapture.cancelChooseDesktopMedia(desktopMediaRequestId);
desktopMediaRequestId = 0;
}
notifyEndConfirmScreenSharingAsync(false).then(()=>{});
}
}
}, 1000);
};
const stopNoOperationIntervalTimer = () => {
if (noOperationIntervalTimerId !== TIMER_ID_NONE) {
clearInterval(noOperationIntervalTimerId);
noOperationIntervalTimerId = TIMER_ID_NONE;
}
if (confirmJoinElapsedTime > 0) {
confirmJoinElapsedTime = 0;
}
if (confirmScreenElapsedTime > 0) {
confirmScreenElapsedTime = 0;
}
document.getElementById('canvasTimer').style.visibility = 'hidden';
};
const disableUserOperation = (isRemove) => {
if (! isRemove) {
document.addEventListener('mousedown', preventEnevts, { passive: false });
document.addEventListener('mouseenter', preventEnevts, { passive: false });
document.addEventListener('mouseleave', preventEnevts, { passive: false });
document.addEventListener('mousemove', preventEnevts, { passive: false });
document.addEventListener('mouseout', preventEnevts, { passive: false });
document.addEventListener('mouseover', preventEnevts, { passive: false });
document.addEventListener('mouseup', preventEnevts, { passive: false });
document.addEventListener('mousewheel', preventEnevts, { passive: false });
document.addEventListener('touchmove', preventEnevts, { passive: false });
document.oncontextmenu = () => { return false; }
}
else {
document.removeEventListener('mousedown', preventEnevts, { passive: false });
document.removeEventListener('mouseenter', preventEnevts, { passive: false });
document.removeEventListener('mouseleave', preventEnevts, { passive: false });
document.removeEventListener('mousemove', preventEnevts, { passive: false });
document.removeEventListener('mouseout', preventEnevts, { passive: false });
document.removeEventListener('mouseover', preventEnevts, { passive: false });
document.removeEventListener('mouseup', preventEnevts, { passive: false });
document.removeEventListener('mousewheel', preventEnevts, { passive: false });
document.removeEventListener('touchmove', preventEnevts, { passive: false });
document.oncontextmenu = () => { return true; }
}
};
const preventEnevts = (ev) => {
if ('type' in ev) {
if (ev.type === 'touchmove') {
if (('cancelable' in ev) && (ev.cancelable === false)) {
return;
}
}
else if (ev.type === 'mousedown') {
if (isEnabledClickPage) {
isEnabledClickPage = false;
putLog('ページでクリックされました.', LogLevels.INFO);
setTimeout(() => {
ApiWrappers.updateWindowAsync(selfWindowId, { state: 'minimized' }).then(() => {});
}, 500);
}
}
}
ev.preventDefault();
};
const joinClasswork = () => {
if (confirmJoinElapsedTime === -1) {
putLog('タイムアウト後の授業参加確認[参加する]操作を無視しました.', LogLevels.INFO);
return;
}
confirmJoinElapsedTime = -1;
stopNoOperationIntervalTimer();
document.getElementById('buttonCancelJoin').disabled = true;
document.getElementById('buttonJoin').disabled = true;
notifyEndConfirmJoinClasswork(true, 500);
};
const cancelJoinClasswork = () => {
if (confirmJoinElapsedTime === -1) {
putLog('タイムアウト後の授業参加確認[やめる]操作を無視しました.', LogLevels.INFO);
return;
}
confirmJoinElapsedTime = -1;
stopNoOperationIntervalTimer();
document.getElementById('buttonCancelJoin').disabled = true;
document.getElementById('buttonJoin').disabled = true;
notifyEndConfirmJoinClasswork(false, 500);
};
const confirmScreenSharing = () => {
desktopMediaRequestId = chrome.desktopCapture.chooseDesktopMedia(['screen'], (streamId) => {
desktopMediaRequestId = 0;
if ((! isCbtMode) && (confirmScreenElapsedTime === -1)) {
putLog('タイムアウト後のデスクトップ画面共有の許諾を無視しました.', LogLevels.INFO);
}
else {
confirmScreenElapsedTime = -1;
stopNoOperationIntervalTimer();
if (! streamId) {
if ((isCbtMode) && (isCbtModeAlwaysDesktopJunshi)) {
setTimeout(confirmScreenSharing, 0);
}
else {
notifyEndConfirmScreenSharingAsync(false).then(()=>{});
}
}
else {
navigator.mediaDevices.getUserMedia({
audio: false,
video: { mandatory: {
chromeMediaSource: 'desktop',
chromeMediaSourceId: streamId,
maxFrameRate: 8,
}
}
})
.then((stream) => {
document.getElementById("videoDesktop").srcObject = stream;
isEnabledVideoDesktop = true;
setTimeout(() => {
setDisplayMode(DisplayModes.WHITESPACE);
setTimeout(() => {
setDisplayMode(DisplayModes.SHARED_SCREEN);
notifyEndConfirmScreenSharingAsync(true).then(()=>{});
}, 100);
}, 100);
})
.catch((err) => {
const errorMsg = 'ERROR - confirmScreenSharing()  Failured Desktop Track Constraints.' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
notifyEndConfirmScreenSharingAsync(false).then(()=>{});
});
}
}
});
};
const notifyEndConfirmJoinClasswork = (joined, delay=0) => {
setTimeout(() => {
ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true)
.then((clientCoreTabId) => {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'EndConfirmJoinClasswork',
joined: joined
}, true);
})
.then(() => {
})
.catch((err) => {
const errorMsg = 'ERROR - notifyEndConfirmJoinClasswork()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
});
}, delay);
};
const notifyEndConfirmScreenSharingAsync = (permission) => {
return new Promise((resolve) => {
ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true)
.then((clientCoreTabId) => {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'EndConfirmScreenSharing',
permission: permission
}, true);
})
.then(() => {
})
.catch((err) => {
const errorMsg = 'ERROR - notifyEndConfirmScreenSharing()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
resolve();
});
});
};
window.addEventListener('load', async () => {
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verClasswork = (typeof JSFILEVER_classwork === 'string') ? JSFILEVER_classwork : 'Undefined';
if (verClasswork === currentVersion) {
logMsg = `★Program file check <3> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <3> -- [currentVer=${currentVersion}]  classwork.js=${verClasswork}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【classwork】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
try {
let selfPageKey;
let elapsedTime = 0;
const tempIndex = document.location.href.indexOf('?');
if (tempIndex > 0) {
const urlArgs = document.location.href.substring(tempIndex + 1).split('&');
urlArgs.forEach((arg) => {
if (arg.startsWith('pid=')) {
const pid = Number(arg.substring(4));
if (! isNaN(pid))  selfPageId = pid;
}
else if (arg.startsWith('primary=')) {
isPrimaryScreen = (arg.substring(8) === 'true');
}
else if (arg.startsWith('key=')) {
selfPageKey = arg.substring(4);
}
else if (arg.startsWith('elapsed=')) {
const elapsed = Number(arg.substring(8));
if (! isNaN(elapsed))  elapsedTime = Math.max(0, elapsed);
}
});
}
if ((selfPageId === 0) || (! selfPageKey)) {
throw new Error('Invalid url parameter.');
}
if ((isPrimaryScreen) && ((! window.opener) || (window.opener.closed))) {
throw new Error('Not found parent window.');
}
createInternalMessageListener();
let currentWindow = await ApiWrappers.getCurrentWindowAsync({ populate: true }, true);
selfWindowId = currentWindow.id;
let selfTabId = TAB_ID_NONE;
if ((currentWindow.tabs) && (currentWindow.tabs.length > 0)) {
selfTabId = currentWindow.tabs[0].id;
}
if (currentWindow.state !== 'fullscreen') {
const tempWindow = await ApiWrappers.updateWindowAsync(selfWindowId, { state: 'fullscreen' });
Utils.assert((!! tempWindow), 'ERROR updateWindowAsync 失敗.');
}
const storage1 = await ApiWrappers.readLocalStorageDataAsync({
DebugTestModeA: 0,
DebugTestModeB: 0,
DebugTestModeC: 0,
}, true);
const storage2 = await ApiWrappers.readSessionStorageDataAsync({
OsType: OsTypes.UNKNOWN,
IsCbtMode: false,
IsCbtModeAlwaysDesktop: false,
IsDeveloperMode: false,
DebugTraceLevel: TraceLevels.UNSET,
ClassworkPageMode: '',
ClassworkName: '',
ClassworkTeacherName: '',
ClientCoreTabId: TAB_ID_NONE,
}, true);
const msgResponse = await ApiWrappers.sendInternalMsgAsync(false, storage2.ClientCoreTabId, {
cmd: 'ShownClassworkPage',
pageId: selfPageId,
pageKey: selfPageKey,
windowId: selfWindowId,
tabId: selfTabId,
primary: isPrimaryScreen
}, true);
if (msgResponse?.accepted !== true) {
throw new Error('Rejected ShownClassworkPage.');
}
debugTestMode[0] = storage1.DebugTestModeA;
debugTestMode[1] = storage1.DebugTestModeB;
debugTestMode[2] = storage1.DebugTestModeC;
isCbtMode = storage2.IsCbtMode;
isCbtModeAlwaysDesktopJunshi = (storage2.IsCbtMode) && (storage2.IsCbtModeAlwaysDesktop);
isDeveloperMode = storage2.IsDeveloperMode;
debugTraceLevel = storage2.DebugTraceLevel;
classworkName = storage2.ClassworkName;
classworkTeacherName = storage2.ClassworkTeacherName;
isEnabledClickPage = ((isPrimaryScreen) && (storage2.OsType === OsTypes.WINDOWS));
if (selfPageId === 1) {
let programVersionCheckedFlags = await ApiWrappers.readLocalStorageValueAsync({ ProgramVersionCheckedFlags: 0 }) || 0;
if (0 === (programVersionCheckedFlags & 0x04)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x04) | 0x04;
await ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags });
if (! Utils.isSkipCheckProgramFileVersion()) {
await fnCheckProgramFileVersionAsync();
}
}
}
let requestedDisplayMode = DisplayModes.INITIAL;
if (storage2.ClassworkPageMode === 'confirmJoin') {
if (isCbtMode)  throw new Error('confirmJoin when isCbtMode.');
requestedDisplayMode = (isPrimaryScreen) ? DisplayModes.CONFIRM_JOIN : DisplayModes.WHITESPACE;
document.title = Utils.getLocaleMessage('title_confirmingJoinClasswork');
}
else if (storage2.ClassworkPageMode === 'confirmScreen') {
requestedDisplayMode = (isPrimaryScreen) ? DisplayModes.CONFIRM_SCREEN : DisplayModes.WHITESPACE;
document.title = Utils.getLocaleMessage('title_waitingDesktopSharingApproval');
}
else {
setTimeout(() => { window.close(); });
return;
}
document.getElementById('buttonCancelJoin').innerHTML = Utils.getLocaleMessage('msg_cancelJoinClasswork');
document.getElementById('buttonJoin').innerHTML = Utils.getLocaleMessage('msg_joinClasswork');
disableUserOperation(false);
setTimeout(() => {
updatePageLayout(requestedDisplayMode);
setDisplayMode(requestedDisplayMode);
if (requestedDisplayMode === DisplayModes.CONFIRM_JOIN) {
if (! isCbtMode) {
if (elapsedTime < TIMEOUT_CONFIRM_JOIN) {
confirmJoinElapsedTime = elapsedTime;
startNoOperationIntervalTimer();
}
else {
putLog('授業参加確認がタイムアウトしました.', LogLevels.INFO);
notifyEndConfirmJoinClasswork(false);
}
}
}
else if (requestedDisplayMode === DisplayModes.CONFIRM_SCREEN) {
if ((! isCbtMode) || (! isCbtModeAlwaysDesktopJunshi)) {
if (elapsedTime < TIMEOUT_CONFIRM_SCREEN_SHARING) {
confirmScreenElapsedTime = elapsedTime;
startNoOperationIntervalTimer();
}
else {
putLog('デスクトップ画面共有許諾確認がタイムアウトしました.', LogLevels.INFO);
notifyEndConfirmScreenSharingAsync(false).then(()=>{});
}
}
}
window.addEventListener('resize', () => {
updateCurrentMessages();
});
}, 100);
}
catch (err) {
const errorMsg = '【classwork】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
});
window.addEventListener('beforeunload', () => {
if (desktopMediaRequestId) {
chrome.desktopCapture.cancelChooseDesktopMedia(desktopMediaRequestId);
desktopMediaRequestId = 0;
}
confirmJoinElapsedTime = -1;
confirmScreenElapsedTime = -1;
stopNoOperationIntervalTimer();
disableUserOperation(true);
});
window.addEventListener('error', (ev) => {
const errorMsg = '【classwork】WINDOW ERROR (Classwork) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
