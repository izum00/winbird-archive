'use strict';
const JSFILEVER_messenger = '3.1.3.1001';
let selfWindowId = WINDOW_ID_NONE;
let messagerDisplaySize = 0;
let isDeveloperMode = false;
let debugTraceLevel = TraceLevels.UNSET;
let debugTestMode = [0, 0, 0];
let validTouchId = -1;
let thinningOutResizeTimerId = TIMER_ID_NONE;
let isEditingSenderMsg = false;
let appendedMessageDataSeqNo = 0;
const containerIndexes = {};
const putLog = (message, level=LogLevels.DEBUG) => {
LogManager.putLog(`【messenger】${message}`, level);
};
const createBroadcastChannelListener = () => {
var bcReceiver = new BroadcastChannel(BcNames.MESSENGER_PAGE);
bcReceiver.onmessage = (ev) => {
if (ev?.data?.cmd === 'ChangedMessengerData') {
updateHistoryAreaAsync((typeof ev.data.id === 'string') ? ev.data.id : null).then(() => {});
return;
}
if (ev?.data?.cmd === 'ChangedLockedMessengerSend') {
updateSendOperationAreaAsync().then(() => {});
return;
}
};
bcReceiver.onmessageerror = (ev) => {
const errorMsg = 'ERROR - BroadcastChannel.onmessage()' + ((ev) ? ` : ${ev.message || ev}` : '');
putLog(errorMsg, LogLevels.FATAL);
};
};
const createInternalMessageListener = () => {
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
try {
if (request.cmd === 'DestroyExistingPage') {
LogManager.putLogAsync(`【messenger】DestroyExistingPage 受諾.  (WindowId:${selfWindowId})`, LogLevels.INFO)
.then(() => {
window.close();
});
return false;
}
if (request.cmd === 'ChangedDebugTraceLevel') {
if (typeof request.level === 'number')  debugTraceLevel = Math.min(2, Math.max(0, Math.trunc(request.level)));
return false;
}
if (request.cmd === 'ChangedDebugTestMode') {
if (typeof request.modeA === 'number')  debugTestMode[0] = request.modeA;
if (typeof request.modeB === 'number')  debugTestMode[1] = request.modeB;
if (typeof request.modeC === 'number')  debugTestMode[2] = request.modeC;
return false;
}
}
catch (err) {
const errorMsg = 'ERROR - Internal.onMessage()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
return false;
});
};
const getDebugTestMode = (modeName) => {
const modeKeys = ['A', 'B', 'C'];
const modeKeyIndex = modeKeys.findIndex(item => item === modeName.toUpperCase());
if (modeKeyIndex !== -1) {
return debugTestMode[modeKeyIndex];
}
return 0;
};
const convertTimeToHHMM = (timeValue) => {
const time = new Date(timeValue);
return `${String(time.getHours()).padStart(2, '0')}:${String(time.getMinutes()).padStart(2, '0')}`;
};
const changeDisplaySizeAsync = (displaySize) => {
return new Promise((resolve) => {
try {
displaySize = Math.trunc(displaySize % 3);
document.body.classList.remove('bodyFontLarge1', 'bodyFontLarge2');
if (displaySize === 1) {
document.body.classList.add('bodyFontLarge1');
}
else if (displaySize === 2) {
document.body.classList.add('bodyFontLarge2');
}
const divHistoryArea = document.getElementById('divHistoryArea');
divHistoryArea.scrollTo({ top: divHistoryArea.scrollHeight, left: 0, behavior: "smooth" });
if (displaySize === messagerDisplaySize) {
resolve();
return;
}
messagerDisplaySize = displaySize;
ApiWrappers.saveLocalStorageDataAsync({ MessagerDisplaySize: displaySize })
.then(() => {
resolve();
});
}
catch (err) {
const errorMsg = 'ERROR - changeDisplaySizeAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
resolve();
}
});
}
const updateHistoryAreaAsync = (requestId=null) => {
return new Promise((resolve) => {
if (requestId) {
MessengerManager.readAsync(requestId)
.then((result) => {
if (typeof result === 'object') {
const container = document.getElementById('divMsgContainer');
updateMsgContainer(container, requestId, result.msgKind, result.time || 0, result.sender || '');
}
})
.catch((err) => {
const errorMsg = 'ERROR - updateHistoryAreaAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
resolve();
});
}
else {
MessengerManager.readAsync(null, appendedMessageDataSeqNo + 1)
.then((result) => {
if ((Array.isArray(result)) && (result.length)) {
const container = document.getElementById('divMsgContainer');
for (let data of result) {
appendMsgContainer(container, data.id, data.msgKind, data.msg, data.time,data.sender);
}
appendedMessageDataSeqNo = result[result.length-1].seqNo;
const divHistoryArea = document.getElementById('divHistoryArea');
divHistoryArea.scrollTo({ top: divHistoryArea.scrollHeight, left: 0, behavior: "smooth" });
}
})
.catch((err) => {
const errorMsg = 'ERROR - updateHistoryAreaAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
resolve();
});
}
});
};
const updateSendOperationAreaAsync = () => {
return new Promise((resolve) => {
ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true)
.then((clientCoreTabId) => {
if (clientCoreTabId !== TAB_ID_NONE) {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, { cmd: 'GetLockedMessengerOperation' }, true);
}
return null;
})
.then((result) => {
const textSenderMsg = document.getElementById('textSenderMsg');
const buttonSend = document.getElementById('buttonSend');
if ((result) && (textSenderMsg.disabled !== result.isLockedEdit))  textSenderMsg.disabled = result.isLockedEdit;
if ((result) && (buttonSend.disabled !== result.isLockedSend)) {
buttonSend.disabled = result.isLockedSend;
if (result.isLockedSend) {
textSenderMsg.classList.add('msgEditorHidePlaceholder');
}
else {
textSenderMsg.classList.remove('msgEditorHidePlaceholder');
}
}
})
.catch((err) => {
const errorMsg = 'ERROR - updateSendOperationAreaAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
resolve();
});
});
};
const appendMsgContainer = (container, requestId, kind, message, timeValue, name='') => {
try {
const ValidKinds = [MessengerKinds.CONTROLLER, MessengerKinds.CLIENT, MessengerKinds.CLIENT_PENDING, MessengerKinds.CLIENT_ERROR];
if ((message) && (ValidKinds.indexOf(kind) !== -1)) {
const labelHeader = document.createElement('label');
const divBalloon = document.createElement('div');
const divArea = document.createElement('div');
const labelText = document.createElement('label');
if (kind === MessengerKinds.CONTROLLER) {
labelHeader.innerHTML = Utils.escapeHtmlStr(`${name}  (${convertTimeToHHMM(timeValue)})`);
labelText.innerHTML = Utils.escapeHtmlStr(message).replace(/\n/g, '<br>');
labelHeader.className = 'msgHeaderLeft';
divBalloon.className = 'msgBalloonLeft';
divArea.className = 'msgAreaLeft';
labelText.className = 'msgStringLeft';
}
else {
labelText.innerHTML = Utils.escapeHtmlStr(message).replace(/\n/g, '<br>');
switch (kind) {
case MessengerKinds.CLIENT_PENDING:
labelHeader.innerHTML = '&nbsp;';
labelHeader.className = 'msgHeaderRight';
divBalloon.className = 'msgBalloonRight';
divArea.className = 'msgAreaRight msgAreaRightPending';
labelText.className = 'msgStringRight msgStringRightPending';
break;
case MessengerKinds.CLIENT_ERROR:
labelHeader.innerHTML = Utils.escapeHtmlStr(`(${Utils.getLocaleMessage('msg_sendError')})`);
labelHeader.className = 'msgHeaderRight';
divBalloon.className = 'msgBalloonRight';
divArea.className = 'msgAreaRight msgAreaRightError';
labelText.className = 'msgStringRight msgStringRightError';
break;
default:
labelHeader.innerHTML = Utils.escapeHtmlStr(`(${convertTimeToHHMM(timeValue)})`);
labelHeader.className = 'msgHeaderRight';
divBalloon.className = 'msgBalloonRight';
divArea.className = 'msgAreaRight';
labelText.className = 'msgStringRight';
break;
}
}
container.appendChild(labelHeader);
divArea.appendChild(labelText);
divBalloon.appendChild(divArea);
container.appendChild(divBalloon);
containerIndexes[requestId] = container.children.length - 2;
}
}
catch (err) {
const errorMsg = 'ERROR - appendMsgContainer()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
}
};
const updateMsgContainer = (container, requestId, kind, timeValue, name='') => {
try {
const ValidKinds = [MessengerKinds.CONTROLLER, MessengerKinds.CLIENT, MessengerKinds.CLIENT_ERROR];
let containerIndex = -1;
if (requestId in containerIndexes) {
containerIndex = containerIndexes[requestId];
}
if ((ValidKinds.indexOf(kind) !== -1) && (containerIndex >= 0) && (containerIndex < (container.children.length - 1))) {
const labelHeader = container.children[containerIndex];
const divBalloon = container.children[containerIndex + 1];
if ((labelHeader.localName !== 'label') || (divBalloon.localName !== 'div')) {
throw new Error('container is broken.');
}
const divArea = divBalloon.children[0];
const labelText = divArea.children[0];
if (kind === MessengerKinds.CONTROLLER) {
labelHeader.innerHTML = Utils.escapeHtmlStr(`${name}  (${convertTimeToHHMM(timeValue)})`);
}
else if (kind === MessengerKinds.CLIENT) {
labelHeader.innerHTML = Utils.escapeHtmlStr(`(${convertTimeToHHMM(timeValue)})`);
divArea.className = 'msgAreaRight';
labelText.className = 'msgStringRight';
}
else {
labelHeader.innerHTML = Utils.escapeHtmlStr(`(${Utils.getLocaleMessage('msg_sendError')})`);
divArea.className = 'msgAreaRight msgAreaRightError';
labelText.className = 'msgStringRight msgStringRightError';
}
}
}
catch (err) {
const errorMsg = 'ERROR - updateMsgContainer()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
}
};
const onResizeWindow = () => {
const textarea = document.getElementById('textSenderMsg');
if ((textarea.offsetWidth < 400) && (isEditingSenderMsg)) {
document.getElementById("textSenderMsg").blur();
}
if (thinningOutResizeTimerId === TIMER_ID_NONE) {
thinningOutResizeTimerId = setTimeout(() => {
ApiWrappers.getCurrentWindowAsync({}, true)
.then((currentWindow) => {
let updateInfo = {};
if ((currentWindow.state !== 'normal') && (currentWindow.state !== 'minimized')) {
updateInfo.state = 'normal';
}
if (currentWindow.width !== 400) {
updateInfo.width = 400;
}
if (currentWindow.height < 380) {
updateInfo.height = 380;
}
if (Object.keys(updateInfo).length > 0) {
return ApiWrappers.updateWindowAsync(currentWindow.id, updateInfo, true);
}
})
.catch((err) => {
const errorMsg = 'ERROR - onResizeWindow()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
thinningOutResizeTimerId = TIMER_ID_NONE;
});
}, 100);
}
};
const preventEnevts = (ev) => {
try {
if (ev?.type === 'touchmove') {
const touches = ev.changedTouches;
if ((validTouchId !== -1) && (touches.length === 1) && (touches[0].identifier === validTouchId)) {
return;
}
}
else if (ev?.type === 'touchstart') {
const touches = ev.changedTouches;
if ((touches.length === 1) && ((validTouchId === -1) || (validTouchId === touches[0].identifier))) {
validTouchId = touches[0].identifier;
return;
}
}
else if (ev?.type === 'wheel') {
if (! ev.ctrlKey) {
return;
}
}
else if ((ev?.type === 'touchend') || (ev?.type === 'touchcancel')) {
if (validTouchId !== -1) {
const touches = ev.changedTouches;
for (let i = 0; i < touches.length; i++) {
if (touches[i].identifier === validTouchId) {
validTouchId = -1;
return;
}
}
}
}
if (ev?.cancelable !== false) {
ev.preventDefault();
}
}
catch (err) {
console.log('ERROR - preventEnevts()' + ((err) ? ` : ${err.message || err}` : ''));
}
};
window.addEventListener('load', async () => {
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verMessenger = (typeof JSFILEVER_messenger === 'string') ? JSFILEVER_messenger : 'Undefined';
if (verMessenger === currentVersion) {
logMsg = `★Program file check <8> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <8> -- [currentVer=${currentVersion}]  messenger.js=${verMessenger}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【messenger】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
try {
const storage1 = await ApiWrappers.readLocalStorageDataAsync({
ProgramVersionCheckedFlags: 0,
MessagerDisplaySize: 0,
DebugTestModeA: 0,
DebugTestModeB: 0,
DebugTestModeC: 0,
}, true);
const storage2 = await ApiWrappers.readSessionStorageDataAsync({
IsDeveloperMode: false,
DebugTraceLevel: TraceLevels.UNSET,
}, true);
let programVersionCheckedFlags = storage1.ProgramVersionCheckedFlags;
messagerDisplaySize = storage1.MessagerDisplaySize;
debugTestMode[0] = storage1.DebugTestModeA;
debugTestMode[1] = storage1.DebugTestModeB;
debugTestMode[2] = storage1.DebugTestModeC;
isDeveloperMode = storage2.IsDeveloperMode;
debugTraceLevel = storage2.DebugTraceLevel;
if (0 === (programVersionCheckedFlags & 0x80)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x80) | 0x80;
await ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags });
if (! Utils.isSkipCheckProgramFileVersion()) {
await fnCheckProgramFileVersionAsync();
}
}
const entries = performance.getEntriesByType('navigation');
putLog(`メッセンジャーページを${((entries?.length) && (entries[0].type === 'reload')) ? 'リロード' : '表示'}しました.`, LogLevels.INFO);
let currentWindow = await ApiWrappers.getCurrentWindowAsync({ populate: true }, true);
selfWindowId = currentWindow.id;
if (currentWindow?.tabs?.length) {
await chrome.tabs.setZoomSettings(currentWindow.tabs[0].id, { mode: 'disabled' });
}
document.addEventListener('wheel', preventEnevts, { passive: false });
document.addEventListener('touchstart', preventEnevts, { passive: false });
document.addEventListener('touchend', preventEnevts, { passive: false });
document.addEventListener('touchcancel', preventEnevts, { passive: false });
document.addEventListener('touchmove', preventEnevts, { passive: false });
document.oncontextmenu = () => { return false; };
document.body.oncontextmenu = 'return false;';
document.title = Utils.getLocaleMessage('title_messengerPage');
document.getElementById('textSenderMsg').placeholder = Utils.getLocaleMessage('msg_pleaseEnterMessage');
document.getElementById('buttonSend').innerHTML = Utils.getLocaleMessage('msg_sendMessenger');
window.addEventListener('resize', onResizeWindow);
createBroadcastChannelListener();
createInternalMessageListener();
await changeDisplaySizeAsync(messagerDisplaySize);
await updateHistoryAreaAsync();
await updateSendOperationAreaAsync();
document.getElementById('buttonSend').addEventListener('mousedown', (ev) => {
const textSenderMsg = document.getElementById('textSenderMsg');
let message = textSenderMsg.value.trimEnd();
message = message.replace(/\t+/g, ' ');
message = message.replace(/\n+/g, '\n');
if (message.length) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'SendClientMessengerData',
msg: message,
});
}
textSenderMsg.value = '';
});
document.getElementById('buttonChangeSize').addEventListener('mousedown', async (ev) => {
await changeDisplaySizeAsync((messagerDisplaySize + 1) % 3);
});
document.getElementById('textSenderMsg').addEventListener('focus', () => {
if (! isEditingSenderMsg) {
const textarea = document.getElementById('textSenderMsg');
if (textarea.offsetWidth < 400) {
document.getElementById("textSenderMsg").classList.remove('msgEditorEditing0', 'msgEditorEditing1', 'msgEditorEditing2');
if (messagerDisplaySize === 0) {
document.getElementById("textSenderMsg").classList.add('msgEditorEditing0');
document.getElementById("divMain").style.gridTemplateRows = "auto 190px";
}
else if (messagerDisplaySize === 1) {
document.getElementById("textSenderMsg").classList.add('msgEditorEditing1');
document.getElementById("divMain").style.gridTemplateRows = "auto 216px";
}
else if (messagerDisplaySize === 2) {
document.getElementById("textSenderMsg").classList.add('msgEditorEditing2');
document.getElementById("divMain").style.gridTemplateRows = "auto 253px";
}
}
isEditingSenderMsg = true;
}
});
document.getElementById('textSenderMsg').addEventListener('blur', () => {
if (isEditingSenderMsg) {
document.getElementById("textSenderMsg").classList.remove('msgEditorEditing0', 'msgEditorEditing1', 'msgEditorEditing2');
document.getElementById("divMain").style.gridTemplateRows = "auto 130px";
isEditingSenderMsg = false;
}
});
}
catch (err) {
const errorMsg = '【messenger】WINDOW - load()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
});
window.addEventListener('error', (ev) => {
const errorMsg = '【messenger】WINDOW ERROR (Messenger) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
