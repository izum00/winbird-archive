'use strict';
const JSFILEVER_blockedPage = '3.1.3.1001';
let thinningOutResizeTimerId = TIMER_ID_NONE;
let currentFlexibleMessages = [];
const disableUserOperation = (isRemove) => {
if (! isRemove) {
document.addEventListener('mousedown', preventEnevts, { passive: false });
document.addEventListener('mouseenter', preventEnevts, { passive: false });
document.addEventListener('mouseleave', preventEnevts, { passive: false });
document.addEventListener('mousemove', preventEnevts, { passive: false });
document.addEventListener('mouseout', preventEnevts, { passive: false });
document.addEventListener('mouseover', preventEnevts, { passive: false });
document.addEventListener('mouseup', preventEnevts, { passive: false });
document.addEventListener('mousewheel', preventEnevts, { passive: false });
document.addEventListener('touchmove', preventEnevts, { passive: false });
document.oncontextmenu = () => { return false; }
}
else {
document.removeEventListener('mousedown', preventEnevts, { passive: false });
document.removeEventListener('mouseenter', preventEnevts, { passive: false });
document.removeEventListener('mouseleave', preventEnevts, { passive: false });
document.removeEventListener('mousemove', preventEnevts, { passive: false });
document.removeEventListener('mouseout', preventEnevts, { passive: false });
document.removeEventListener('mouseover', preventEnevts, { passive: false });
document.removeEventListener('mouseup', preventEnevts, { passive: false });
document.removeEventListener('mousewheel', preventEnevts, { passive: false });
document.removeEventListener('touchmove', preventEnevts, { passive: false });
document.oncontextmenu = () => { return true; }
}
};
const preventEnevts = (ev) => {
if (('type' in ev) && (ev.type === 'touchmove')) {
if (('touches' in ev) && (ev.touches.length >= 2)) {
ev.preventDefault();
}
}
else {
ev.preventDefault();
}
};
const updateCurrentMessages = () => {
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
Utils.removeFlexibleMessage(divFlexibleMessages);
currentFlexibleMessages.forEach((info) => {
Utils.addFlexibleMessage(divFlexibleMessages, info);
});
};
const clearCurrentMessages = () => {
currentFlexibleMessages.length = 0;
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
Utils.removeFlexibleMessage(divFlexibleMessages);
};
const addCurrentMessage = (message, color, verticalPar, maxFontPer) => {
currentFlexibleMessages.push(new FlexibleMessageInfo(message, color, verticalPar, maxFontPer));
};
const onResizeWindow = () => {
if (thinningOutResizeTimerId === TIMER_ID_NONE) {
thinningOutResizeTimerId = setTimeout(() => {
thinningOutResizeTimerId = TIMER_ID_NONE;
if (currentFlexibleMessages.length > 0) {
updateCurrentMessages();
}
}, 100);
}
};
window.addEventListener('load', () => {
const fnProcError = (errorMsg) => {
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verBlockedPage = (typeof JSFILEVER_blockedPage === 'string') ? JSFILEVER_blockedPage : 'Undefined';
if (verBlockedPage === currentVersion) {
logMsg = `★Program file check <7> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <7> -- [currentVer=${currentVersion}]  blockedPage.js=${verBlockedPage}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【blockedPage】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
try {
let selfPageKey = '';
const tempIndex = document.location.href.indexOf('?');
if (tempIndex > 0) {
const urlArgs = document.location.href.substring(tempIndex + 1).split('&');
urlArgs.forEach((arg) => {
if (arg.startsWith('key=')) {
selfPageKey = arg.substring(4);
}
});
}
ApiWrappers.getCurrentTabAsync(true)
.then((currentTab) => {
return ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, {
cmd: 'ShownBlockedPage',
pageKey: selfPageKey,
windowId: currentTab.windowId,
tabId: currentTab.id,
});
})
.then((msgResponse) => {
if ((typeof msgResponse !== 'object') || (msgResponse?.accepted !== true)) {
return Promise.reject(new Error('Rejected ShownBlockedPage.'));
}
return ApiWrappers.readLocalStorageValueAsync({ ProgramVersionCheckedFlags: 0 });
})
.then((programVersionCheckedFlags) => {
if (programVersionCheckedFlags === null)  programVersionCheckedFlags = 0;
if (0 === (programVersionCheckedFlags & 0x40)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x40) | 0x40;
ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags }).then(() => {});
if (! Utils.isSkipCheckProgramFileVersion()) {
fnCheckProgramFileVersionAsync().then(() => {});
}
}
return ApiWrappers.readSessionStorageValueAsync({ AppliedBrowserSeigen: BrowserSeigens.NONE }, true);
})
.then((browserSeigen) => {
if (browserSeigen !== BrowserSeigens.NONE) {
const divImage = document.getElementById('divImage');
divImage.style.backgroundImage = 'url("./assets/blockedPage.png")';
divImage.style.backgroundColor = '#303030';
setTimeout(() => {
clearCurrentMessages();
addCurrentMessage(Utils.getLocaleMessage('msg_blockedPage'), '#66CDAA', 50, 15);
updateCurrentMessages();
});
}
else {
clearCurrentMessages();
addCurrentMessage(Utils.getLocaleMessage('msg_suspendedPage'), '#F0F8FF', 50, 12);
updateCurrentMessages();
}
document.title = Utils.getLocaleMessage('title_nowInBlockedPage');
disableUserOperation(false);
window.addEventListener('resize', onResizeWindow);
})
.catch((err) => {
const errorMsg = '【blockedPage】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
fnProcError(errorMsg);
});
}
catch (err) {
const errorMsg = '【blockedPage】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
fnProcError(errorMsg);
}
});
window.addEventListener('beforeunload', (ev) => {
disableUserOperation(true);
});
window.addEventListener('error', (ev) => {
const errorMsg = '【blockedPage】WINDOW ERROR (B.Page) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
