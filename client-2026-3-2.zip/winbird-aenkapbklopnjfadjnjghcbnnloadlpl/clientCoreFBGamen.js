'use strict';
const JSFILEVER_clientCoreFBGamen = '3.1.3.1001';
import './library/firebase-app.js';
import './library/firebase-database.js';
import './library/firebase-firestore.js';
export class ClientCoreFBGamen {
static getJsFileVersion() {
return (typeof JSFILEVER_clientCoreFBGamen === 'string') ? JSFILEVER_clientCoreFBGamen : 'Undefined';
}
constructor(gamenCategory) {
this._gamenCategory = ((gamenCategory === 'teiji') || (gamenCategory === 'snapshot')) ? gamenCategory : 'client';
this._firestoreDB = null;
this._isBusyWrite = false;
this._unsubscribeTeiji = null;
this._teijiListenCtrlEmail = null;
this._putLog = this._putLog.bind(this);
this._makeErrorMessage = this._makeErrorMessage.bind(this);
this._getFirestoreDB = this._getFirestoreDB.bind(this);
this._closeFirestoreDB = this._closeFirestoreDB.bind(this);
this._convertBase64ImageAsync = this._convertBase64ImageAsync.bind(this);
this._updateAsync = this._updateAsync.bind(this);
this._addTeijiListenerAsync = this._addTeijiListenerAsync.bind(this);
this._removeTeijiListener = this._removeTeijiListener.bind(this);
this.isBusyWrite = this.isBusyWrite.bind(this);
this.writeGamenAsync = this.writeGamenAsync.bind(this);
this.setTeijiListenerAsync = this.setTeijiListenerAsync.bind(this);
this.resetTeijiListener = this.resetTeijiListener.bind(this);
this.releaseDatabase = this.releaseDatabase.bind(this);
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
_makeErrorMessage(error, prefix=null) {
return `${prefix} [${this._gamenCategory}]` + ((error) ? ` : ${error.message || error}` : '');
}
_getFirestoreDB() {
try {
if (! this._firestoreDB) {
this._firestoreDB = firebase.initializeApp(ExtraConstants.GamenImage_FirebaseConfig, `ClientStatus_${this._gamenCategory}`).firestore();
}
return this._firestoreDB;
}
catch (err) {
this._putLog(this._makeErrorMessage(err, 'ERROR - _getFirestoreDB()'), LogLevels.INFO);
}
return null;
}
_closeFirestoreDB() {
try {
if ((this._firestoreDB) && (typeof this._firestoreDB.app?.delete === 'function')) {
this._firestoreDB.app.delete();
}
this._firestoreDB = null;
}
catch (err) {
this._putLog(this._makeErrorMessage(err, 'ERROR - _closeFirestoreDB()'), LogLevels.INFO);
}
}
_convertBase64ImageAsync(canvas, quality) {
const fnConvertBlobAsync = async (canvas, quality) => {
for (let qualityLevel = quality; qualityLevel > 0; qualityLevel -= 0.15) {
const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: qualityLevel });
if ((blob) && (blob?.size <= 900000)) {
return {
quality: qualityLevel,
blob: blob
};
}
}
return null;
};
return new Promise((resolve, reject) => {
fnConvertBlobAsync(canvas, quality)
.then((result) => {
if (! result)  return Promise.reject('failed convert Blob.');
const reader = new FileReader();
reader.onload = () => {
resolve(reader.result.substring(23));
};
reader.onerror = () => {
reject('failed Blob read.');
};
reader.readAsDataURL(result.blob);
})
.catch((err) => {
reject('failed convert base64' + ((err) ? ` : ${err.message || err}` : '.'));
});
});
}
_updateAsync(ctrlEmail, clientEmail, base64Image=null) {
return new Promise((resolve, reject) => {
if ((this._gamenCategory !== 'client') && (this._gamenCategory !== 'snapshot')) {
reject(`${this._gamenCategory} is not supported.`);
return;
}
const db = this._getFirestoreDB();
const docRef = db.collection(`ClientStatus/${ctrlEmail}/${this._gamenCategory}`).doc(clientEmail);
db.runTransaction((trans) => {
if (base64Image) {
trans.update(docRef, {
jpeg: firebase.firestore.Blob.fromBase64String(base64Image),
updateAt: firebase.firestore.FieldValue.serverTimestamp()
});
}
else {
trans.update(docRef, {
updateAt: firebase.firestore.FieldValue.serverTimestamp()
});
}
return Promise.resolve();
})
.then(() => {
resolve();
})
.catch((err) => {
if ((err?.name === 'FirebaseError') && (err?.code === 'not-found')) {
reject(`${this._gamenCategory} document not found.`);
}
else if ((err?.name === 'FirebaseError') && (err?.code === 'unavailable')) {
reject('failed connection.');
}
else {
reject(err);
}
});
});
}
_addTeijiListenerAsync(ctrlEmail, updatedCallback) {
return new Promise((resolve, reject) => {
try {
if (this._gamenCategory !== 'teiji') {
reject(this._makeErrorMessage(`${this._gamenCategory} is not supported.`, 'ERROR - _addTeijiListenerAsync()'));
return;
}
const db = this._getFirestoreDB();
const docRef = db.doc(`ClientStatus/${ctrlEmail}`);
this._unsubscribeTeiji = docRef.onSnapshot(querySnapshot => {
const updateAt = querySnapshot.get('updateAt');
if (updateAt) {
let updateTime = new Date(updateAt.seconds * 1000);
let jpeg = querySnapshot.get('jpeg');
const base64 = (jpeg) ? 'data:image/jpeg;base64,' + jpeg.toBase64() : '';
if (typeof updatedCallback === 'function') {
const data = {
email: this._teijiListenCtrlEmail,
time: updateTime,
imageBase64: base64,
};
updatedCallback(data);
}
}
});
this._teijiListenCtrlEmail = ctrlEmail;
resolve();
}
catch (err) {
reject(this._makeErrorMessage(err, 'ERROR - _addTeijiListenerAsync()'));
}
});
}
_removeTeijiListener() {
try {
if (this._unsubscribeTeiji) {
this._unsubscribeTeiji();
this._unsubscribeTeiji = null;
}
this._teijiListenCtrlEmail = null;
this._closeFirestoreDB();
}
catch (err) {
this._putLog(this._makeErrorMessage(err, 'ERROR - _removeTeijiListener()'), LogLevels.INFO);
}
}
isBusyWrite() {
return this._isBusyWrite;
}
writeGamenAsync(canvas, ctrlEmail, clientEmail, quality=0.75) {
return new Promise((resolve, reject) => {
try {
if (this._isBusyWrite)  throw new Error('Busy');
this._isBusyWrite = true;
if (canvas) {
this._convertBase64ImageAsync(canvas, quality)
.then((base64Image) => {
return this._updateAsync(ctrlEmail, clientEmail, base64Image);
})
.then(() => {
resolve();
})
.catch((err) => {
reject(this._makeErrorMessage(err, 'ERROR - writeGamenAsync()'));
})
.finally(() => {
this._isBusyWrite = false;
});
}
else {
this._updateAsync(ctrlEmail, clientEmail)
.then(() => {
resolve();
})
.catch((err) => {
const errorMsg = this._makeErrorMessage(err, 'ERROR - writeGamenAsync()');
this._closeFirestoreDB();
reject(errorMsg);
})
.finally(() => {
this._isBusyWrite = false;
});
}
}
catch (err) {
reject(this._makeErrorMessage(err, 'ERROR - writeGamenAsync()'));
this._isBusyWrite = false;
}
});
}
setTeijiListenerAsync(ctrlEmail, updatedCallback) {
return this._addTeijiListenerAsync(ctrlEmail, updatedCallback);
}
resetTeijiListener() {
return this._removeTeijiListener();
}
releaseDatabase() {
this._closeFirestoreDB();
}
}
