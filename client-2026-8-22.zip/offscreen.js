"use strict";const JSFILEVER_offscreen='3.2.1.1001';class OffScreen{constructor(){this._debugTraceLevel=TraceLevels.UNSET;this._bcReceiver=null;this._requestCheckClientCoreDownTimerId=-1;this._globalIpAddress=null;this._tabCurrentUrlMap=new Map();this._requestCheckGipServerTimeTimerId=TIMER_ID_NONE;this._requestCheckGipServerTimeTriggerAt=Number.MAX_VALUE;this._putLog=this._putLog.bind(this);this._makeOffscreenDumpLog=this._makeOffscreenDumpLog.bind(this);this._procReceivedBcMessage=this._procReceivedBcMessage.bind(this);this._procRequestStartupClient=this._procRequestStartupClient.bind(this);this._procRequestCheckClientCoreDown=this._procRequestCheckClientCoreDown.bind(this);this._procRequestCheckGipServerTime=this._procRequestCheckGipServerTime.bind(this);this._procUpdatedBrowserTab=this._procUpdatedBrowserTab.bind(this);this._procRemovedBrowserTab=this._procRemovedBrowserTab.bind(this);this._procChangedGlobalIpAddress=this._procChangedGlobalIpAddress.bind(this);setTimeout(this._procRequestStartupClient,500,true);}
_putLog(message,level=LogLevels.DEBUG){LogManager.putLog(`【offscreen】${message}`,level);}
_makeOffscreenDumpLog(){let logs=[];try{logs.push(`tabCurrentUrlMap  (${this._tabCurrentUrlMap.size}件)`);let num=0;for(const[tabId,tabInfo]of this._tabCurrentUrlMap){logs.push(` [${num++}]  TabID: ${tabId}  TIME: ${Utils.getJstDateTimeStr(true,new Date(tabInfo.time)).slice(5,19)}  `+
`GIP: ${tabInfo.gip}  WRITTEN: ${tabInfo.isWrittenInfo}  URL: "${Utils.truncateStr(tabInfo.url,80,true)}"`);}
logs.push(' ');logs.push(`Current GIP: ${this._globalIpAddress||'(不明)'}`);}
catch(err){this._putLog(`ERROR _makeOffscreenDumpLog(): ${err.message||err||'Error'}`,LogLevels.INFO);logs=[];}
return logs;}
_procReceivedBcMessage(ev){try{if(this._debugTraceLevel===TraceLevels.DEBUG){this._putLog(`_procReceivedBcMessage 受信  cmd=${ev?.data?.cmd}`,LogLevels.INFO);}
if(ev?.data?.cmd==='ImmediateCheckClientCoreDown'){if(this._requestCheckClientCoreDownTimerId!==-1){clearTimeout(this._requestCheckClientCoreDownTimerId);}
this._requestCheckClientCoreDownTimerId=setTimeout(this._procRequestCheckClientCoreDown,0);return;}
else if(ev?.data?.cmd==='UpdatedBrowserTab'){this._procUpdatedBrowserTab(ev.data.status,ev.data.tabId,ev.data.time,ev.data.url,ev.data.title||null,ev.data.error||null);}
else if(ev?.data?.cmd==='RemovedBrowserTab'){this._procRemovedBrowserTab(ev.data.tabId);}
else if(ev?.data?.cmd==='ScheduleCheckGipServerTime'){this._procRequestCheckGipServerTime((typeof ev.data.delay==='number')?ev.data.delay:0);}
else if(ev?.data?.cmd==='ChangedGlobalIpAddress'){this._procChangedGlobalIpAddress(ev.data.ipAddress);}}
catch(err){this._putLog(`ERROR _procReceivedBcMessage(): ${err.message||err||'Error'}`,LogLevels.INFO);}}
_procRequestStartupClient(isFirst=false){try{if(isFirst){chrome.runtime.onMessage.addListener((request,sender,sendResponse)=>{try{if(request.cmd==='ChangedDebugTraceLevel'){if(typeof request.level==='number'){this._debugTraceLevel=Math.min(2,Math.max(0,Math.trunc(request.level)));}
return false;}
if(request.cmd==='GetOffscreenDumpLog'){sendResponse(this._makeOffscreenDumpLog());return false;}}
catch(err){const errorMsg='ERROR - Internal.onMessage()'+((err)?` : ${err.message||err}`:'');this._putLog(errorMsg,LogLevels.FATAL);}
return false;});this._bcReceiver=new BroadcastChannel(BcNames.OFFSCREEN);this._bcReceiver.addEventListener('message',this._procReceivedBcMessage);this._bcReceiver.onmessageerror=(ev)=>{const errorMsg='ERROR - BroadcastChannel.onmessageerror()'+((ev)?` : ${ev.message||ev}`:'');this._putLog(errorMsg,LogLevels.FATAL);};}
chrome.runtime.sendMessage({cmd:'RequestStartupClient',verOffscreen:JSFILEVER_offscreen,},(response)=>{if(chrome.runtime.lastError){this._putLog(`Failed _procRequestStartupClient() sendMessage : ${chrome.runtime.lastError.message}`,LogLevels.INFO);setTimeout(this._procRequestStartupClient,5000,false);}
else{Utils.assert((this._requestCheckClientCoreDownTimerId===-1),'Implementation Error. -- _procRequestStartupClient');this._requestCheckClientCoreDownTimerId=setTimeout(this._procRequestCheckClientCoreDown,10000);}});}
catch(err){this._putLog(`ERROR _procRequestStartupClient(): ${err.message||err||'Error'}`,LogLevels.INFO);}}
_procRequestCheckClientCoreDown(){if(this._requestCheckClientCoreDownTimerId!==-1){clearTimeout(this._requestCheckClientCoreDownTimerId);this._requestCheckClientCoreDownTimerId=-1;}
setTimeout(()=>{chrome.runtime.sendMessage({cmd:'RequestCheckClientCoreDown'});this._requestCheckClientCoreDownTimerId=setTimeout(this._procRequestCheckClientCoreDown,5750);},250);}
_procRequestCheckGipServerTime(delay=0){const now=Date.now();const triggerAt=now+delay;if(this._requestCheckGipServerTimeTimerId!==TIMER_ID_NONE){if((now<(this._requestCheckGipServerTimeTriggerAt-1000))||(triggerAt>=this._requestCheckGipServerTimeTriggerAt)){return;}
clearTimeout(this._requestCheckGipServerTimeTimerId);this._requestCheckGipServerTimeTimerId=TIMER_ID_NONE;}
this._requestCheckGipServerTimeTriggerAt=now+delay;this._requestCheckGipServerTimeTimerId=setTimeout(()=>{this._requestCheckGipServerTimeTimerId=TIMER_ID_NONE;this._requestCheckGipServerTimeTriggerAt=Number.MAX_VALUE;ApiWrappers.sendInternalMsgAsync(true,TAB_ID_NONE,{cmd:'RequestCheckGipServerTime'}).then(()=>{});},delay);}
_procUpdatedBrowserTab(status,tabId,time,url,title,error){try{if((!url?.startsWith('https://'))&&(!url?.startsWith('http://'))){return;}
if(status==='loading'){const lowerLimitTime=time-300000;for(const[tabId,tabInfo]of this._tabCurrentUrlMap){if(tabInfo.time<lowerLimitTime){this._tabCurrentUrlMap.delete(tabId);}}
const tabInfo=this._tabCurrentUrlMap.get(tabId)||null;if((tabInfo?.url===url)&&(tabInfo?.gip===this._globalIpAddress)){if(this._debugTraceLevel===TraceLevels.DEBUG){this._putLog(`URL変化のない『ブラウザタブの更新通知』(loading)を無視します.  tabId:${tabId}  url:"${Utils.truncateStr(url,50,true)}"`,LogLevels.INFO);}
return;}
this._tabCurrentUrlMap.set(tabId,{url:url,time:time,gip:this._globalIpAddress,isWrittenInfo:false,});}
else{if(status==='complete'){const urlInfo=this._tabCurrentUrlMap.get(tabId)||null;if(urlInfo){if(!urlInfo.isWrittenInfo){urlInfo.isWrittenInfo=true;this._tabCurrentUrlMap.set(tabId,urlInfo);AccessUrlInfoBuffer.writeUrlInfoAsync(tabId,urlInfo.time,title||'',urlInfo.url,urlInfo.gip).then((succeed)=>{if(!succeed){this._putLog(`利用URL情報バッファ書込み失敗  url:"${Utils.truncateStr(urlInfo.url,256,true)}"`,LogLevels.INFO);}});}}}
else if(status==='error'){if(error!=='net::ERR_ABORTED'){const urlInfo=this._tabCurrentUrlMap.get(tabId)||null;if(urlInfo){if(this._debugTraceLevel===TraceLevels.DEBUG){this._putLog(`読込み失敗(${error}):  time:${urlInfo.time}  ip:"${urlInfo.gip}"  url:"${Utils.truncateStr(urlInfo.url,256,true)}"`,LogLevels.INFO);}
this._tabCurrentUrlMap.delete(tabId);this._procRequestCheckGipServerTime(5000);}}}
else if(status==='blocked'){const urlInfo=this._tabCurrentUrlMap.get(tabId)||null;if((urlInfo)&&(urlInfo.url===url)){this._tabCurrentUrlMap.delete(tabId);}
AccessUrlInfoBuffer.updateBlockedUrlInfoAsync(tabId,time,url).then((succeed)=>{if(succeed&&(this._debugTraceLevel!==TraceLevels.UNSET)){this._putLog(`利用URL情報バッファの該当情報をブロック済みに更新しました.  tabId:${tabId}  url:"${Utils.truncateStr(url,256,true)}"`,LogLevels.INFO);}});}}}
catch(err){this._putLog(`ERROR _procUpdatedBrowserTab(): ${err.message||err||'Error'}`,LogLevels.INFO);}}
_procRemovedBrowserTab(tabId){try{this._tabCurrentUrlMap.delete(tabId);}
catch(err){this._putLog(`ERROR _procRemovedBrowserTab(): ${err.message||err||'Error'}`,LogLevels.INFO);}}
_procChangedGlobalIpAddress(ipAddress){if(ipAddress){this._globalIpAddress=ipAddress;for(const[tabId,urlInfo]of this._tabCurrentUrlMap){if(!urlInfo.gip){urlInfo.gip=this._globalIpAddress;this._tabCurrentUrlMap.set(tabId,urlInfo);}}
(async()=>{const newIpAddress=ipAddress;const maxRetryCount=3;for(let i=0;i<=maxRetryCount;i++){if(true===await AccessUrlInfoBuffer.updateEmptyGlobalIpAsync(newIpAddress)){break;}
if(i<maxRetryCount){await new Promise(resolve=>setTimeout(resolve,500));if(this._globalIpAddress!==newIpAddress){this._putLog('利用URL情報バッファ内のグローバルIP更新を待機中にグローバルIPが変更(または空に)なったため更新を中止しました.',LogLevels.INFO);break;}}
else{this._putLog(`利用URL情報バッファ内のグローバルIP更新を再試行しましたが、${i}回継続失敗したため断念しました.`,LogLevels.INFO);}}})();}
else{this._globalIpAddress=null;}}}
const cOffScreen=new OffScreen();