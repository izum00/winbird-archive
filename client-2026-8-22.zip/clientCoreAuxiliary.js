"use strict";
const JSFILEVER_clientCoreAuxiliary = '3.2.1.1001';
class ClientCoreAuxiliary {
constructor(cData, timer) {
this._cData = cData;
this._timer = timer;
this._urlWhiteListChecker = null;
this._putLog = this._putLog.bind(this);
this.clearCtrlRequestedLockInfo = this.clearCtrlRequestedLockInfo.bind(this);
this.findCtrlInfoByMail = this.findCtrlInfoByMail.bind(this);
this.convertBrowserSeigenName = this.convertBrowserSeigenName.bind(this);
this.adjustLastJunshiTime = this.adjustLastJunshiTime.bind(this);
this.getDebugTestMode = this.getDebugTestMode.bind(this);
this.getActiveTabAsync = this.getActiveTabAsync.bind(this);
this.getAllBrowserWindowAsync = this.getAllBrowserWindowAsync.bind(this);
this.getBatteryInfoAsync = this.getBatteryInfoAsync.bind(this);
this.makeScreenInfoString = this.makeScreenInfoString.bind(this);
this.makeNewPageKeyAsync = this.makeNewPageKeyAsync.bind(this);
this.createNewHalfBrowserWindowAsync = this.createNewHalfBrowserWindowAsync.bind(this);
this.activeWindowTabAsync = this.activeWindowTabAsync.bind(this);
this.flashClientCorePageAsync = this.flashClientCorePageAsync.bind(this);
this.restoreSizeClientCorePageAsync = this.restoreSizeClientCorePageAsync.bind(this);
this.notifyChangedClientStatus = this.notifyChangedClientStatus.bind(this);
this.notifyChangedAvailableTime = this.notifyChangedAvailableTime.bind(this);
this.captureActiveTab = this.captureActiveTab.bind(this);
this.captureDesktop = this.captureDesktop.bind(this);
this.stopDesktopCapturedStream = this.stopDesktopCapturedStream.bind(this);
this.stopDesktopJunshiStream = this.stopDesktopJunshiStream.bind(this);
this.getCapturedMarkerTabAsync = this.getCapturedMarkerTabAsync.bind(this);
this.restoreBlockedPageTabAsync = this.restoreBlockedPageTabAsync.bind(this);
this.checkClientState = this.checkClientState.bind(this);
this.checkBlockTabUrl = this.checkBlockTabUrl.bind(this);
this.fillCanvas = this.fillCanvas.bind(this);
this.writeFirebaseJunshiGamenAsync = this.writeFirebaseJunshiGamenAsync.bind(this);
this.writeSnapshotAsync = this.writeSnapshotAsync.bind(this);
this.checkIfSameFirebaseJunshiImage = this.checkIfSameFirebaseJunshiImage.bind(this);
this.deactivateMessengerAsync = this.deactivateMessengerAsync.bind(this);
this.openMessengerPageAsync = this.openMessengerPageAsync.bind(this);
this.closeMessengerPageAsync = this.closeMessengerPageAsync.bind(this);
this.openNotificationAsync = this.openNotificationAsync.bind(this);
this.closeNotificationAsync = this.closeNotificationAsync.bind(this);
}
get urlWhiteListChecker() {
return this._urlWhiteListChecker;
}
set urlWhiteListChecker(checker) {
this._urlWhiteListChecker = checker;
}
get authWhiteListUrls() {
let urls = [];
if (this._cData.osType === OsTypes.CHROME) {
urls = [
'https://accounts.google.com/o/',
'https://accounts.google.com/signin/oauth/',
'https://admin.google.com/ServiceNotAllowed/',
];
}
else if (this._cData.osType === OsTypes.WINDOWS) {
urls = [
'https://accounts.google.co.jp/accounts/',
'https://accounts.google.com/o/',
'https://accounts.google.com/ServiceLogin/',
'https://accounts.google.com/signin/oauth/',
'https://accounts.google.com/signin/v2/',
'https://accounts.google.com/signin/v3/',
'https://accounts.google.com/v3/signin/',
'https://admin.google.com/ServiceNotAllowed/',
];
}
return urls;
}
get defaultWhiteListUrl() {
let urls = [
'https://drive.google.com/',
'https://mail.google.com/',
'https://docs.google.com/',
'https://calendar.google.com/',
'https://chat.google.com/',
'https://meet.google.com/',
'https://sites.google.com/',
'https://groups.google.com/',
'https://photos.google.com/',
'https://hangouts.google.com/',
'https://keep.google.com/',
'https://jamboard.google.com/',
'https://classroom.google.com/',
'https://canvas.apps.chrome/',
];
urls = urls.concat(this.authWhiteListUrls);
return urls;
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
clearCtrlRequestedLockInfo() {
this._cData.ctrlRequestedLockType = null;
this._cData.ctrlRequestedLockText = null;
this._cData.ctrlRequestedLockFontColor = null;
this._cData.ctrlRequestedLockBgColor = null;
}
findCtrlInfoByMail(ctrlMail) {
const foundInfo = this._cData.connectedCtrlInfos.find((info) => info.mailAddress === ctrlMail);
return ((foundInfo) ? foundInfo : null);
}
convertBrowserSeigenName(seigenType) {
if (seigenType === BrowserSeigens.CBTMODE) {
return 'CBTモードのブラウザ制限';
}
else if (seigenType === BrowserSeigens.NIGHT) {
return '夜間ブラウザ制限';
}
return 'ブラウザ制限';
}
adjustLastJunshiTime(targetCtrlInfo) {
let junshiFrameRate = targetCtrlInfo.gamenJunshiFrameRate;
if ((targetCtrlInfo.gamenJunshiType !== 'screen') && (junshiFrameRate > this._cData.maxActiveTabJunshiFrameRate)) {
junshiFrameRate = this._cData.maxActiveTabJunshiFrameRate;
}
let refreshTime = (junshiFrameRate > 0) ? Math.round(1000 / junshiFrameRate) : 0;
if (refreshTime > 750) {
targetCtrlInfo.lastJunshiTime = new Date(Date.now() - refreshTime + 750);
}
else {
targetCtrlInfo.lastJunshiTime = new Date();
}
}
getDebugTestMode(modeName) {
const modeKeys = ['A', 'B', 'C'];
const modeKeyIndex = modeKeys.findIndex(item => item === modeName.toUpperCase());
if (modeKeyIndex !== -1) {
return this._cData.debugTestMode[modeKeyIndex];
}
return 0;
}
getActiveTabAsync(useReject=false) {
return new Promise((resolve, reject) => {
let activeTab = null;
ApiWrappers.queryTabAsync({
lastFocusedWindow: true,
active: true
}, useReject)
.then((tabs) => {
if (tabs.length > 0) {
activeTab = tabs[0];
return ApiWrappers.getWindowAsync(activeTab.windowId, {}, useReject);
}
return null;
})
.then((wnd) => {
if ((wnd?.state === 'normal') || (wnd?.state === 'maximized') || (wnd?.state === 'fullscreen')) {
resolve(activeTab);
}
else {
resolve(null);
}
})
.catch((err) => {
reject(err);
});
});
}
getAllBrowserWindowAsync() {
return new Promise((resolve) => {
const browserWnds = [];
let browserSeigenWindowId;
ApiWrappers.readSessionStorageValueAsync({ BrowserSeigenWindowId: WINDOW_ID_NONE }, true)
.then((id) => {
browserSeigenWindowId = (id !== null) ? id : WINDOW_ID_NONE;
return ApiWrappers.getAllWindowAsync({ populate: true, windowTypes: ['normal'] }, true);
})
.then((wnds) => {
for (const wnd of wnds) {
if (wnd.id !== browserSeigenWindowId) {
browserWnds.push(wnd);
}
}
})
.catch((err) => {
const errorMsg = 'ERROR - getAllBrowserWindowAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
browserWnds.length = 0;
})
.finally(() => {
resolve(browserWnds);
});
});
}
getBatteryInfoAsync() {
return new Promise((resolve) => {
let batteryLevel = 0;
let batteryCharging = false;
if ('getBattery' in navigator) {
navigator.getBattery()
.then((battery) => {
batteryLevel = Math.round(battery.level * 100),
batteryCharging = battery.charging;
if (this._cData.debugTraceLevel === TraceLevels.DEBUG) {
this._putLog(`getBattery Result.  level=${battery.level}  charging=${battery.charging}`, LogLevels.INFO);
}
resolve({
level: batteryLevel,
charging: batteryCharging,
});
})
.catch((err) => {
const errorMsg = 'ERROR - getBatteryInfoAsync()  バッテリー情報取得エラー' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve({
level: 0,
charging: false,
});
});
}
else {
if (! this._cData.isUnsupportedGetBattery) {
const errorMsg = 'ERROR - getBatteryInfoAsync()  navigator.getBattery() 未サポートエラー';
this._putLog(errorMsg, LogLevels.INFO);
this._cData.isUnsupportedGetBattery = true;
}
resolve({
level: -1,
charging: false,
});
}
});
}
makeScreenInfoString(screenInfos) {
let result = '';
try {
const tempArray = [];
screenInfos.forEach((info) => {
tempArray.push(`id:${info.displayId},primary:${info.isPrimary},x:${info.screenLeft},y:${info.screenTop},w:${info.screenWidth},h:${info.screenHeight}`);
});
result = JSON.stringify(tempArray);
}
catch (err) {
const errorMsg = 'ERROR - makeScreenInfoString()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
result = '';
}
return result;
}
makeNewPageKeyAsync() {
return new Promise((resolve, reject) => {
let prefixPageKey;
ApiWrappers.readSessionStorageValueAsync({ PrefixPageKey: 'PXXXXXXXXX'} )
.then((prefix) => {
prefixPageKey = prefix;
return CountManager.incrementAsync('PageKeyCode');
})
.then((pageKeyCode) => {
const newPageKey = `${prefixPageKey}${String(Math.trunc(pageKeyCode % 100000000)).padStart(8, '0')}`;
resolve(newPageKey);
})
.catch((err) => {
reject('Failed makeNewPageKeyAsync()' + ((err) ? ` : ${err.message || err}` : ''));
});
});
}
createNewHalfBrowserWindowAsync(createData, useReject=false) {
return new Promise((resolve, reject) => {
ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode, true)
.then((screenInfos) => {
const primaryScreenInfo = screenInfos.find((info) => info.isPrimary);
if (primaryScreenInfo) {
const sizeData = {
left: primaryScreenInfo.screenLeft + Math.trunc(primaryScreenInfo.screenWidth / 4),
top: primaryScreenInfo.screenTop + Math.trunc(primaryScreenInfo.screenHeight / 4),
width: Math.trunc(primaryScreenInfo.screenWidth / 2),
height: Math.trunc(primaryScreenInfo.screenHeight / 2)
};
const newCreateData = Object.assign(createData, sizeData);
return ApiWrappers.createWindowAsync(newCreateData, useReject);
}
return ApiWrappers.createWindowAsync(createData, useReject);
})
.then((wnd) => {
Utils.assert(((wnd !== null) || (! useReject)), 'Implementation Error.');
resolve(wnd);
})
.catch((err) => {
const errorMsg = 'ERROR - createNewHalfBrowserWindowAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
reject('Failed createNewHalfBrowserWindowAsync()');
});
});
}
activeWindowTabAsync(windowId, tabId, useReject=false) {
return new Promise((resolve, reject) => {
if (windowId === WINDOW_ID_NONE) {
if (useReject) {
reject('Failed activeWindowTabAsync()');
}
else {
resolve(false);
}
return;
}
ApiWrappers.updateWindowAsync(windowId, {focused: true}, useReject)
.then((wnd) => {
if (! wnd) {
return null;
}
return ApiWrappers.updateTabAsync(tabId, {active: true}, useReject);
})
.then((tab) => {
if (! tab) {
resolve(false);
}
else {
resolve(true);
}
})
.catch((err) => {
const errorMsg = 'ERROR - activeWindowTabAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
reject('Failed activeWindowTabAsync()');
});
});
}
flashClientCorePageAsync(isUndoFocus=true, msec=350) {
return new Promise((resolve) => {
let lastFocusedWindowId = WINDOW_ID_NONE;
let selfWindowPos = null;
this._cData.isFlashingClientCorePage = true;
ApiWrappers.getLastFocusedWindowAsync({ windowTypes: ['normal','popup','panel','app','devtools']})
.then((wnd)=> {
if ((wnd) && (wnd.id !== this._cData.selfWindowId)) {
lastFocusedWindowId = wnd.id;
}
return ApiWrappers.getWindowAsync(this._cData.selfWindowId);
})
.then((wnd)=> {
if (wnd) {
selfWindowPos = {
left: wnd.left,
top: wnd.top,
right: wnd.left + wnd.width,
bottom: wnd.top + wnd.height
};
}
return ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode);
})
.then((screenInfos)=> {
let updatePosData = { };
if ((screenInfos.length > 1) && (selfWindowPos !== null)) {
if ((selfWindowPos.left < screenInfos[0].screenLeft) ||
(selfWindowPos.top < screenInfos[0].screenTop) ||
(selfWindowPos.right > (screenInfos[0].screenLeft + screenInfos[0].screenWidth)) ||
(selfWindowPos.bottom > (screenInfos[0].screenTop + screenInfos[0].screenHeight))) {
this._cData.selfWindowPosInfo.width = Math.min(this._cData.selfWindowPosInfo.width, screenInfos[0].workAreaWidth);
this._cData.selfWindowPosInfo.height = Math.min(this._cData.selfWindowPosInfo.height, screenInfos[0].workAreaHeight);
this._cData.selfWindowPosInfo.left = screenInfos[0].workAreaLeft + Math.floor((screenInfos[0].workAreaWidth - this._cData.selfWindowPosInfo.width) / 2);
this._cData.selfWindowPosInfo.top = screenInfos[0].workAreaTop + screenInfos[0].workAreaHeight - this._cData.selfWindowPosInfo.height;
updatePosData = this._cData.selfWindowPosInfo;
this._putLog(`クライアントコアページの位置を調整します.  ${this._cData.selfWindowPosInfo}`, LogLevels.INFO);
}
}
Object.assign(updatePosData, { state: 'normal', focused: true });
return ApiWrappers.updateWindowAsync(this._cData.selfWindowId, updatePosData, true);
})
.then(()=> {
return ApiWrappers.updateTabAsync(this._cData.selfTabId, { active: true }, true);
})
.then(()=> {
return new Promise((resolve) => this._timer.addTimer(msec, false, resolve, true));
})
.then(()=> {
return ApiWrappers.updateTabAsync(this._cData.selfTabId, { active: false }, true);
})
.then(()=> {
if (lastFocusedWindowId !== WINDOW_ID_NONE) {
return ApiWrappers.updateWindowAsync(lastFocusedWindowId, { focused: true });
}
})
.then(()=> {
return ApiWrappers.updateWindowAsync(this._cData.selfWindowId, { state: 'minimized', focused: false }, true);
})
.then(()=> {
if ((isUndoFocus) && (lastFocusedWindowId !== WINDOW_ID_NONE)) {
return ApiWrappers.updateWindowAsync(lastFocusedWindowId, { focused: true });
}
})
.then(()=> {
this._cData.isFlashingClientCorePage = false;
resolve(true);
})
.catch((err) => {
const errorMsg = 'ERROR - flashClientCorePageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
this._cData.isFlashingClientCorePage = false;
resolve(false);
});
});
}
restoreSizeClientCorePageAsync() {
return new Promise((resolve) => {
ApiWrappers.updateWindowAsync(this._cData.selfWindowId, { state: 'normal' }, true)
.then(()=> {
resolve(true);
})
.catch((err) => {
const errorMsg = 'ERROR - restoreSizeClientCorePageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve(false);
});
});
}
notifyChangedClientStatus() {
Utils.postBroadcastMessage(BcNames.POPUP_PAGE, { cmd: 'ChangedClientStatus' });
}
notifyChangedAvailableTime() {
Utils.postBroadcastMessage(BcNames.POPUP_PAGE, { cmd: 'ChangedAvailableTime' });
}
captureActiveTab(callback) {
let browserSeigenWindowId;
ApiWrappers.readSessionStorageValueAsync({ BrowserSeigenWindowId: WINDOW_ID_NONE })
.then((value) => {
browserSeigenWindowId = value;
return this.getActiveTabAsync();
})
.then((activeTab) => {
if (! activeTab) {
this._cData.activeTabCapturedImage = null;
callback(0, 0, this._cData.activeTabCapturedImage);
return;
}
try {
const activeWindowId = activeTab.windowId;
const tabId = activeTab.id;
const tabWidth = activeTab.width;
const tabHeight = activeTab.height;
const tabUrl = activeTab.url || activeTab.pendingUrl || '';
if ((activeWindowId === browserSeigenWindowId) || (tabUrl === '') ||
((tabUrl.startsWith(this._cData.selfExtensionPrefixUrl)) &&
(! tabUrl.startsWith(this._cData.attentionPageAbsoluteUrl)) && (! tabUrl.startsWith(this._cData.messengerPageAbsoluteUrl)))) {
this._cData.activeTabCapturedImage = null;
callback(tabWidth, tabHeight, this._cData.activeTabCapturedImage);
return;
}
if (tabUrl.startsWith(this._cData.markerPageAbsoluteUrl)) {
this.getCapturedMarkerTabAsync(tabId)
.then((capturedCanvas) => {
if (capturedCanvas) {
callback(capturedCanvas.width, capturedCanvas.height, capturedCanvas);
}
else {
callback(tabWidth, tabHeight, null);
}
});
}
else {
if ('MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND' in chrome.tabs) {
const tempNowTime = new Date();
const elapsedTime = tempNowTime.getTime() - this._cData.lastActiveTabCapturedTime.getTime();
if (elapsedTime <= Math.ceil(1000 / (chrome.tabs.MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND - 0.05))) {
if (this._cData.activeTabCapturedImage) {
if ((this._cData.activeTabCapturedImage.width < 16) || (this._cData.activeTabCapturedImage.height < 8)) {
callback(this._cData.activeTabCapturedImage.width, this._cData.activeTabCapturedImage.height, null);
}
else {
callback(this._cData.activeTabCapturedImage.width, this._cData.activeTabCapturedImage.height, this._cData.activeTabCapturedImage);
}
}
else {
callback(tabWidth, tabHeight, null);
}
if (elapsedTime < 0) {
this._putLog('アクティブタブのキャプチャ処理中に時計の巻き戻り検出.', LogLevels.INFO);
this._cData.lastActiveTabCapturedTime = new Date();
}
return;
}
}
this._cData.lastActiveTabCapturedTime = new Date();
const options = { format: 'png' };
const beginTime = window.performance.now();
chrome.tabs.captureVisibleTab(activeWindowId, options, (base64img) => {
const elapsedTime = Math.trunc(window.performance.now() - beginTime);
if (chrome.runtime.lastError) {
this._cData.activeTabCapturedImage = null;
callback(tabWidth, tabHeight, this._cData.activeTabCapturedImage);
}
else if (typeof base64img === 'undefined') {
this._cData.activeTabCapturedImage = null;
callback(tabWidth, tabHeight, this._cData.activeTabCapturedImage);
}
else if (elapsedTime >= Constants.TIMEOUT_CAPTURE_ACTIVE_TAB) {
this._cData.activeTabCapturedImage = null;
callback(tabWidth, tabHeight, this._cData.activeTabCapturedImage);
}
else {
this._cData.activeTabCapturedImage = new Image();
this._cData.activeTabCapturedImage.onload = () => {
if ((this._cData.activeTabCapturedImage.width < 16) || (this._cData.activeTabCapturedImage.height < 8)) {
callback(this._cData.activeTabCapturedImage.width, this._cData.activeTabCapturedImage.height, null);
}
else {
callback(this._cData.activeTabCapturedImage.width, this._cData.activeTabCapturedImage.height, this._cData.activeTabCapturedImage);
}
};
this._cData.activeTabCapturedImage.onerror = () => {
this._cData.activeTabCapturedImage = null;
callback(tabWidth, tabHeight, this._cData.activeTabCapturedImage);
};
this._cData.activeTabCapturedImage.src = base64img;
}
});
}
}
catch (err) {
const errorMsg = 'ERROR - captureActiveTab()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
this._cData.activeTabCapturedImage = null;
callback(0, 0, this._cData.activeTabCapturedImage);
}
});
}
captureDesktop(canvas) {
try {
if (canvas) {
const tempNowTime = new Date();
const elapsedTime = tempNowTime.getTime() - this._cData.lastDesktopCapturedTime.getTime();
if (elapsedTime >= 100) {
const videoWidth = this._cData.desktopCapturedVideo.videoWidth;
const videoHeight = this._cData.desktopCapturedVideo.videoHeight;
if ((videoWidth > 0) && (videoHeight > 0)) {
const aspectRatio = videoWidth / videoHeight;
if ((videoWidth !== this._cData.desktopCapturedWidth) ||
(aspectRatio !== this._cData.desktopCapturedAspectRatio)) {
canvas.width = videoWidth;
canvas.height = Math.round(videoWidth / aspectRatio);
this._cData.desktopCapturedWidth = videoWidth;
this._cData.desktopCapturedAspectRatio = aspectRatio;
}
}
Utils.transferImage(canvas, null, this._cData.desktopCapturedVideo);
this._cData.lastDesktopCapturedTime = new Date();
}
else if (elapsedTime < 0) {
this._putLog('デスクトップ画面のキャプチャ処理中に時計の巻き戻り検出.', LogLevels.INFO);
this._cData.lastDesktopCapturedTime = tempNowTime;
}
}
}
catch (err) {
const errorMsg = 'ERROR - captureDesktop()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
}
}
stopDesktopCapturedStream() {
if (this._cData.desktopCapturedStream) {
Utils.stopVideoStream(this._cData.desktopCapturedStream);
this._cData.desktopCapturedStream = null;
}
if (this._cData.desktopCapturedVideo) {
if (this._cData.desktopCapturedVideo.srcObject) {
if (! this._cData.desktopCapturedVideo.paused) {
this._cData.desktopCapturedVideo.pause();
}
if (this._cData.desktopCapturedVideo.srcObject) {
Utils.stopVideoStream(this._cData.desktopCapturedVideo.srcObject);
}
this._cData.desktopCapturedVideo.srcObject = null;
}
this._cData.desktopCapturedVideo = null;
}
if (this._cData.desktopCapturedCanvas) {
this._cData.desktopCapturedCanvas = null;
}
this._cData.lastDesktopCapturedTime = new Date(0);
}
stopDesktopJunshiStream(targetCtrlInfo) {
if (targetCtrlInfo.desktopCapturedVideo) {
if (targetCtrlInfo.desktopCapturedVideo.srcObject) {
Utils.stopVideoStream(targetCtrlInfo.desktopCapturedVideo.srcObject);
}
targetCtrlInfo.desktopCapturedVideo.srcObject = null;
targetCtrlInfo.desktopCapturedVideo = null;
}
if (targetCtrlInfo.desktopJunshiCanvas) {
targetCtrlInfo.desktopJunshiCanvas = null;
}
if (targetCtrlInfo.desktopJunshiStream) {
Utils.stopVideoStream(targetCtrlInfo.desktopJunshiStream);
targetCtrlInfo.desktopJunshiStream = null;
}
}
getCapturedMarkerTabAsync(tabId) {
const fnMakeCapturedMarkerCanvas = (markerData, callback) => {
const canvas = new OffscreenCanvas(this._cData.markerSourceImageCanvas.width, this._cData.markerSourceImageCanvas.height);
const ctx = canvas.getContext('2d');
Utils.transferImage(null, ctx, this._cData.markerSourceImageCanvas);
if (! markerData) {
callback(canvas);
}
else {
const svgImage = new Image();
svgImage.onload = () => {
Utils.transferImage(null, ctx, svgImage);
callback(canvas);
};
svgImage.onerror = () => {
const errorMsg = 'ERROR - getCapturedMarkerTabAsync() - fnMakeCapturedMarkerCanvas()  SVG画像読込エラー';
this._putLog(errorMsg);
callback(null);
};
svgImage.src = markerData;
}
};
return new Promise((resolve) => {
try {
chrome.runtime.sendMessage(ExtraConstants.MARKER_EXTENSION_ID, {
cmd: 'CaptureMarkingPage',
tabId: tabId,
captureMode: 0
}, (response) => {
if (chrome.runtime.lastError) {
const errorMsg = `ERROR - getCapturedMarkerTabAsync() - chrome.runtime.sendMessage : ${chrome.runtime.lastError.message}`;
this._putLog(errorMsg, LogLevels.INFO);
resolve(null);
}
else if (! response) {
const errorMsg = 'ERROR - getCapturedMarkerTabAsync() - CaptureMarkingPage 拒否応答';
this._putLog(errorMsg, LogLevels.INFO);
resolve(null);
}
else {
if (('sourceImage' in response) && (response.sourceImage.length > 0) && ('width' in response) && ('height' in response)) {
const sourceImage = new Image();
sourceImage.onload = () => {
this._cData.markerSourceImageCanvas = new OffscreenCanvas(response.width, response.height);
Utils.transferImage(this._cData.markerSourceImageCanvas, null, sourceImage);
fnMakeCapturedMarkerCanvas(response.markerImage, (canvas) => {
resolve(canvas);
});
};
sourceImage.onerror = () => {
resolve(null);
};
sourceImage.src = response.sourceImage;
}
else if ('markerImage' in response) {
fnMakeCapturedMarkerCanvas(response.markerImage, (canvas) => {
resolve(canvas);
});
}
else {
const errorMsg = 'getCapturedMarkerTabAsync() - データ無し ';
this._putLog(errorMsg, LogLevels.INFO);
resolve(null);
}
}
});
}
catch (err) {
const errorMsg = 'ERROR - getCapturedMarkerTabAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve(null);
}
});
}
restoreBlockedPageTabAsync() {
return new Promise((resolve) => {
let currentActiveWindowId = WINDOW_ID_NONE;
let currentActiveTabId = TAB_ID_NONE;
let tempSeigenPageWindowId = WINDOW_ID_NONE;
let tempSeigenPageTabId = TAB_ID_NONE;
let prefixPageKey;
ApiWrappers.readSessionStorageValueAsync({ PrefixPageKey: 'PXXXXXXXXX' })
.then((value) => {
prefixPageKey = value;
return this.getActiveTabAsync();
})
.then((activeTab) => {
if (activeTab) {
currentActiveWindowId = activeTab.windowId;
currentActiveTabId = activeTab.id;
}
return ApiWrappers.queryTabAsync({ windowType: 'normal' });
})
.then((tabs) => {
let restoreTabInfos = {};
tabs.forEach((tab) => {
const tabUrl = tab.url || '';
if (tabUrl.startsWith(this._cData.blockedPageAbsoluteUrl)) {
const windowId = tab.windowId;
const tabId = tab.id;
if (! restoreTabInfos[windowId]) {
restoreTabInfos[windowId] = [];
}
restoreTabInfos[windowId].push(tabId);
}
else if (tabUrl.startsWith(this._cData.browserSeigenPageAbsoluteUrl)) {
tempSeigenPageWindowId = tab.windowId;
tempSeigenPageTabId = tab.id;
}
});
let promises = [];
const keys = Object.keys(restoreTabInfos);
for (let i = 0; i < keys.length; i++) {
const windowId = Number(keys[i]);
for (let j = 0; j < restoreTabInfos[windowId].length; j++) {
const tabId = restoreTabInfos[windowId][j];
promises.push(ApiWrappers.goBackTabAsync(tabId));
}
}
if (promises.length > 0) {
return Promise.allSettled(promises);
}
return [];
})
.then((results) => {
if (results.length > 0) {
return new Promise((resolve) => this._timer.addTimer(950, false, resolve, true));
}
return false;
})
.then((isNeedCheck) => {
if (isNeedCheck) {
return ApiWrappers.queryTabAsync({ windowType: 'normal' });
}
return [];
})
.then((tabs) => {
let removeTabIds = [];
let prefixTargetUrl = `${this._cData.blockedPageAbsoluteUrl}?key=${prefixPageKey}`;
tabs.forEach((tab) => {
const tabUrl = tab.url || '';
if (tabUrl.startsWith(prefixTargetUrl)) {
removeTabIds.push(tab.id);
}
});
if (removeTabIds.length > 0) {
this._putLog(`遮断ページをひとつ前のページに戻せなかった ${removeTabIds.length}個 のタブを削除します.`, LogLevels.INFO);
return ApiWrappers.removeTabAsync(removeTabIds);
}
})
.then(() => {
if (tempSeigenPageWindowId !== WINDOW_ID_NONE) {
return ApiWrappers.updateWindowAsync(tempSeigenPageWindowId, { state: 'normal' });
}
return null;
})
.then((wnd) => {
if (wnd) {
if (tempSeigenPageTabId) {
return ApiWrappers.removeTabAsync(tempSeigenPageTabId);
}
}
})
.then(() => {
if ((currentActiveWindowId !== WINDOW_ID_NONE) || (currentActiveTabId !== TAB_ID_NONE)) {
return this.activeWindowTabAsync(currentActiveWindowId, currentActiveTabId);
}
})
.finally(() => {
resolve();
});
});
}
checkClientState(isReentry, callback) {
let batteryInfo;
let activeTab;
let activeTabUrl = '';
let activeTabFaviconUrl = '';
let activeTabTitle = '';
this.getBatteryInfoAsync()
.then((result) => {
batteryInfo = result;
return this.getActiveTabAsync();
})
.then((result) => {
activeTab = result;
if (activeTab) {
let isActivedNowInClassworkPage = false;
if (this._cData.currentGamenJunshiType === 'screen') {
const primaryPageInfo = this._cData.currentClassworkPages.find((v) => (!! v.isPrimary));
if ((primaryPageInfo) && (primaryPageInfo.currentPageWindowId === activeTab.windowId)) {
isActivedNowInClassworkPage = true;
}
}
if (! isActivedNowInClassworkPage) {
if ('url' in activeTab) {
activeTabUrl = activeTab.url || activeTab.pendingUrl || '';
}
if ('favIconUrl' in activeTab) {
activeTabFaviconUrl = activeTab.favIconUrl;
}
if ('title' in activeTab) {
activeTabTitle = (activeTab.title) ? activeTab.title : '';
}
if ((activeTabUrl.startsWith(this._cData.clientCorePageAbsoluteUrl)) ||
(activeTabUrl.startsWith(this._cData.phantomPageAbsoluteUrl)) ||
(activeTabUrl.startsWith(this._cData.browserSeigenPageAbsoluteUrl))) {
if (! isReentry) {
this._timer.addTimer(250, false, this.checkClientState, true, callback);
return;
}
activeTabUrl = '';
activeTabFaviconUrl = '';
activeTabTitle = '';
}
if ((! activeTabFaviconUrl) && (! isReentry) && (activeTab.status === 'loading')) {
this._timer.addTimer(950, false, this.checkClientState, true, callback);
return;
}
}
}
let changed = false;
let changedUrl = false;
let changedFaviconUrl = false;
if (this._cData.currentBatteryCharging !== batteryInfo.charging) {
this._cData.currentBatteryCharging = batteryInfo.charging;
changed = true;
}
const batteryLevel = Math.trunc(batteryInfo.level / 10) * 10;
if (this._cData.currentBatteryLevel !== batteryLevel) {
this._cData.currentBatteryLevel = batteryLevel;
changed = true;
}
if (this._cData.currentActiveTabTitle !== activeTabTitle) {
this._cData.currentActiveTabTitle = activeTabTitle;
changed = true;
}
if (this._cData.currentActiveTabUrl !== activeTabUrl) {
this._cData.currentActiveTabUrl = activeTabUrl;
changedUrl = true;
}
if (this._cData.currentActiveTabFaviconUrl !== activeTabFaviconUrl) {
this._cData.currentActiveTabFaviconUrl = activeTabFaviconUrl;
changedFaviconUrl = true;
}
if (! changed) {
changed = (this._cData.currentActiveTabFaviconUrl) ? changedFaviconUrl : changedUrl;
}
callback(changed);
});
}
checkBlockTabUrl(tabUrl) {
if (this._cData.appliedBrowserSeigen === BrowserSeigens.NONE) {
this._putLog('ブラウザ制限中でないときに checkBlockTabUrl() が呼ばれた.', LogLevels.INFO);
return 'ignore';
}
if (this._urlWhiteListChecker === null) {
this._putLog('ホワイトリストチェッカーが未設定(null)のときに checkBlockTabUrl() が呼ばれた.', LogLevels.INFO);
return 'ignore';
}
if ((tabUrl.startsWith(this._cData.selfExtensionPrefixUrl)) ||
(tabUrl.startsWith(ExtraConstants.NEW_TAB_PAGE_URL))) {
return 'ignore';
}
if ((tabUrl.startsWith('chrome-extension://')) ||
(tabUrl.startsWith('about:blank'))) {
return 'allow';
}
if ((this._cData.appliedBrowserSeigen !== BrowserSeigens.CBTMODE) &&
((tabUrl.startsWith('chrome://')) && (! tabUrl.startsWith('chrome://dino')))) {
return 'allow';
}
tabUrl = Utils.trimUrlAnkerParameter(tabUrl);
if (tabUrl === 'https://www.google.com/url') {
return 'ignore';
}
return (this._urlWhiteListChecker.check(tabUrl)) ? 'allow' : 'disallow';
}
fillCanvas(canvas, isBlackOut) {
if (canvas) {
try {
const ctx = canvas.getContext('2d');
ctx.fillStyle = (isBlackOut ? 'rgb(32, 32, 32)' : 'rgb(0, 64, 128)');
ctx.fillRect(0, 0, canvas.width, canvas.height);
if (this._cData.debugTraceLevel === TraceLevels.INFO) {
this._putLog(`アクティブタブのキャプチャ用キャンバスを ${(isBlackOut ? '黒塗り' : '青塗り')} しました.`);
}
}
catch (err) {
const errorMsg = 'ERROR - fillCanvas()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
}
}
}
writeFirebaseJunshiGamenAsync(cFbg, ctrlMail, image, quality, requestedWidth) {
return new Promise((resolve, reject) => {
if (cFbg.isBusyWrite()) {
this._putLog(`巡視画面画像をFirebaseに書き込み中のため、画像書き込み(要求幅:${requestedWidth})をスキップします.`, this._cData.getTraceLogLevel());
resolve({
skiped: true,
quality: quality,
width: requestedWidth
});
}
else if (! image) {
Utils.assert((image), 'Implementation Error. -- writeFirebaseJunshiGamenAsync()');
reject();
}
else {
const workCanvas = new OffscreenCanvas(image.width, image.height);
Utils.transferImage(workCanvas, null, image);
cFbg.writeGamenAsync(workCanvas, ctrlMail, this._cData.signedUserEmail, quality)
.then(() => {
this._putLog(`巡視画面画像(要求幅:${requestedWidth})をFirebaseに書き込みました.  Mail=${ctrlMail}`, this._cData.getTraceLogLevel());
resolve({
skiped: false,
quality: quality,
width: requestedWidth
});
})
.catch((err) => {
this._putLog(`巡視画面画像(要求幅:${requestedWidth})のFirebase書き込み失敗.  Mail=${ctrlMail}  ${err.message || err || ''}`, LogLevels.INFO);
reject();
});
}
});
}
writeSnapshotAsync(cFbg, ctrlMail) {
return new Promise((resolve) => {
const targetCtrlInfo = this.findCtrlInfoByMail(ctrlMail);
if ((! targetCtrlInfo) || (! targetCtrlInfo.isSnapshotWriteWaiting)) {
resolve(false);
}
else {
const elapsed = Date.now() - targetCtrlInfo.snapshotRequestedTime;
if ((elapsed < 0) || (elapsed > 5000)) {
this._putLog(`タイムアウトによりコントローラ( ${targetCtrlInfo.mailAddress} )のスナップショット書込を断念しました.`, LogLevels.INFO);
targetCtrlInfo.snapshotQuality = 0;
targetCtrlInfo.snapshotRequestedTime = 0;
targetCtrlInfo.snapshotWriteWaitingImage = null;
targetCtrlInfo.isSnapshotWriteWaiting = false;
resolve(false);
}
else if (cFbg.isBusyWrite()) {
resolve(false);
}
else {
const image = targetCtrlInfo.snapshotWriteWaitingImage;
const quality = targetCtrlInfo.snapshotQuality;
targetCtrlInfo.snapshotQuality = 0;
targetCtrlInfo.snapshotRequestedTime = 0;
targetCtrlInfo.snapshotWriteWaitingImage = null;
targetCtrlInfo.isSnapshotWriteWaiting = false;
cFbg.writeGamenAsync(image, ctrlMail, this._cData.signedUserEmail, quality)
.then(() => {
this._putLog(`スナップショット画像${(image) ? '' : '(画像なし)'}をFirebaseに書き込みました.  Mail=${ctrlMail}`, LogLevels.INFO);
resolve(true);
})
.catch((err) => {
this._putLog(`スナップショット画像${(image) ? '' : '(画像なし)'}のFirebase書き込み失敗.  Mail=${ctrlMail}  ${err.message || err || ''}`, LogLevels.INFO);
resolve(false);
});
}
}
});
}
checkIfSameFirebaseJunshiImage(targetCtrlInfo, image) {
const fnComputeImageCheckSums = (canvas) => {
const checkSums = [];
try {
let partitionedRanges;
if ((canvas.width <= 24) || (canvas.height <= 18)) {
partitionedRanges = [{ xs: 0, xe: canvas.width - 1, ys: 0, ye: canvas.height - 1 }];
}
else {
const quarterWidth = Math.floor((canvas.width + 3) / 4);
const quarterHeight = Math.floor((canvas.height + 3) / 4);
partitionedRanges = [
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: 0,                   ye: (quarterHeight * 1) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 1), ye: (quarterHeight * 2) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 2), ye: (quarterHeight * 3) - 1 },
{ xs: 0                 , xe: (quarterWidth * 1) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 1), xe: (quarterWidth * 2) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 2), xe: (quarterWidth * 3) - 1, ys: (quarterHeight * 3), ye: canvas.height - 1 },
{ xs: (quarterWidth * 3), xe: canvas.width - 1      , ys: (quarterHeight * 3), ye: canvas.height - 1 },
];
}
const ctx = canvas.getContext('2d');
const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
const dataView = new DataView(imageData.data.buffer, 0, imageData.data.byteLength);
for (const range of partitionedRanges) {
let sum32 = 0;
for (let y = range.ys; y <= range.ye; y++) {
let x = range.xs;
if ((x & 1) !== (y & 1))  x++;
while (x <= range.xe) {
let val = dataView.getUint32((y * (imageData.width * 4)) + (x * 4), true);
if (val === 0) {
val = ((y % 11) + 1) * ((x % 13) + 1);
}
else {
val *= ((y % 11) + 1) * ((x % 13) + 1);
}
sum32 += val;
if (sum32 >= 4294967296) {
sum32 -= 4294967296;
}
x += 2;
}
}
checkSums.push(sum32);
}
}
catch (err) {
const errorMsg = 'ERROR - checkIfSameFirebaseJunshiImage() - fnComputeImageCheckSums()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
checkSums.length = 0;
}
return checkSums;
};
let result = true;
Utils.assert((image) && (targetCtrlInfo.isFirebaseJunshi), 'Implementation Error. -- checkIfSameFirebaseJunshiImage()');
if ((image) && (targetCtrlInfo.isFirebaseJunshi)) {
const workCanvas = new OffscreenCanvas(image.width, image.height);
Utils.transferImage(workCanvas, null, image);
const checkSums = fnComputeImageCheckSums(workCanvas);
if ((workCanvas.width < 0) || (targetCtrlInfo.lastFirebaseJunshiImageWidth < 0) ||
(workCanvas.width !== targetCtrlInfo.lastFirebaseJunshiImageWidth) ||
(workCanvas.height < 0) || (targetCtrlInfo.lastFirebaseJunshiImageHeight < 0) ||
(workCanvas.height !== targetCtrlInfo.lastFirebaseJunshiImageHeight) ||
(checkSums.length < 0) || (targetCtrlInfo.lastFirebaseJunshiImageCheckSums.length < 0) ||
(checkSums.length !== targetCtrlInfo.lastFirebaseJunshiImageCheckSums.length)) {
result = false;
}
else {
for (let i = 0; i < checkSums.length; i++) {
if (checkSums[i] !== targetCtrlInfo.lastFirebaseJunshiImageCheckSums[i]) {
result = false;
break;
}
}
}
if (! result) {
targetCtrlInfo.lastFirebaseJunshiImageWidth = workCanvas.width;
targetCtrlInfo.lastFirebaseJunshiImageHeight = workCanvas.height;
targetCtrlInfo.lastFirebaseJunshiImageCheckSums = checkSums;
}
}
return result;
}
deactivateMessengerAsync() {
return new Promise((resolve) => {
ApiWrappers.readSessionStorageValueAsync({ IsActivedMessenger: false })
.then((isActived) => {
if ((isActived) && ((this._cData.isCbtMode) || (false === this._cData.connectedCtrlInfos.some((info) => info.isActivedMessenger)))) {
if (this._cData.isCbtMode) {
this._cData.connectedCtrlInfos.forEach((info) => {
info.isActivedMessenger = false;
info.isSimplexMessenger = false;
});
}
this.closeMessengerPageAsync()
.then(() => {
return ApiWrappers.saveSessionStorageDataAsync({ IsActivedMessenger: false });
})
.then(() => {
const timerIds = Object.values(this._cData.cliMessengerResponseTimerIds);
this._cData.cliMessengerResponseTimerIds = {};
this._cData.cliMessengerRequestNumberInfos = {};
for (const id of timerIds) {
this._timer.removeTimer(id);
}
return this.closeNotificationAsync('Messenger');
})
.finally(() => {
this._cData.pendingMessengerPushMessage = null;
resolve(true);
});
}
else {
resolve(false);
}
});
});
}
openMessengerPageAsync(delay=0, isReopen=false, isRetry=false) {
return new Promise(async (resolve) => {
let isNeedsRetry = false;
try {
if (delay > 0)  await new Promise((resolve) => this._timer.addTimer(delay, false, resolve, true));
let messengerWindowPosInfo = await ApiWrappers.readLocalStorageValueAsync({ MessengerWindowPosInfo: null});
if (messengerWindowPosInfo === null)  messengerWindowPosInfo = { left: 50, top: 50, width: 400, height: 500 };
messengerWindowPosInfo.width = 400;
let storage = await ApiWrappers.readSessionStorageDataAsync({
IsActivedMessenger: false,
MessengerPageWindowId: WINDOW_ID_NONE,
}, true);
if (! storage.IsActivedMessenger) {
resolve(false);
return;
}
if (storage.MessengerPageWindowId !== WINDOW_ID_NONE) {
if (! isReopen) {
let updateInfo = {
state: 'normal',
focused: true,
};
updateInfo = Object.assign(updateInfo, messengerWindowPosInfo);
if (null !== await ApiWrappers.updateWindowAsync(storage.MessengerPageWindowId, updateInfo)) {
resolve(true);
return;
}
}
await this.closeMessengerPageAsync();
}
let createData = {
url: chrome.runtime.getURL(PageHtmlNames.MESSENGER),
focused: true,
type: 'popup',
state: 'normal',
};
createData = Object.assign(createData, messengerWindowPosInfo);
const wnd = await ApiWrappers.createWindowAsync(createData, true);
let tabId = TAB_ID_NONE;
if ((wnd.tabs) && (wnd.tabs.length > 0)) {
tabId = wnd.tabs[0].id;
}
await ApiWrappers.saveSessionStorageDataAsync({
MessengerPageWindowId: wnd.id,
MessengerPageTabId: tabId,
});
resolve(true);
}
catch (err) {
if ((! isRetry) && (typeof err === 'string') &&
((err.startsWith('Failed createWindowAsync() : Invalid value for bounds.')) ||
(err.startsWith('Failed updateWindowAsync() : Invalid value for bounds.')))) {
LogManager.putLog('メッセンジャーページのウィンドウ作成が配置失敗のため再試行します.', LogLevels.INFO);
await ApiWrappers.removeLocalStorageDataAsync('MessengerWindowPosInfo');
isNeedsRetry = true;
}
else {
const errorMsg = 'メッセンジャーページのウィンドウ作成に失敗しました.' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.FATAL);
resolve(false);
}
}
if (isNeedsRetry) {
const result = await this.openMessengerPageAsync(0, false, true);
resolve(result);
}
});
}
closeMessengerPageAsync() {
return new Promise((resolve) => {
ApiWrappers.readSessionStorageValueAsync({ MessengerPageWindowId: WINDOW_ID_NONE })
.then((messengerPageWindowId) => {
if (messengerPageWindowId === WINDOW_ID_NONE) {
resolve(true);
}
else {
ApiWrappers.removeWindowAsync(messengerPageWindowId)
.then((succeed) => {
if (succeed) {
return ApiWrappers.saveSessionStorageDataAsync({
MessengerPageWindowId: WINDOW_ID_NONE,
MessengerPageTabId: TAB_ID_NONE,
});
}
})
.finally(() => {
resolve(true);
});
}
})
.catch((err) => {
const errorMsg = 'ERROR - closeMessengerPageAsync()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.FATAL);
resolve(false);
});
});
}
openNotificationAsync(name, message, iconPath=null) {
return new Promise((resolve) => {
ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, {
cmd: 'OpenPushNotification',
name: name,
message: message,
iconPath: iconPath
})
.then((msgResponse) => {
resolve(msgResponse);
});
});
}
closeNotificationAsync(name=null) {
return new Promise((resolve) => {
ApiWrappers.sendInternalMsgAsync(false, TAB_ID_NONE, {
cmd: 'ClosePushNotification',
name: name
})
.then((msgResponse) => {
resolve(msgResponse);
});
});
}
}
