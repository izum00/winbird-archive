'use strict';
const JSFILEVER_attention = '3.2.1.1001';
const DisplayModes = Object.freeze({
INITIAL: 0,
GAMEN_LOCK: 1,
GAMEN_TEIJI: 2,
});
const CursorTypes = Object.freeze({
NONE: 0,
DEFAULT: 1,
ZOOM_OUT: 2,
});
let isBeforeUnloadFired = false;
let selfWindowId = WINDOW_ID_NONE;
let selfPageId = 0;
let osType = OsTypes.UNKNOWN;
let clientCoreTabId = TAB_ID_NONE;
let isDeveloperMode = false;
let debugTraceLevel = TraceLevels.UNSET;
let debugTestMode = [0, 0, 0];
let isPrimaryScreen = false;
let isAllowedPipGamenTeiji = false;
let pipGamenTeijiWindow = null;
let isShowedPipGamenTeiji = false;
let isBusyClickPageProsess = false;
const enabledPageClick = { isEnabled: true };
let currentDisplayMode = DisplayModes.INITIAL;
let currentLockType = null;
let currentMessageText = null;
let currentMessageColor = null;
let currentTeijiCanvas = null;
let thinningOutMouseMoveTimerId = TIMER_ID_NONE;
const putLog = (message, level=LogLevels.DEBUG) => {
LogManager.putLog(`【attention】${message}`, level);
};
const createInternalMessageListener = () => {
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
try {
if (request.cmd === 'ChangedTeijiImage') {
if (isPrimaryScreen) {
try {
if (request.imageBase64) {
const teijiImage = new Image();
teijiImage.onload = () => {
if ((currentTeijiCanvas?.width || 0) > 0) {
if ((currentTeijiCanvas.width !== teijiImage.naturalWidth) ||
(currentTeijiCanvas.height !== teijiImage.naturalHeight)) {
currentTeijiCanvas.width = teijiImage.naturalWidth;
currentTeijiCanvas.height = teijiImage.naturalHeight;
}
Utils.transferImage(currentTeijiCanvas, null, teijiImage);
}
else {
putLog('ERROR - Internal.onMessage() "ChangedTeijiImage" : currentTeijiCanvas is invalid.', LogLevels.INFO);
}
};
teijiImage.onerror = () => {
putLog('ERROR - Internal.onMessage() "ChangedTeijiImage" : Failed teijiImage load.', LogLevels.INFO);
};
teijiImage.src = request.imageBase64;
}
else if (request.isResend !== true) {
const ctx = currentTeijiCanvas.getContext('2d');
ctx.fillStyle = 'rgb(93, 93, 93)';
ctx.fillRect(0, 0, currentTeijiCanvas.width, currentTeijiCanvas.height);
}
}
catch (err) {}
}
return false;
}
if (request.cmd === 'UpdateAttentionPage') {
ApiWrappers.readSessionStorageDataAsync({
AttentionPageMode: '',
IsAllowedPipGamenTeiji: false,
})
.then(async (storage) => {
if (storage.AttentionPageMode === 'lock') {
if (isShowedPipGamenTeiji) {
await closePipGamenTeijiAsync();
}
isAllowedPipGamenTeiji = false;
setDisplayMode(DisplayModes.GAMEN_LOCK);
}
else if (storage.AttentionPageMode === 'teiji') {
if ((isShowedPipGamenTeiji) && (! storage.IsAllowedPipGamenTeiji)) {
await closePipGamenTeijiAsync();
}
isAllowedPipGamenTeiji = storage.IsAllowedPipGamenTeiji;
setDisplayMode(DisplayModes.GAMEN_TEIJI);
}
});
return false;
}
if (request.cmd === 'DestroyExistingPage') {
LogManager.putLogAsync(`【attention】DestroyExistingPage 受諾.  (Page:${selfPageId}  Primary:${isPrimaryScreen}  WindowId:${selfWindowId})`, LogLevels.INFO)
.then(() => {
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
return document.exitPictureInPicture();
}
})
.then(() => {
pipGamenTeijiWindow = null;
window.close();
});
return false;
}
if (request.cmd === 'ClosePipGamenTeijiWindow') {
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
document.exitPictureInPicture()
.then(() => {
pipGamenTeijiWindow = null;
});
}
return false;
}
if (request.cmd === 'ClosePage') {
LogManager.putLogAsync(`【attention】ClosePage 受諾.  (Page:${selfPageId}  Primary:${isPrimaryScreen}  WindowId:${selfWindowId})`, (debugTraceLevel === TraceLevels.UNSET) ? LogLevels.DEBUG : LogLevels.INFO)
.then(() => {
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
return document.exitPictureInPicture();
}
})
.then(() => {
pipGamenTeijiWindow = null;
window.close();
});
return false;
}
if (request.cmd === 'ChangedDebugTraceLevel') {
if (typeof request.level === 'number')  debugTraceLevel = Math.min(2, Math.max(0, Math.trunc(request.level)));
return false;
}
if (request.cmd === 'ChangedDebugTestMode') {
if (typeof request.modeA === 'number')  debugTestMode[0] = request.modeA;
if (typeof request.modeB === 'number')  debugTestMode[1] = request.modeB;
if (typeof request.modeC === 'number')  debugTestMode[2] = request.modeC;
return false;
}
}
catch (err) {
const errorMsg = 'ERROR - Internal.onMessage()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
return false;
});
};
const getDebugTestMode = (modeName) => {
const modeKeys = ['A', 'B', 'C'];
const modeKeyIndex = modeKeys.findIndex(item => item === modeName.toUpperCase());
if (modeKeyIndex !== -1) {
return debugTestMode[modeKeyIndex];
}
return 0;
};
const updatePageLayout = () => {
try {
const clientWidth = document.body.clientWidth;
const clientHeight = document.documentElement.clientHeight;
const videoGamenTeiji = document.getElementById('videoGamenTeiji');
if (videoGamenTeiji) {
videoGamenTeiji.style.width = `${clientWidth}px`;
videoGamenTeiji.style.height = `${clientHeight}px`;
}
}
catch (err) {
const errorMsg = 'ERROR - updatePageLayout()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
}
};
const changeCursor = (cursorType=CursorTypes.NONE) => {
const divMain = document.getElementById('divMain');
switch (cursorType) {
case CursorTypes.NONE:
divMain.classList.remove('cursorDefault');
divMain.classList.remove('cursorZoomOut');
divMain.classList.add('cursorNone');
break;
case CursorTypes.DEFAULT:
divMain.classList.remove('cursorNone');
divMain.classList.remove('cursorZoomOut');
divMain.classList.add('cursorDefault');
break;
case CursorTypes.ZOOM_OUT:
divMain.classList.remove('cursorNone');
divMain.classList.remove('cursorDefault');
divMain.classList.add('cursorZoomOut');
break;
}
};
const updateFlexibleMessage = () => {
if ((currentDisplayMode === DisplayModes.GAMEN_LOCK)  && (currentLockType === 'text')) {
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
Utils.removeFlexibleMessage(divFlexibleMessages);
const msgInfo = new FlexibleMessageInfo(currentMessageText, currentMessageColor, 50, 30);
Utils.addFlexibleMessage(divFlexibleMessages, msgInfo);
}
};
const disableUserOperation = (isRemove) => {
if (! isRemove) {
document.addEventListener('mousedown', preventEvents, { passive: false });
document.addEventListener('mouseenter', preventEvents, { passive: false });
document.addEventListener('mouseleave', preventEvents, { passive: false });
document.addEventListener('mousemove', preventEvents, { passive: false });
document.addEventListener('mouseout', preventEvents, { passive: false });
document.addEventListener('mouseover', preventEvents, { passive: false });
document.addEventListener('mouseup', preventEvents, { passive: false });
document.addEventListener('mousewheel', preventEvents, { passive: false });
document.addEventListener('touchmove', preventEvents, { passive: false });
document.oncontextmenu = () => { return false; }
}
else {
document.removeEventListener('mousedown', preventEvents, { passive: false });
document.removeEventListener('mouseenter', preventEvents, { passive: false });
document.removeEventListener('mouseleave', preventEvents, { passive: false });
document.removeEventListener('mousemove', preventEvents, { passive: false });
document.removeEventListener('mouseout', preventEvents, { passive: false });
document.removeEventListener('mouseover', preventEvents, { passive: false });
document.removeEventListener('mouseup', preventEvents, { passive: false });
document.removeEventListener('mousewheel', preventEvents, { passive: false });
document.removeEventListener('touchmove', preventEvents, { passive: false });
document.oncontextmenu = () => { return true; }
}
};
const preventEvents = (ev) => {
if ('type' in ev) {
if (ev.type === 'touchmove') {
if (('cancelable' in ev) && (ev.cancelable === false)) {
return;
}
}
else if ((ev.type === 'mousedown') && (enabledPageClick.isEnabled)) {
if (thinningOutMouseMoveTimerId !== TIMER_ID_NONE) {
clearTimeout(thinningOutMouseMoveTimerId);
thinningOutMouseMoveTimerId = TIMER_ID_NONE;
changeCursor(CursorTypes.NONE);
}
if (! isBusyClickPageProsess) {
if (! isShowedPipGamenTeiji) {
if (isAllowedPipGamenTeiji) {
isBusyClickPageProsess = true;
setTimeout(() => {
openPipGamenTeijiAsync()
.then(() => {
isBusyClickPageProsess = false;
});
}, 100);
}
}
}
}
else if ((ev.type === 'mousemove') && (enabledPageClick.isEnabled) && (currentDisplayMode === DisplayModes.GAMEN_TEIJI)) {
if ((thinningOutMouseMoveTimerId === TIMER_ID_NONE) && (isAllowedPipGamenTeiji) && (! isShowedPipGamenTeiji)) {
if (isPrimaryScreen) {
changeCursor(CursorTypes.ZOOM_OUT);
thinningOutMouseMoveTimerId = setTimeout(() => {
thinningOutMouseMoveTimerId = TIMER_ID_NONE;
changeCursor(CursorTypes.NONE);
}, 3500);
}
}
}
}
ev.preventDefault();
};
const closePipGamenTeijiAsync = async () => {
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
await document.exitPictureInPicture();
}
pipGamenTeijiWindow = null;
await ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ChangeAttentionPageWindowState',
newState: 'fullscreen'
});
};
const setDisplayMode = (displayMode) => {
try {
currentDisplayMode = displayMode;
const divGamenTeiji = document.getElementById('divGamenTeiji');
const videoGamenTeiji = document.getElementById('videoGamenTeiji');
const divGamenLockImage = document.getElementById('divGamenLockImage');
const divFlexibleMessages = document.getElementById('divFlexibleMessages');
const divPoweredBy = document.getElementById('divPoweredBy');
changeCursor(CursorTypes.NONE);
if (currentDisplayMode === DisplayModes.GAMEN_TEIJI) {
if ((! isPrimaryScreen) || (! window.opener) || (window.opener.closed)) {
divGamenTeiji.style.visibility = 'hidden';
divGamenLockImage.style.visibility = 'hidden';
divFlexibleMessages.style.visibility = 'hidden';
divPoweredBy.style.visibility = 'visible';
document.title = Utils.getLocaleMessage('ext_title');
if (isAllowedPipGamenTeiji) {
changeCursor(CursorTypes.DEFAULT);
}
}
else {
ApiWrappers.readSessionStorageDataAsync({
IsTeijiStreamSource: false,
IsTeijiBinarySource: false,
IsTeijiFirebaseSource: true,
})
.then((storage) => {
if (storage.IsTeijiStreamSource) {
const parentVideoGamenTeiji = window.opener.document.getElementById('videoGamenTeiji');
if (parentVideoGamenTeiji) {
try {
videoGamenTeiji.srcObject = parentVideoGamenTeiji.srcObject;
videoGamenTeiji.volume = 0;
videoGamenTeiji.play();
}
catch (err) {
const errorMsg = 'ERROR - setDisplayMode()  画面提示ストリームにより再生開始失敗.' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
}
}
else {
try {
videoGamenTeiji.srcObject = currentTeijiCanvas.captureStream();
videoGamenTeiji.volume = 0;
videoGamenTeiji.play();
const ctx = currentTeijiCanvas.getContext('2d');
ctx.fillStyle = 'rgb(93, 93, 93)';
ctx.fillRect(0, 0, currentTeijiCanvas.width, currentTeijiCanvas.height);
ctx.font = '36px serif';
ctx.textAlign = 'right';
ctx.textBaseline = 'bottom';
ctx.fillStyle = 'gainsboro';
ctx.fillText('Now Loading...', (currentTeijiCanvas.width - 32), (currentTeijiCanvas.height - 32));
}
catch (err) {
const errorMsg = 'ERROR - setDisplayMode()  画面提示画像により再生開始失敗.' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
}
divGamenTeiji.style.visibility = 'visible';
divGamenLockImage.style.visibility = 'hidden';
divFlexibleMessages.style.visibility = 'hidden';
divPoweredBy.style.visibility = 'hidden';
document.title = Utils.getLocaleMessage('title_nowInGamenTeiji');
if ((storage.IsTeijiBinarySource) || (storage.IsTeijiFirebaseSource)) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, { cmd: 'ResendChangedTeijiImage' });
}
});
}
}
else if (currentDisplayMode === DisplayModes.GAMEN_LOCK) {
if (videoGamenTeiji.srcObject) {
if (! videoGamenTeiji.paused) {
videoGamenTeiji.pause();
}
videoGamenTeiji.srcObject = null;
}
divPoweredBy.style.visibility = 'hidden';
document.title = Utils.getLocaleMessage('title_nowInLocked');
changeCursor(CursorTypes.NONE);
ApiWrappers.readSessionStorageDataAsync({
LockType: '',
LockText: '',
LockFontColor: '#f0f0f0',
LockBgColor: '#202020'
})
.then((storage) => {
Utils.removeFlexibleMessage(divFlexibleMessages);
currentLockType = (storage.LockType) ? storage.LockType.toLowerCase() : '';
currentMessageText = (storage.LockText) ? storage.LockText : '';
if (currentMessageText) {
currentMessageText = Utils.escapeHtmlStr(currentMessageText);
}
if (currentLockType === 'text') {
currentMessageColor = (storage.LockFontColor) ? storage.LockFontColor : '#f0f0f0';
divGamenTeiji.style.visibility = 'hidden';
divGamenLockImage.style.visibility = 'hidden';
divFlexibleMessages.style.backgroundColor = (storage.LockBgColor) ? storage.LockBgColor : '#202020';
divFlexibleMessages.style.visibility = 'visible';
updateFlexibleMessage();
}
else {
divGamenTeiji.style.visibility = 'hidden';
divFlexibleMessages.style.visibility = 'hidden';
divGamenLockImage.style.visibility = 'visible';
divGamenLockImage.style.backgroundColor = '#202020';
Utils.removeFlexibleMessage(divFlexibleMessages);
let imageFileName;
switch (currentLockType) {
case 'image2':
case 'image3':
case 'image4':
case 'image5':
imageFileName = 'LockImg'.concat(currentLockType.substring(5), '.jpg');
break;
default:
imageFileName = 'LockImg1.jpg';
break;
}
divGamenLockImage.style.backgroundImage = `url("./assets/${imageFileName}")`;
}
});
}
else {
currentDisplayMode = DisplayModes.INITIAL;
divPoweredBy.style.visibility = 'visible';
document.title = Utils.getLocaleMessage('ext_title');
}
}
catch (err) {
const errorMsg = 'ERROR - setDisplayMode()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.FATAL);
}
};
const openPipGamenTeijiAsync = () => {
const fnEnterPip = (event) => {
try {
ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenAttentionPageEnds: WINDOW_ID_NONE,
TabIdToActiveWhenAttentionPageEnds: TAB_ID_NONE,
})
.then(() => {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ChangeAttentionPageWindowState',
newState: 'minimized'
});
})
.then(() => {
});
}
catch (err) {
const errorMsg = 'ERROR - openPipGamenTeijiAsync() - fnEnterPip()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
};
};
const fnLeavePip = (event) => {
try {
event.target.removeAttribute('__pip__');
pipGamenTeijiWindow = null;
isShowedPipGamenTeiji = false;
ApiWrappers.saveSessionStorageDataAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE })
.then(() => {
return LogManager.putLogAsync('【attention】画面提示のピクチャインピクチャを抜けました.', LogLevels.INFO);
})
.then(() => {
enabledPageClick.isEnabled = false;
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ChangeAttentionPageWindowState',
newState: 'fullscreen'
});
})
.then(() => {
setTimeout((obj) => {
obj.isEnabled = true;
}, 700, enabledPageClick);
});
}
catch (err) {
const errorMsg = 'ERROR - openPipGamenTeijiAsync() - fnLeavePip()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
};
};
const fnStartPipAsync = (video) => {
return new Promise((resolve) => {
video.addEventListener('enterpictureinpicture', fnEnterPip, { once: true });
video.requestPictureInPicture()
.then((window) => {
pipGamenTeijiWindow = window;
video.setAttribute('__pip__', true);
video.addEventListener('leavepictureinpicture', fnLeavePip, { once: true });
const observer = new ResizeObserver((entries) => {
if (entries.length > 0) {
let element = entries[0].target;
if (! document.querySelector('[__pip__]')) {
observer.unobserve(element);
return;
}
const videoGamenTeiji = document.getElementById('videoGamenTeiji');
if ((videoGamenTeiji) && (! videoGamenTeiji.hasAttribute('__pip__'))) {
observer.unobserve(videoGamenTeiji);
fnStartPipAsync(videoGamenTeiji);
}
}
});
observer.observe(video);
resolve(true);
})
.catch((err) => {
const errorMsg = 'ERROR - openPipGamenTeijiAsync() - fnStartPipAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
resolve(false);
});
});
};
return new Promise((resolve) => {
let videoGamenTeiji = null;
try {
videoGamenTeiji = document.getElementById('videoGamenTeiji');
if (! videoGamenTeiji) {
resolve(false);
return;
}
if (thinningOutMouseMoveTimerId !== TIMER_ID_NONE) {
clearTimeout(thinningOutMouseMoveTimerId);
thinningOutMouseMoveTimerId = TIMER_ID_NONE;
changeCursor(CursorTypes.NONE);
}
ApiWrappers.readSessionStorageValueAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE })
.then((value) => {
if (value !== WINDOW_ID_NONE) {
throw new MyError('AlreadyShowedPipGamenTeiji');
}
putLog('ユーザーの操作により画面提示をピクチャインピクチャに切り替えます.', LogLevels.INFO);
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
return document.exitPictureInPicture();
}
})
.then(() => {
pipGamenTeijiWindow = null;
return fnStartPipAsync(videoGamenTeiji);
})
.then((result) => {
isShowedPipGamenTeiji = result;
if (isShowedPipGamenTeiji) {
return ApiWrappers.saveSessionStorageDataAsync({ PipGamenTeijiWindowId: selfWindowId });
}
})
.then(() => {
resolve(isShowedPipGamenTeiji);
})
.catch((err) => {
if ((err instanceof MyError) && (err.message === 'AlreadyShowedPipGamenTeiji')) {
putLog('ピクチャインピクチャ画面提示を既に表示中のためユーザーの操作を無視しました.', LogLevels.INFO);
}
else {
putLog(`ERROR - openPipGamenTeijiAsync() : ${err.message || err || ''}`, LogLevels.INFO);
}
});
}
catch (err) {
const errorMsg = 'ERROR - openPipGamenTeijiAsync()' + ((err) ? ` : ${err.message || err}` : '');
putLog(errorMsg, LogLevels.INFO);
resolve(false);
};
});
};
window.addEventListener('load', async () => {
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verAttention = (typeof JSFILEVER_attention === 'string') ? JSFILEVER_attention : 'Undefined';
if (verAttention === currentVersion) {
logMsg = `★Program file check <4> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <4> -- [currentVer=${currentVersion}]  attention.js=${verAttention}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【attention】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
try {
let selfPageKey;
const tempIndex = document.location.href.indexOf('?');
if (tempIndex > 0) {
const urlArgs = document.location.href.substring(tempIndex + 1).split('&');
urlArgs.forEach((arg) => {
if (arg.startsWith('pid=')) {
const pid = Number(arg.substring(4));
if (! isNaN(pid))  selfPageId = pid;
}
else if (arg.startsWith('primary=')) {
isPrimaryScreen = (arg.substring(8) === 'true');
}
else if (arg.startsWith('key=')) {
selfPageKey = arg.substring(4);
}
});
}
if ((selfPageId === 0) || (! selfPageKey)) {
throw new Error('Invalid url parameter.');
}
if ((isPrimaryScreen) && ((! window.opener) || (window.opener.closed))) {
throw new Error('Not found parent window.');
}
createInternalMessageListener();
let currentWindow = await ApiWrappers.getCurrentWindowAsync({ populate: true }, true);
selfWindowId = currentWindow.id;
let selfTabId = TAB_ID_NONE;
if ((currentWindow.tabs) && (currentWindow.tabs.length > 0)) {
selfTabId = currentWindow.tabs[0].id;
}
if (currentWindow.state !== 'fullscreen') {
const tempWindow = await ApiWrappers.updateWindowAsync(selfWindowId, { state: 'fullscreen' });
Utils.assert((!! tempWindow), 'ERROR updateWindowAsync 失敗.');
}
const storage1 = await ApiWrappers.readLocalStorageDataAsync({
DebugTestModeA: 0,
DebugTestModeB: 0,
DebugTestModeC: 0,
}, true);
const storage2 = await ApiWrappers.readSessionStorageDataAsync({
OsType: OsTypes.UNKNOWN,
IsDeveloperMode: false,
DebugTraceLevel: TraceLevels.UNSET,
AttentionPageMode: '',
IsAllowedPipGamenTeiji: false,
ClientCoreTabId: TAB_ID_NONE,
}, true);
clientCoreTabId = storage2.ClientCoreTabId;
if (clientCoreTabId === TAB_ID_NONE) {
throw new Error('Rejected ShownAttentionPage. ClientCoreTabId is None.');
}
const msgResponse = await ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ShownAttentionPage',
pageId: selfPageId,
pageKey: selfPageKey,
windowId: selfWindowId,
tabId: selfTabId,
primary: isPrimaryScreen
}, true);
if (msgResponse?.accepted !== true) {
throw new Error('Rejected ShownAttentionPage.');
}
debugTestMode[0] = storage1.DebugTestModeA;
debugTestMode[1] = storage1.DebugTestModeB;
debugTestMode[2] = storage1.DebugTestModeC;
osType = storage2.OsType;
isDeveloperMode = storage2.IsDeveloperMode;
debugTraceLevel = storage2.DebugTraceLevel;
enabledPageClick.isEnabled = (isPrimaryScreen === true);
if (selfPageId === 1) {
let programVersionCheckedFlags = await ApiWrappers.readLocalStorageValueAsync({ ProgramVersionCheckedFlags: 0 }) || 0;
if (0 === (programVersionCheckedFlags & 0x08)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x08) | 0x08;
await ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags });
if (! Utils.isSkipCheckProgramFileVersion()) {
await fnCheckProgramFileVersionAsync();
}
}
}
currentTeijiCanvas = document.createElement('canvas');
currentTeijiCanvas.width = 1366;
currentTeijiCanvas.height = 768;
let requestedDisplayMode = DisplayModes.INITIAL;
if (storage2.AttentionPageMode === 'lock') {
requestedDisplayMode = DisplayModes.GAMEN_LOCK;
document.title = Utils.getLocaleMessage('title_nowInLocked');
}
else if (storage2.AttentionPageMode === 'teiji') {
isAllowedPipGamenTeiji = storage2.IsAllowedPipGamenTeiji;
requestedDisplayMode = DisplayModes.GAMEN_TEIJI;
document.title = Utils.getLocaleMessage('title_nowInGamenTeiji');
}
else {
setTimeout(() => { window.close(); });
return;
}
disableUserOperation(false);
updatePageLayout();
setTimeout(() => {
setDisplayMode(requestedDisplayMode);
window.addEventListener('resize', () => {
updatePageLayout();
if (currentMessageText) {
updateFlexibleMessage();
}
});
ApiWrappers.readSessionStorageDataAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE }, true)
.then((storage) => {
if (storage.PipGamenTeijiWindowId !== WINDOW_ID_NONE) {
return ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ChangeAttentionPageWindowState',
newState: 'minimized'
});
}
})
.then(() => { });
}, 100);
}
catch (err) {
const errorMsg = '【attention】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
});
window.addEventListener('beforeunload', (ev) => {
if (! isBeforeUnloadFired) {
isBeforeUnloadFired = true;
if ((pipGamenTeijiWindow) && (document.pictureInPictureElement)) {
document.exitPictureInPicture();
pipGamenTeijiWindow = null;
}
if (isShowedPipGamenTeiji) {
ApiWrappers.saveSessionStorageDataAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE }).then(() => {});
isShowedPipGamenTeiji = false;
}
disableUserOperation(true);
}
});
window.addEventListener('error', (ev) => {
const errorMsg = '【attention】WINDOW ERROR (Attention) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
