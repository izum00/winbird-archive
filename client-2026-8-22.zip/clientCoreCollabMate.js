'use strict';
const JSFILEVER_clientCoreCollabMate = '3.2.1.1001';
import './library/firebase-app.js';
import './library/firebase-functions.js';
export class ClientCoreCollabMate {
static getJsFileVersion() {
return (typeof JSFILEVER_clientCoreCollabMate === 'string') ? JSFILEVER_clientCoreCollabMate : 'Undefined';
}
constructor(cData, cAux, timer) {
this._cData = cData;
this._cAux = cAux;
this._timer = timer;
this._putLog = this._putLog.bind(this);
this._uploadR2ImageAsync = this._uploadR2ImageAsync.bind(this);
this.captureForCollabMateAsync = this.captureForCollabMateAsync.bind(this);
this.openCollabMatePageAsync = this.openCollabMatePageAsync.bind(this);
this.writeCollabMateImageAsync = this.writeCollabMateImageAsync.bind(this);
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
_uploadR2ImageAsync(targetCtrlInfo, groupId, guestId, entryId, base64Image) {
return new Promise((resolve) => {
let workFirebaseApp = null;
return Promise.resolve()
.then(() => {
let encryptedBase64;
try {
const password = this._cData.signedUserEmail.split('@')[0];
encryptedBase64 = CryptoJS.Rabbit.encrypt(base64Image, password).toString();
workFirebaseApp = firebase.apps.find((v) => (v.name === 'CollabMate') && (! v.checkDestroyed_()));
if (! workFirebaseApp) {
workFirebaseApp = firebase.initializeApp(ExtraConstants.CollabMate_FirebaseConfig, 'CollabMate');
}
if (! workFirebaseApp) {
throw new Error('Firebase app 取得失敗.');
}
}
catch (err) {
throw new Error(err?.message || '原因不明');
}
const tempFunction = workFirebaseApp.functions('asia-northeast2');
const collabMateFunc = tempFunction.httpsCallable('collabMateFunc');
const params = {
funcNo: 20,
hostId: targetCtrlInfo.collabMateHostId,
roomId: targetCtrlInfo.collabMateRoomId,
entryId: entryId,
rtdbName: targetCtrlInfo.collabMateRtdbName,
mail: this._cData.signedUserEmail,
guestId: guestId,
groupId: groupId,
object: encryptedBase64
};
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
let tempParams = Object.assign({}, params);
tempParams.object = '...';
this._putLog(`collabMateFunc ファンクション呼び出し.  ${JSON.stringify(tempParams)}`, LogLevels.INFO);
}
return collabMateFunc(params);
})
.then((result) => {
if (result?.data?.status !== true) {
throw new Error(result?.data?.error || '');
}
this._putLog('コラボメイトＲ２へ画像をアップロードしました.', LogLevels.INFO);
resolve(true);
})
.catch((err) => {
this._putLog('コラボメイトＲ２への画像をアップロードに失敗しました.' + ((err) ? `  理由: ${err.message || err}` : ''), LogLevels.FATAL);
resolve(false);
});
});
}
captureForCollabMateAsync(targetCtrlInfo, timeout) {
return new Promise(async(resolve) => {
if (targetCtrlInfo.collabMateCaptureState !== CollabMateCaptureStates.NONE) {
this._putLog('前回のコラボメイト用画面キャプチャ要求が処理中のためキャプチャできません.', LogLevels.INFO);
resolve(false);
return;
}
const beginTime = window.performance.now();
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.REQUESTED;
while (targetCtrlInfo.collabMateCaptureState !== CollabMateCaptureStates.NONE) {
const elapsedTime = Math.trunc(window.performance.now() - beginTime);
if (elapsedTime > timeout) {
targetCtrlInfo.collabMateCapturedCanvas = null;
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.NONE;
this._putLog('コラボメイト用画面キャプチャのタイムアウト検出.', LogLevels.INFO);
resolve(true);
return;
}
await new Promise((resolve2) => this._timer.addTimer(125, false, resolve2, true));
};
resolve(true);
});
}
openCollabMatePageAsync(targetCtrlInfo) {
const fnGetCollabMateClientIdAsync = () => {
return new Promise((resolve, reject) => {
CountManager.incrementAsync('CollabMateClientId')
.then((clientId) => {
if (clientId <= Constants.MAX_COLLABMATE_CLIENT_ID) {
resolve(clientId);
}
else {
CountManager.exchangeAsync('CollabMateClientId', 1)
.then(() => {
resolve(1);
})
.catch((err) => {
const errorMsg = 'コラボメイト起動用クライアントIDの採番エラー' + ((err) ? ` : ${err.message || err}` : '');
reject(errorMsg);
});
}
});
});
};
return new Promise((resolve) => {
const hostId = targetCtrlInfo.collabMateHostId;
const roomId = targetCtrlInfo.collabMateRoomId;
let targetUrl;
let browserSeigenWindowId;
let attentionPageMode;
let isShowedPipGamenTeiji;
fnGetCollabMateClientIdAsync()
.then((clientId) => {
targetCtrlInfo.collabMateClientId = String(clientId);
targetUrl = `${ExtraConstants.COLLABMATE_URL_1}?h=${hostId}&r=${roomId}&k=${chrome.runtime.id}&c=${clientId}`;
return ApiWrappers.readSessionStorageDataAsync({
BrowserSeigenWindowId: WINDOW_ID_NONE,
AttentionPageMode: '',
PipGamenTeijiWindowId: WINDOW_ID_NONE,
});
})
.then((storage) => {
browserSeigenWindowId = storage.BrowserSeigenWindowId;
attentionPageMode = storage.AttentionPageMode;
isShowedPipGamenTeiji = (storage.PipGamenTeijiWindowId !== WINDOW_ID_NONE);
return this._cAux.getActiveTabAsync(true);
})
.then((activeTab) => {
if (activeTab) {
return ApiWrappers.getWindowAsync(activeTab.windowId, {}, true);
}
return null;
})
.then((wnd) => {
if (wnd?.type === 'normal') {
return wnd;
}
return ApiWrappers.getAllWindowAsync({windowTypes: ['normal']});
})
.then((wnds) => {
let targetWindow = null;
if (Array.isArray(wnds)) {
targetWindow = wnds.find((w) => ((w.focused) && (w.id !== browserSeigenWindowId)));
if (! targetWindow) {
targetWindow = wnds.find((w) => (w.id !== browserSeigenWindowId));
}
}
else {
targetWindow = wnds;
}
if (targetWindow?.state === 'minimized') {
const updateInfo = {
state: 'normal',
focused: true
};
return ApiWrappers.updateWindowAsync(targetWindow.id, updateInfo, true);
}
return targetWindow;
})
.then((wnd) => {
if (wnd) {
const createProperties = {
windowId: wnd.id,
url: targetUrl
};
return ApiWrappers.createTabAsync(createProperties, true);
}
else {
const createData = {
url: targetUrl,
focused: true,
type: 'normal'
};
return ApiWrappers.createWindowAsync(createData, true);
}
})
.then((result) => {
this._putLog('コラボメイト起動成功', LogLevels.INFO);
if ((attentionPageMode === 'lock') || ((attentionPageMode === 'teiji') && (! isShowedPipGamenTeiji))) {
let startedWindowId = WINDOW_ID_NONE;
let startedTabId = TAB_ID_NONE;
if (result?.tabs?.length) {
startedWindowId = result.id;
startedTabId = result.tabs[0].id;
}
else {
startedWindowId = result.windowId;
startedTabId = result.id;
}
return ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenAttentionPageEnds: startedWindowId,
TabIdToActiveWhenAttentionPageEnds: startedTabId,
});
}
})
.then(() => {
let promises = [];
this._cData.currentClassworkPages.forEach((pageInfo) => {
if ((pageInfo.currentPageWindowId !== WINDOW_ID_NONE) && (pageInfo.currentWindowState !== 'minimized')) {
const windowId = pageInfo.currentPageWindowId;
promises.push(ApiWrappers.updateWindowAsync(windowId, { focused: true }, true));
}
});
this._cData.currentAttentionPages.forEach((pageInfo) => {
if ((pageInfo.currentPageWindowId !== WINDOW_ID_NONE) && (pageInfo.currentWindowState !== 'minimized')) {
const windowId = pageInfo.currentPageWindowId;
promises.push(ApiWrappers.updateWindowAsync(windowId, { focused: true }, true));
}
});
if (promises.length > 0) {
return Promise.allSettled(promises);
}
})
.then(() => {
resolve(true);
})
.catch((err) => {
const errorMsg = 'ERROR - openCollabMatePageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve(false);
})
});
};
writeCollabMateImageAsync(targetCtrlInfo, groupId, guestId, entryId) {
const fnConvertBase64ImageAsync = (canvas) => {
return new Promise((resolve, reject) => {
canvas.convertToBlob({ type: 'image/jpeg', quality: 0.75 })
.then((blob) => {
if (! blob)  return Promise.reject('failed convert Blob.');
const reader = new FileReader();
reader.onload = () => {
resolve(reader.result);
};
reader.onerror = () => {
reject('failed Blob read.');
};
reader.readAsDataURL(blob);
})
.catch((err) => {
reject('failed convert base64' + ((err) ? ` : ${err.message || err}` : '.'));
});
});
};
return new Promise((resolve) => {
let capturedCanvas;
if (targetCtrlInfo.collabMateCapturedCanvas !== null) {
capturedCanvas = new OffscreenCanvas(targetCtrlInfo.collabMateCapturedCanvas.width, targetCtrlInfo.collabMateCapturedCanvas.height);
Utils.transferImage(capturedCanvas, null, targetCtrlInfo.collabMateCapturedCanvas);
}
else {
capturedCanvas = new OffscreenCanvas(64, 36);
this._cAux.fillCanvas(capturedCanvas, false);
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('コラボメイト用のキャプチャ済み画像が空のため青画面をキャプチャ済み画像にしました.', LogLevels.INFO);
}
}
fnConvertBase64ImageAsync(capturedCanvas)
.then((base64Image) => {
return this._uploadR2ImageAsync(targetCtrlInfo, groupId, guestId, entryId, base64Image);
})
.then((result) => {
resolve(result);
})
.catch((err) => {
const errorMsg = 'ERROR - writeCollabMateImageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve(false);
});
});
};
}
