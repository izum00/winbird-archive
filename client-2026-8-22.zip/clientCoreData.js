'use strict';
const JSFILEVER_clientCoreData = '3.2.1.1001';
class ClientCoreData {
constructor() {
this._delayGetNightLimitPolicy = Math.round(Math.random() * 600);
this._isExperiencedSleep = false;
this._isShowedWaitPolicyWindow = false;
this._isInitializedSigLib = false;
this._failedInitializeSigLibCounter = 0;
this._onlineNotificationState = 0;
this._isConnectingFirebase = false;
this._isWaitingBrowserOnline = false;
this._isWaitingExtensionPolicy = false;
this._isNeedsAutoUploadLog = false;
this._cbtModeInfo = null;
this._cbtModeBlockedInfo = null;
this._isCbtMode = false;
this._isCbtModeAlwaysDesktopJunshi = false;
this._isCbtModeAlwaysBrowserMaximize = false;
this._isCbtModeAlwaysBrowserOnTop = false;
this._isVerifiedSigConfig = false;
this._isAvailableTime = false;
this._isNightLimitMode = false;
this._isJoinedClasswork = false;
this._isConfirmingJoinClasswork = false;
this._isConfirmingScreenSharing = false;
this._isGamenLockMode = false;
this._isGamenTeijiMode = false;
this._appliedBrowserSeigen = BrowserSeigens.NONE;
this._sigConfigDbName = null;
this._isNeedsUploadBrowsingHistory = false;
this.selfWindowId = WINDOW_ID_NONE;
this.selfTabId = TAB_ID_NONE;
this.selfWindowPosInfo = null;
this.clientVersion = '';
this.osType = OsTypes.UNKNOWN;
this.isAcceptedDestroyPage = false;
this.isChromeLockedScreen = false;
this.isRequestedReloadClient = false;
this.isVerifyingSigConfig = false;
this.isReceivedStartClassWithoutTime = false;
this.isNeedsConfirmingJoinClasswork = false;
this.debugTraceLevel = TraceLevels.UNSET;
this.bcReceiver = null;
this.signedUserEmail = '';
this.isDeveloperMode = false;
this.debugTestMode = [0, 0, 0];
this.selfExtensionPrefixUrl = chrome.runtime.getURL('');
this.clientCorePageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.CLIENT_CORE);
this.classworkPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.CLASSWORK);
this.attentionPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.ATTENTION);
this.blockedPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.BLOCKED);
this.browserSeigenPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.BROWSER_SEIGEN);
this.messengerPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.MESSENGER);
this.optionsPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.OPTIONS);
this.phantomPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.CLIENT_PHANTOM);
this.temporaryPageAbsoluteUrl = chrome.runtime.getURL(PageHtmlNames.TEMPORARY);
this.markerPageAbsoluteUrl = `chrome-extension://${ExtraConstants.MARKER_EXTENSION_ID}/${PageHtmlNames.MARKER}`;
this.isChangedDomainSystemId = false;
this.judgeFailedStartCounterResetTimerId = TIMER_ID_NONE;
this.doneLeaveClassworkNotifiedCode = 0;
this.classworkName = '';
this.classworkTeacherName = '';
this.currentFlexibleMessages = [];
this.isUnsupportedGetBattery = false;
this.isUploadingClientLog = false;
this.isRequestedReshowClassworkPages = false;
this.isRequestedReshowAttentionPages = false;
this.currentGamenTeijiImageBase64 = null;
this.currentGamenJunshiType = 'tab';
this.currentBatteryCharging = false;
this.currentBatteryLevel = 0;
this.currentActiveTabUrl = '';
this.currentActiveTabFaviconUrl = '';
this.currentActiveTabTitle = '';
this.maxActiveTabJunshiFrameRate = 4;
this.activeTabCapturedImage = null;
this.lastActiveTabCapturedTime = new Date(0);
this.activeTabJunshiDummyCanvas = null;
this.desktopCapturedStream = null;
this.desktopCapturedVideo = null;
this.desktopCapturedCanvas = null;
this.lastDesktopCapturedTime = new Date(0);
this.desktopCapturedWidth = 1;
this.desktopCapturedAspectRatio = 1.0;
this.markerSourceImageCanvas = null;
this.reconnectFirebaseTimerId = TIMER_ID_NONE;
this.emittoJoinLobbyTimeoutTimerId = TIMER_ID_NONE;
this.checkExistMyFirebaseNodeTimerId = TIMER_ID_NONE;
this.currentClassworkPages = [];
this.currentAttentionPages = [];
this.ctrlCommandQueue = [];
this.isActivedCtrlCommandProcessor = false;
this.browserSeigenCommandQueue = [];
this.isActivedBrowserSeigenProcessor = false;
this.browserSeigenPageKey = '';
this.browserSeigenHiddenInfos = [];
this.isWatchSignalingCtrl = false;
this.watchSignalingCtrlTimerId = TIMER_ID_NONE;
this.ctrlRequestedLockType = null;
this.ctrlRequestedLockText = null;
this.ctrlRequestedLockFontColor = null;
this.ctrlRequestedLockBgColor = null;
this.ctrlRequestedGamenLockMail = null;
this.ctrlRequestedGamenTeijiMail = null;
this.ctrlRequestedBrowserSeigenMail = null;
this.connectedCtrlInfos = [];
this.nightLimitPolicyRequestedYMD = null;
this.nightLimitInfo = null;
this.changedNightLimitInfo = null;
this.isFlashingClientCorePage = false;
this.blockedBrowserTabUrls = {};
this.replaceNewVerClientTimerId = TIMER_ID_NONE;
this.messengerWindowPosInfo = null;
this.thinningSaveMessengerPosInfoTimerId = TIMER_ID_NONE;
this.isLockedMessengerSend = false;
this.unlockMessengerSendTimerId = TIMER_ID_NONE;
this.pendingMessengerPushMessage = null;
this.cliMessengerRequestNumberInfos = {};
this.cliMessengerResponseTimerIds = {};
this.lastCollabMateRequestReceivedData = null;
this.lastCollabMateRequestReceivedTime = new Date(0);
this.lastFocusedWindowId = WINDOW_ID_NONE;
this._notifyChangedClientStatus = this._notifyChangedClientStatus.bind(this);
this.judgeCurrentAttentionPageMode = this.judgeCurrentAttentionPageMode.bind(this);
this.getTraceLogLevel = this.getTraceLogLevel.bind(this);
};
get delayGetNightLimitPolicy() {
return this._delayGetNightLimitPolicy;
}
get isExperiencedSleep() {
return this._isExperiencedSleep;
}
set isExperiencedSleep(value) {
this._isExperiencedSleep = value;
ApiWrappers.saveSessionStorageDataAsync({ IsExperiencedSleep: value }).then(() => {});
}
get isShowedWaitPolicyWindow() {
return this._isShowedWaitPolicyWindow;
}
set isShowedWaitPolicyWindow(value) {
if ((typeof value === 'boolean') && (value !== this._isShowedWaitPolicyWindow)) {
this._isShowedWaitPolicyWindow = value;
ApiWrappers.saveLocalStorageDataAsync({ IsShowedWaitPolicyWindow: value }).then(() => {});
}
}
get isInitializedSigLib() {
return this._isInitializedSigLib;
}
set isInitializedSigLib(value) {
this._isInitializedSigLib = value;
this._notifyChangedClientStatus();
}
get failedInitializeSigLibCounter() {
return this._failedInitializeSigLibCounter;
}
set failedInitializeSigLibCounter(value) {
this._failedInitializeSigLibCounter = value;
this._notifyChangedClientStatus();
}
get onlineNotificationState() {
return this._onlineNotificationState;
}
set onlineNotificationState(value) {
this._onlineNotificationState = value;
this._notifyChangedClientStatus();
}
get isConnectingFirebase() {
return this._isConnectingFirebase;
}
set isConnectingFirebase(value) {
this._isConnectingFirebase = value;
this._notifyChangedClientStatus();
}
get isWaitingBrowserOnline() {
return this._isWaitingBrowserOnline;
}
set isWaitingBrowserOnline(value) {
this._isWaitingBrowserOnline = value;
this._notifyChangedClientStatus();
}
get isWaitingExtensionPolicy() {
return this._isWaitingExtensionPolicy;
}
set isWaitingExtensionPolicy(value) {
this._isWaitingExtensionPolicy = value;
}
get isNeedsAutoUploadLog() {
return this._isNeedsAutoUploadLog;
}
set isNeedsAutoUploadLog(value) {
if ((typeof value === 'boolean') && (value !== this._isNeedsAutoUploadLog)) {
this._isNeedsAutoUploadLog = value;
ApiWrappers.saveLocalStorageDataAsync({ IsNeedsAutoUploadLog: value }).then(() => {});
}
}
get cbtModeInfo() {
return this._cbtModeInfo;
}
set cbtModeInfo(value) {
if ((value === null) || (value instanceof AntiCheatInfo)) {
this._cbtModeInfo = value;
if (value) {
ApiWrappers.saveLocalStorageDataAsync({ CbtModeSettings: value.toString() }).then(() => {});
}
else {
ApiWrappers.removeLocalStorageDataAsync('CbtModeSettings').then(() => {});
}
}
}
get cbtModeBlockedInfo() {
return this._cbtModeBlockedInfo;
}
set cbtModeBlockedInfo(value) {
if (typeof value === 'object') {
this._cbtModeBlockedInfo = value;
if (value) {
ApiWrappers.saveLocalStorageDataAsync({ CbtModeBlockedInfo: value }).then(() => {});
}
else {
ApiWrappers.removeLocalStorageDataAsync('CbtModeBlockedInfo').then(() => {});
}
}
}
get isCbtMode() {
return this._isCbtMode;
}
set isCbtMode(value) {
this._isCbtMode = value;
ApiWrappers.saveSessionStorageDataAsync({ IsCbtMode: value }).then(() => {
this._notifyChangedClientStatus();
});
}
get isCbtModeAlwaysDesktopJunshi() {
return this._isCbtModeAlwaysDesktopJunshi;
}
set isCbtModeAlwaysDesktopJunshi(value) {
this._isCbtModeAlwaysDesktopJunshi = value;
ApiWrappers.saveSessionStorageDataAsync({ IsCbtModeAlwaysDesktop: value }).then(() => {});
}
get isCbtModeAlwaysBrowserMaximize() {
return this._isCbtModeAlwaysBrowserMaximize;
}
set isCbtModeAlwaysBrowserMaximize(value) {
this._isCbtModeAlwaysBrowserMaximize = value;
ApiWrappers.saveSessionStorageDataAsync({ IsCbtModeAlwaysBrowserMaximize: value }).then(() => {});
}
get isCbtModeAlwaysBrowserOnTop() {
return this._isCbtModeAlwaysBrowserOnTop;
}
set isCbtModeAlwaysBrowserOnTop(value) {
this._isCbtModeAlwaysBrowserOnTop = value;
ApiWrappers.saveSessionStorageDataAsync({ IsCbtModeAlwaysBrowserOnTop: value }).then(() => {});
}
get isVerifiedSigConfig() {
return this._isVerifiedSigConfig;
}
set isVerifiedSigConfig(value) {
this._isVerifiedSigConfig = value;
ApiWrappers.saveSessionStorageDataAsync({ IsVerifiedSigConfig: value }).then(() => {});
}
get isAvailableTime() {
return this._isAvailableTime;
}
set isAvailableTime(value) {
this._isAvailableTime = value;
ApiWrappers.saveSessionStorageDataAsync({ IsAvailableTime: value }).then(() => {
this._notifyChangedClientStatus();
});
}
get isNightLimitMode() {
return this._isNightLimitMode;
}
set isNightLimitMode(value) {
this._isNightLimitMode = value;
ApiWrappers.saveSessionStorageDataAsync({ IsNightLimitMode: value }).then(() => {
this._notifyChangedClientStatus();
});
}
get isJoinedClasswork() {
return this._isJoinedClasswork;
}
set isJoinedClasswork(value) {
this._isJoinedClasswork = value;
ApiWrappers.saveSessionStorageDataAsync({ IsJoinedClasswork: value }).then(() => {
this._notifyChangedClientStatus();
});
}
get isConfirmingJoinClasswork() {
return this._isConfirmingJoinClasswork;
}
set isConfirmingJoinClasswork(value) {
this._isConfirmingJoinClasswork = value;
ApiWrappers.saveSessionStorageDataAsync({ IsConfirmingJoinClasswork: value }).then(() => {});
}
get isConfirmingScreenSharing() {
return this._isConfirmingScreenSharing;
}
set isConfirmingScreenSharing(value) {
this._isConfirmingScreenSharing = value;
ApiWrappers.saveSessionStorageDataAsync({ IsConfirmingScreenSharing: value }).then(() => {});
}
get isGamenLockMode() {
return this._isGamenLockMode;
}
set isGamenLockMode(value) {
this._isGamenLockMode = value;
const attentionPageMode = this.judgeCurrentAttentionPageMode();
ApiWrappers.saveSessionStorageDataAsync({
IsGamenLockMode: value,
AttentionPageMode: attentionPageMode,
}).then(() => {});
}
get isGamenTeijiMode() {
return this._isGamenTeijiMode;
}
set isGamenTeijiMode(value) {
this._isGamenTeijiMode = value;
const attentionPageMode = this.judgeCurrentAttentionPageMode();
ApiWrappers.saveSessionStorageDataAsync({
IsGamenTeijiMode: value,
AttentionPageMode: attentionPageMode,
}).then(() => {});
}
get appliedBrowserSeigen() {
return this._appliedBrowserSeigen;
}
set appliedBrowserSeigen(value) {
this._appliedBrowserSeigen = value;
ApiWrappers.saveSessionStorageDataAsync({ AppliedBrowserSeigen: value }).then(() => {});
}
get sigConfigDbName() {
return this._sigConfigDbName;
}
set sigConfigDbName(value) {
this._sigConfigDbName = value;
ApiWrappers.saveSessionStorageDataAsync({ SigConfigDbName: value }).then(() => {});
}
get isNeedsUploadBrowsingHistory() {
return this._isNeedsUploadBrowsingHistory;
}
set isNeedsUploadBrowsingHistory(value) {
this._isNeedsUploadBrowsingHistory = value;
ApiWrappers.saveSessionStorageDataAsync({ IsNeedsUploadBrowsingHistory: value }).then(() => {});
}
_notifyChangedClientStatus() {
Utils.postBroadcastMessage(BcNames.POPUP_PAGE, { cmd: 'ChangedClientStatus' });
}
judgeCurrentAttentionPageMode() {
if (this._isGamenLockMode) {
return 'lock';
}
else if (this._isGamenTeijiMode) {
return 'teiji';
}
return '';
}
getTraceLogLevel(isDetail=false) {
if (this.debugTraceLevel !== TraceLevels.UNSET) {
return ((this.debugTraceLevel === TraceLevels.DEBUG) || (! isDetail)) ? LogLevels.INFO : LogLevels.DEBUG;
}
return LogLevels.DEBUG;
}
}
