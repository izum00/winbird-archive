'use strict';
const JSFILEVER_clientCoreMonitor = '3.2.1.1001';
import { WbTimeLimit } from './library/WbTimeLimit.js';
import './library/firebase-app.js';
import './library/firebase-database.js';
import './library/firebase-firestore.js';
import './library/firebase-functions.js';
export class ClientCoreMonitor {
static getJsFileVersion() {
return (typeof JSFILEVER_clientCoreMonitor === 'string') ? JSFILEVER_clientCoreMonitor : 'Undefined';
}
constructor(cData, cAux, cComm, cFbgJunshi, cFbgSnapshot, timer) {
this._cData = cData;
this._cAux = cAux;
this._cComm = cComm;
this._cFbgJunshi = cFbgJunshi;
this._cFbgSnapshot = cFbgSnapshot;
this._timer = timer;
this._timeLimit = new WbTimeLimit(null, true);
this._isWatchBrowserSeigenWindow = false;
this._watchBrowserSeigenWindowTimerId = TIMER_ID_NONE;
this._isWatchClassworkPages = false;
this._watchClassworkPagesTimerId = TIMER_ID_NONE;
this._classworkScreenInfoString = '';
this._isWatchAttentionPages = false;
this._watchAttentionPagesTimerId = TIMER_ID_NONE;
this._attentionScreenInfoString = '';
this._isWatchCoreWindowState = false;
this._watchCoreWindowStateTimerId = TIMER_ID_NONE;
this._isWatchClientState = false;
this._watchClientStateTimerId = TIMER_ID_NONE;
this._isWatchCbtMode = false;
this._watchCbtModeTimerId = TIMER_ID_NONE;
this._isWatchCbtOpeningMessage = false;
this._watchCbtOpeningMessageTimerId = TIMER_ID_NONE;
this._cbtOpeningMessageBaseMsec = -1;
this._isWatchAvailableTime = false;
this._watchAvailableTimeTimerId = TIMER_ID_NONE;
this._isWatchNightLimit = false;
this._watchNightLimitTimerId = TIMER_ID_NONE;
this._readNightLimitPolicyTimerId = TIMER_ID_NONE;
this._changeDesktopCaptureTimerId = TIMER_ID_NONE;
this._firestorePolicyDb = null;
this._putLog = this._putLog.bind(this);
this._isBetweenTimeSeconds = this._isBetweenTimeSeconds.bind(this);
this._watchClassworkPages = this._watchClassworkPages.bind(this);
this._watchAttentionPages = this._watchAttentionPages.bind(this);
this._watchCoreWindowState = this._watchCoreWindowState.bind(this);
this._watchBrowserSeigenWindow = this._watchBrowserSeigenWindow.bind(this);
this._watchActiveTab = this._watchActiveTab.bind(this);
this._watchDesktopGamen = this._watchDesktopGamen.bind(this);
this._watchClientState = this._watchClientState.bind(this);
this._watchCbtMode = this._watchCbtMode.bind(this);
this._watchCbtOpeningMessage = this._watchCbtOpeningMessage.bind(this);
this._watchAvailableTime = this._watchAvailableTime.bind(this);
this._watchNightLimit = this._watchNightLimit.bind(this);
this._requestChangeBrowserSeigen = this._requestChangeBrowserSeigen.bind(this);
this._uploadClientLogAsync = this._uploadClientLogAsync.bind(this);
this._reshowClassworkPagesAsync = this._reshowClassworkPagesAsync.bind(this);
this._reshowAttentionPagesAsync = this._reshowAttentionPagesAsync.bind(this);
this.startWatchBrowserSeigenWindow = this.startWatchBrowserSeigenWindow.bind(this);
this.stopWatchBrowserSeigenWindow = this.stopWatchBrowserSeigenWindow.bind(this);
this.showClassworkPages = this.showClassworkPages.bind(this);
this.closeClassworkPagesAsync = this.closeClassworkPagesAsync.bind(this);
this.waitClosedClassworkPagesAsync = this.waitClosedClassworkPagesAsync.bind(this);
this.startWatchClassworkPages = this.startWatchClassworkPages.bind(this);
this.stopWatchClassworkPages = this.stopWatchClassworkPages.bind(this);
this.showAttentionPages = this.showAttentionPages.bind(this);
this.closeAttentionPagesAsync = this.closeAttentionPagesAsync.bind(this);
this.waitClosedAttentionPagesAsync = this.waitClosedAttentionPagesAsync.bind(this);
this.requestUpdateAttentionPages = this.requestUpdateAttentionPages.bind(this);
this.startWatchAttentionPages = this.startWatchAttentionPages.bind(this);
this.stopWatchAttentionPages = this.stopWatchAttentionPages.bind(this);
this.startWatchCoreWindowState = this.startWatchCoreWindowState.bind(this);
this.stopWatchCoreWindowState = this.stopWatchCoreWindowState.bind(this);
this.startWatchActiveTab = this.startWatchActiveTab.bind(this);
this.stopWatchActiveTab = this.stopWatchActiveTab.bind(this);
this.startWatchDesktopGamen = this.startWatchDesktopGamen.bind(this);
this.stopWatchDesktopGamen = this.stopWatchDesktopGamen.bind(this);
this.startWatchClientState = this.startWatchClientState.bind(this);
this.stopWatchClientState = this.stopWatchClientState.bind(this);
this.startWatchCbtMode = this.startWatchCbtMode.bind(this);
this.stopWatchCbtMode = this.stopWatchCbtMode.bind(this);
this.startWatchCbtOpeningMessage = this.startWatchCbtOpeningMessage.bind(this);
this.stopWatchCbtOpeningMessage = this.stopWatchCbtOpeningMessage.bind(this);
this.advanceWatchCbtMode = this.advanceWatchCbtMode.bind(this);
this.startWatchAvailableTime = this.startWatchAvailableTime.bind(this);
this.stopWatchAvailableTime = this.stopWatchAvailableTime.bind(this);
this.startWatchNightLimit = this.startWatchNightLimit.bind(this);
this.stopWatchNightLimit = this.stopWatchNightLimit.bind(this);
this.changeDesktopCapture = this.changeDesktopCapture.bind(this);
this.cancelChangeDesktopCapture = this.cancelChangeDesktopCapture.bind(this);
this.setDesktopGamenJunshi = this.setDesktopGamenJunshi.bind(this);
this.collectTabsIntoBrowserAsync = this.collectTabsIntoBrowserAsync.bind(this);
this.terminateCbtModeAsync = this.terminateCbtModeAsync.bind(this);
this.showCbtOpeningMessageAsync = this.showCbtOpeningMessageAsync.bind(this);
this.closeCbtOpeningMessageAsync = this.closeCbtOpeningMessageAsync.bind(this);
this.showPendingMessengerPushNotificationAsync = this.showPendingMessengerPushNotificationAsync.bind(this);
}
get timeLimit() {
return this._timeLimit;
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
_isBetweenTimeSeconds(current, begin, end) {
if (begin < end) {
if ((current >= begin) && (current < end)) {
return true;
}
}
else if (begin > end) {
if ((current >= begin) || (current < end)) {
return true;
}
}
return false;
}
_watchClassworkPages() {
if (! this._isWatchClassworkPages)  return;
this._watchClassworkPagesTimerId = TIMER_ID_NONE;
ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode)
.then((screenInfos) => {
if ((this._cData.isConfirmingJoinClasswork) || (this._cData.isConfirmingScreenSharing)) {
const currentScreenInfoString = this._cAux.makeScreenInfoString(screenInfos);
if (currentScreenInfoString !== this._classworkScreenInfoString) {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog(`_watchClassworkPages()   表示開始時の画面条件: ${this._classworkScreenInfoString}   現在の画面条件: ${currentScreenInfoString}`, LogLevels.INFO);
}
this._putLog('授業ページ監視中に画面条件の変更を検出しました.', LogLevels.INFO);
this._cData.isRequestedReshowClassworkPages = true;
this.stopWatchClassworkPages();
this._reshowClassworkPagesAsync().then(()=>{});
throw new MyError('ChangedScreenInfo');
}
}
return ApiWrappers.getAllWindowAsync({ windowTypes: ['popup'] }, true);
})
.then((wnds) => {
let refreshTargetPages = [];
wnds.forEach((wnd) => {
const hitPageInfo = this._cData.currentClassworkPages.find((v) => v.currentPageWindowId === wnd.id);
if (hitPageInfo) {
if ((hitPageInfo.currentWindowState !== '') && (wnd.state !== hitPageInfo.currentWindowState)) {
refreshTargetPages.push(hitPageInfo);
}
else if ((hitPageInfo.isPrimary) && (! hitPageInfo.isDuplicate)) {
if ((hitPageInfo.activeWindowStat !== 'minimized') && (! wnd.focused)) {
refreshTargetPages.push(hitPageInfo);
}
}
}
});
refreshTargetPages.forEach((pageInfo) => {
let updateInfo = {state: pageInfo.currentWindowState};
if ((pageInfo.isPrimary) && (! pageInfo.isDuplicate) && (pageInfo.currentWindowState !== 'minimized')) {
updateInfo.focused = true;
}
ApiWrappers.updateWindowAsync(pageInfo.currentPageWindowId, updateInfo).then(() => {});
});
this._cData.currentClassworkPages.forEach((info) => {
if (info.openRequestTimeout > 0) {
info.openRequestTimeout = info.openRequestTimeout - 1;
if (info.openRequestTimeout === 0) {
info.openRequestTimeout = -1;
this._putLog(`CLASSWORKページ(Page:${info.id})のオープン要求タイムアウトを検知したため、再表示します.`, LogLevels.INFO);
this.showClassworkPages(info);
}
}
});
})
.catch((err) => {
if ((err instanceof MyError) && (err.message === 'ChangedScreenInfo')) {
}
else {
this._putLog(`ERROR - _watchClassworkPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
})
.finally(() => {
if (this._isWatchClassworkPages) {
this._isWatchClassworkPages = this.stopWatchClassworkPages();
if (this._isWatchClassworkPages) {
this._watchClassworkPagesTimerId = this._timer.addTimer(950, false, this._watchClassworkPages);
}
}
});
}
_watchAttentionPages() {
if (! this._isWatchAttentionPages)  return;
this._watchAttentionPagesTimerId = TIMER_ID_NONE;
let isShowedPipGamenTeiji;
ApiWrappers.readSessionStorageValueAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE })
.then((value) => {
isShowedPipGamenTeiji = (value !== WINDOW_ID_NONE);
return ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode);
})
.then((screenInfos) => {
const currentScreenInfoString = this._cAux.makeScreenInfoString(screenInfos);
if (currentScreenInfoString !== this._attentionScreenInfoString) {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog(`_watchAttentionPages()   表示開始時の画面条件: ${this._attentionScreenInfoString}   現在の画面条件: ${currentScreenInfoString}`, LogLevels.INFO);
}
this._putLog('アテンションページ監視中に画面条件の変更を検出しました.', LogLevels.INFO);
this._cData.isRequestedReshowAttentionPages = true;
this.stopWatchAttentionPages();
this._reshowAttentionPagesAsync().then(()=>{});
throw new MyError('ChangedScreenInfo');
}
if ((! isShowedPipGamenTeiji) && (this._cData.lastFocusedWindowId !== WINDOW_ID_NONE)) {
if (-1 === this._cData.currentAttentionPages.findIndex((v) => v.currentPageWindowId === this._cData.lastFocusedWindowId)) {
this._cData.lastFocusedWindowId = WINDOW_ID_NONE;
let promises = [];
this._cData.currentAttentionPages.forEach((pageInfo) => {
if (! pageInfo.isPrimary) {
const windowId = pageInfo.currentPageWindowId;
promises.push(ApiWrappers.updateWindowAsync(windowId, { focused: true }, true));
}
});
if (promises.length > 0) {
return Promise.allSettled(promises);
}
}
else {
this._cData.lastFocusedWindowId = WINDOW_ID_NONE;
}
}
})
.then(() => {
return ApiWrappers.getAllWindowAsync({ windowTypes: ['popup'] }, true);
})
.then((wnds) => {
let primaryMainWindowId = WINDOW_ID_NONE;
let primaryMainWindowState = '';
let primaryDuplicateWindowId = WINDOW_ID_NONE;
let primaryDuplicateWindowState = '';
let refreshTargetPages = [];
wnds.forEach((wnd) => {
const hitPageInfo = this._cData.currentAttentionPages.find((v) => v.currentPageWindowId === wnd.id);
if (hitPageInfo) {
if ((hitPageInfo.isPrimary) && (hitPageInfo.currentWindowState !== 'minimized')) {
if (hitPageInfo.isDuplicate) {
primaryDuplicateWindowId = hitPageInfo.currentPageWindowId;
if ((hitPageInfo.currentWindowState !== '') && (wnd.state !== hitPageInfo.currentWindowState)) {
primaryDuplicateWindowState = hitPageInfo.currentWindowState;
}
}
else {
primaryMainWindowId = hitPageInfo.currentPageWindowId;
if ((hitPageInfo.currentWindowState !== '') && (wnd.state !== hitPageInfo.currentWindowState)) {
primaryMainWindowState = hitPageInfo.currentWindowState;
}
}
}
else {
if ((hitPageInfo.currentWindowState !== '') && (wnd.state !== hitPageInfo.currentWindowState)) {
refreshTargetPages.push(hitPageInfo);
}
}
}
});
refreshTargetPages.forEach((pageInfo) => {
let updateInfo = { state: pageInfo.currentWindowState };
ApiWrappers.updateWindowAsync(pageInfo.currentPageWindowId, updateInfo).then(() => {});
});
if ((isShowedPipGamenTeiji !== true) && (primaryMainWindowId !== WINDOW_ID_NONE)) {
if (primaryDuplicateWindowId !== WINDOW_ID_NONE) {
let updateInfo1 = { focused: true };
if (primaryDuplicateWindowState)  updateInfo1.state = primaryDuplicateWindowState;
ApiWrappers.updateWindowAsync(primaryDuplicateWindowId, updateInfo1).then(() => {});
}
let updateInfo2 = { focused: true };
if (primaryMainWindowState)  updateInfo2.state = primaryMainWindowState;
ApiWrappers.updateWindowAsync(primaryMainWindowId, updateInfo2).then(() => {});
}
this._cData.currentAttentionPages.forEach((info) => {
if (info.openRequestTimeout > 0) {
info.openRequestTimeout = info.openRequestTimeout - 1;
if (info.openRequestTimeout === 0) {
info.openRequestTimeout = -1;
this._putLog(`ATTENTIONページ(Page:${info.id})のオープン要求タイムアウトを検知したため、再表示します.`, LogLevels.INFO);
this.showAttentionPages(info);
}
}
});
})
.catch((err) => {
if ((err instanceof MyError) && (err.message === 'ChangedScreenInfo')) {
}
else {
this._putLog(`ERROR - _watchAttentionPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
})
.finally(() => {
if (this._isWatchAttentionPages) {
this._isWatchAttentionPages = this.stopWatchAttentionPages();
if (this._isWatchAttentionPages) {
this._watchAttentionPagesTimerId = this._timer.addTimer(950, false, this._watchAttentionPages);
}
}
});
}
_watchCoreWindowState() {
if (! this._isWatchCoreWindowState)  return;
this._watchCoreWindowStateTimerId = TIMER_ID_NONE;
let nextWatch = 450;
ApiWrappers.getCurrentWindowAsync({}, true)
.then((wnd) => {
if (! this._cData.isFlashingClientCorePage) {
if ((wnd.state === 'normal') && (this._cData.selfWindowPosInfo !== null)) {
if ((Math.min(wnd.width, wnd.height) < 200)) {
if ((wnd.left !== this._cData.selfWindowPosInfo.left) || (wnd.top !== this._cData.selfWindowPosInfo.top) ||
(wnd.width !== this._cData.selfWindowPosInfo.width) || (wnd.height !== this._cData.selfWindowPosInfo.height)) {
nextWatch = 100;
return ApiWrappers.updateWindowAsync(wnd.id, this._cData.selfWindowPosInfo, true);
}
}
}
if (wnd.state === 'maximized') {
nextWatch = 100;
return ApiWrappers.updateWindowAsync(wnd.id, { state: 'normal' }, true)
}
if (wnd.state !== 'minimized') {
return ApiWrappers.updateWindowAsync(wnd.id, { state: 'minimized' }, true)
}
}
})
.catch((err) => {
this._putLog(`ERROR - _watchCoreWindowState() : ${err.message || err || ''}`, LogLevels.INFO);
if ((typeof err === 'string') && (err.startsWith('Failed updateWindowAsync() : Invalid value for bounds.'))) {
this._cData.selfWindowPosInfo = null;
}
})
.finally(() => {
if (this._isWatchCoreWindowState) {
this._isWatchCoreWindowState = this.stopWatchCoreWindowState();
this._watchCoreWindowStateTimerId = this._timer.addTimer(nextWatch, false, this._watchCoreWindowState);
}
});
}
_watchBrowserSeigenWindow() {
if (! this._isWatchBrowserSeigenWindow)  return;
this._watchBrowserSeigenWindowTimerId = TIMER_ID_NONE;
ApiWrappers.readSessionStorageValueAsync({ BrowserSeigenWindowId: WINDOW_ID_NONE }, true)
.then((browserSeigenWindowId) => {
if (browserSeigenWindowId !== WINDOW_ID_NONE) {
let isSkip = false;
ApiWrappers.getWindowAsync(browserSeigenWindowId, { windowTypes: ['normal'] })
.then(async (wnd) => {
if ((! wnd) || (('state' in wnd) && (wnd.state === 'minimized'))) {
isSkip = true;
return;
}
const wnds = await ApiWrappers.getAllWindowAsync({ windowTypes: ['normal'] });
if (wnds.length >= 2) {
const otherWindow = wnds.find((w) => w.id !== browserSeigenWindowId);
const updateInfo = {
focused: true
};
if (otherWindow.state === 'minimized') {
updateInfo.state = 'normal';
}
return ApiWrappers.updateWindowAsync(otherWindow.id, updateInfo, true);
}
else {
return ApiWrappers.createWindowAsync({
url: ExtraConstants.NEW_TAB_PAGE_URL,
focused: true,
type: 'normal',
state: 'normal'
}, true);
}
})
.then(() => {
if (isSkip) {
return;
}
const updateInfo = {
state: 'minimized',
focused: false
};
return ApiWrappers.updateWindowAsync(browserSeigenWindowId, updateInfo, true);
})
.catch((err) => {
this._putLog(`ERROR - _watchBrowserSeigenWindow() : ${err.message || err || ''}`, LogLevels.INFO);
})
.finally(() => {
if (this._isWatchBrowserSeigenWindow) {
this._isWatchBrowserSeigenWindow = this.stopWatchBrowserSeigenWindow();
this._watchBrowserSeigenWindowTimerId = this._timer.addTimer(500, false, this._watchBrowserSeigenWindow);
}
});
}
}, (err) => {
this._putLog(`ERROR - _watchBrowserSeigenWindow() : ${err.message || err || ''}`, LogLevels.FATAL);
});
}
_watchActiveTab(ctrlMail) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`_watchActiveTab() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
return;
}
if (! targetCtrlInfo.isWatchActiveTab)  return;
if (targetCtrlInfo.isSnapshotWriteWaiting) {
this._cAux.writeSnapshotAsync(this._cFbgSnapshot, ctrlMail).then(() => {});
}
if ((! targetCtrlInfo.isBusyJunshi) || (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED)) {
try {
if ((targetCtrlInfo.gamenJunshiType !== 'tab') && (! targetCtrlInfo.isGamenStreamTransfer())) {
targetCtrlInfo.gamenJunshiType = 'tab';
this._cComm.sendClientState(targetCtrlInfo.mailAddress);
}
let nextTime;
let junshiFrameRate = Math.min(targetCtrlInfo.gamenJunshiFrameRate, this._cData.maxActiveTabJunshiFrameRate);
if (junshiFrameRate > 0) {
if (targetCtrlInfo.isChangedJunshiRequirements) {
targetCtrlInfo.isChangedJunshiRequirements = false;
if (targetCtrlInfo.isFirebaseJunshi) {
targetCtrlInfo.lastFirebaseJunshiWidth = -1;
targetCtrlInfo.lastFirebaseJunshiQuality = -1;
}
nextTime = Date.now();
this._putLog('アクティブタブ監視処理で画面巡視要件変更により巡視処理時刻を調整しました.', this._cData.getTraceLogLevel());
}
else {
let refreshTime = Math.round(1000 / junshiFrameRate);
nextTime = targetCtrlInfo.lastJunshiTime.getTime() + refreshTime;
}
}
else {
nextTime = Number.MAX_VALUE;
}
const now = new Date();
const nowTime = now.getTime();
const elapsedJunshiTime = (nextTime <= nowTime);
let isAcceptedCollabMateCapture = false;
if ((elapsedJunshiTime) || (targetCtrlInfo.snapshotRequestedTime) ||
(targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED)) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED) {
isAcceptedCollabMateCapture = true;
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.ACCEPTED;
}
targetCtrlInfo.isBusyJunshi = true;
let timeoverCaptureTimerId = this._timer.addTimer(Constants.TIMEOUT_CAPTURE_ACTIVE_TAB, false, (ctrlMail) => {
timeoverCaptureTimerId = TIMER_ID_NONE;
this._putLog(`アクティブタブキャプチャのタイムアウト.  (${ctrlMail})`, this._cData.getTraceLogLevel());
if ((isAcceptedCollabMateCapture) && (! targetCtrlInfo.isWatchActiveTab)) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.ACCEPTED) {
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.REQUESTED;
}
isAcceptedCollabMateCapture = false;
return;
}
if (isAcceptedCollabMateCapture) {
isAcceptedCollabMateCapture = false;
targetCtrlInfo.collabMateCapturedCanvas = null;
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.NONE;
return;
}
const info = this._cAux.findCtrlInfoByMail(ctrlMail);
if ((info) && (info.isJunshiCaptured !== false)) {
info.isJunshiCaptured = false;
this._cComm.sendClientCapturedResult(info);
}
}, targetCtrlInfo.mailAddress);
this._cAux.captureActiveTab((width, height, image) => {
if (timeoverCaptureTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(timeoverCaptureTimerId);
}
if ((timeoverCaptureTimerId === TIMER_ID_NONE) || (! image) || (! targetCtrlInfo.isWatchActiveTab)) {
if (targetCtrlInfo.snapshotRequestedTime) {
targetCtrlInfo.snapshotWriteWaitingImage = null;
targetCtrlInfo.isSnapshotWriteWaiting = true;
this._cAux.writeSnapshotAsync(this._cFbgSnapshot, ctrlMail).then(() => {});
}
if (isAcceptedCollabMateCapture) {
if (! targetCtrlInfo.isWatchActiveTab) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.ACCEPTED) {
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.REQUESTED;
}
}
else {
targetCtrlInfo.collabMateCapturedCanvas = null;
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.NONE;
}
targetCtrlInfo.isBusyJunshi = false;
isAcceptedCollabMateCapture = false;
return;
}
if ((! elapsedJunshiTime) || (! targetCtrlInfo.isWatchActiveTab)) {
targetCtrlInfo.isBusyJunshi = false;
return;
}
if (targetCtrlInfo.isJunshiCaptured !== false) {
targetCtrlInfo.isJunshiCaptured = false;
this._cComm.sendClientCapturedResult(targetCtrlInfo);
}
if ((width > 0) && (height > 0)) {
targetCtrlInfo.activeTabJunshiRealWidth = width;
targetCtrlInfo.activeTabJunshiRealAspectRatio = width / height;
let junshiWidth = width;
if (targetCtrlInfo.gamenJunshiWidth !== 0) {
junshiWidth = Math.min(junshiWidth, targetCtrlInfo.gamenJunshiWidth);
}
if ((targetCtrlInfo.isGamenStreamTransfer()) && (this._cAux.getDebugTestMode('B') === 0)) {
if ((junshiWidth & 0x1) !== 0)  junshiWidth--;
}
let canvasAspectRatio = targetCtrlInfo.activeTabJunshiRealAspectRatio;
let canvasHeight = Math.round(junshiWidth / canvasAspectRatio);
if ((targetCtrlInfo.isGamenStreamTransfer()) && (this._cAux.getDebugTestMode('B') === 0)) {
if (canvasHeight < 18) {
canvasHeight = 18;
}
if ((canvasHeight & 0x1) !== 0)  canvasHeight--;
canvasAspectRatio = junshiWidth / canvasHeight;
}
else {
if (canvasHeight < 18) {
canvasHeight = 18;
canvasAspectRatio = junshiWidth / canvasHeight;
}
}
if (targetCtrlInfo.activeTabJunshiCanvas) {
targetCtrlInfo.activeTabJunshiCanvas.width = junshiWidth;
targetCtrlInfo.activeTabJunshiCanvas.height = canvasHeight;
}
targetCtrlInfo.activeTabJunshiCanvasAspectRatio = canvasAspectRatio;
}
if (targetCtrlInfo.activeTabJunshiCanvas === null) {
targetCtrlInfo.lastJunshiTime = now;
targetCtrlInfo.isBusyJunshi = false;
return;
}
if ((targetCtrlInfo.activeTabJunshiRealWidth === 0) ||
(targetCtrlInfo.activeTabJunshiCanvasAspectRatio === targetCtrlInfo.activeTabJunshiRealAspectRatio)) {
this._cAux.fillCanvas(targetCtrlInfo.activeTabJunshiCanvas, false);
if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
}
else {
const ctx = targetCtrlInfo.activeTabJunshiCanvas.getContext('2d');
ctx.fillStyle = 'rgb(93, 93, 93)';
ctx.fillRect(0, 0, targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvas.height);
const drawHeight = Math.max(1, Math.round(targetCtrlInfo.activeTabJunshiCanvas.width / targetCtrlInfo.activeTabJunshiRealAspectRatio));
const drawTop = Math.trunc((targetCtrlInfo.activeTabJunshiCanvas.height - drawHeight) / 2);
ctx.fillStyle = 'rgb(0, 64, 128)';
ctx.fillRect(0, drawTop, targetCtrlInfo.activeTabJunshiCanvas.width, drawHeight);
if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
}
if (targetCtrlInfo.gamenJunshiType !== 'tab') {
if (targetCtrlInfo.isGamenStreamTransfer()) {
Utils.replacePeerVideoStream(targetCtrlInfo.peerConnection, targetCtrlInfo.activeTabJunshiStream);
if (targetCtrlInfo.appliedMaxPeerVideoFrameRate !== Constants.FRAME_RATE_WHEN_ACTIVE_TAB) {
if (Utils.setMaxPeerVideoFrameRate(targetCtrlInfo.peerConnection, Constants.FRAME_RATE_WHEN_ACTIVE_TAB)) {
targetCtrlInfo.appliedMaxPeerVideoFrameRate = Constants.FRAME_RATE_WHEN_ACTIVE_TAB;
}
}
}
targetCtrlInfo.gamenJunshiType = 'tab';
this._cComm.sendClientState(targetCtrlInfo.mailAddress);
}
if (targetCtrlInfo.isGamenStreamTransfer()) {
if ((targetCtrlInfo.activeTabJunshiCanvas) &&
((targetCtrlInfo.appliedActiveTabJunshiWidth !== targetCtrlInfo.activeTabJunshiCanvas.width) ||
(targetCtrlInfo.appliedActiveTabJunshiAspectRatio !== targetCtrlInfo.activeTabJunshiCanvasAspectRatio))) {
Utils.setVideoStreamConstraints(targetCtrlInfo.activeTabJunshiStream,
targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvasAspectRatio, (result) => {
if (result) {
targetCtrlInfo.appliedActiveTabJunshiWidth = targetCtrlInfo.activeTabJunshiCanvas.width;
targetCtrlInfo.appliedActiveTabJunshiAspectRatio = targetCtrlInfo.activeTabJunshiCanvasAspectRatio;
if (targetCtrlInfo.appliedMaxPeerVideoFrameRate !== Constants.FRAME_RATE_WHEN_ACTIVE_TAB) {
if (Utils.setMaxPeerVideoFrameRate(targetCtrlInfo.peerConnection, Constants.FRAME_RATE_WHEN_ACTIVE_TAB)) {
targetCtrlInfo.appliedMaxPeerVideoFrameRate = Constants.FRAME_RATE_WHEN_ACTIVE_TAB;
}
}
}
});
}
}
}
else {
if (isAcceptedCollabMateCapture) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.ACCEPTED) {
targetCtrlInfo.collabMateCapturedCanvas = new OffscreenCanvas(image.width, image.height);
Utils.transferImage(targetCtrlInfo.collabMateCapturedCanvas, null, image);
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.NONE;
}
targetCtrlInfo.isBusyJunshi = false;
return;
}
if (targetCtrlInfo.snapshotRequestedTime) {
targetCtrlInfo.snapshotWriteWaitingImage = new OffscreenCanvas(image.width, image.height);
Utils.transferImage(targetCtrlInfo.snapshotWriteWaitingImage, null, image);
targetCtrlInfo.isSnapshotWriteWaiting = true;
this._cAux.writeSnapshotAsync(this._cFbgSnapshot, ctrlMail).then(() => {});
}
if (! elapsedJunshiTime) {
targetCtrlInfo.isBusyJunshi = false;
return;
}
targetCtrlInfo.activeTabJunshiRealWidth = width;
targetCtrlInfo.activeTabJunshiRealAspectRatio = width / height;
let requestedJunshiWidth = targetCtrlInfo.gamenJunshiWidth;
let requestedJunshiQuality = 1;
let isWriteToFirebaseImage = false;
if (targetCtrlInfo.isFirebaseJunshi) {
requestedJunshiQuality = targetCtrlInfo.firebaseJunshiQuality;
const isSameImage = this._cAux.checkIfSameFirebaseJunshiImage(targetCtrlInfo, image);
isWriteToFirebaseImage = (! isSameImage) ||
(requestedJunshiWidth !== targetCtrlInfo.lastFirebaseJunshiWidth) ||
(requestedJunshiQuality !== targetCtrlInfo.lastFirebaseJunshiQuality);
}
let junshiWidth = width;
if (targetCtrlInfo.gamenJunshiWidth !== 0) {
junshiWidth = Math.min(junshiWidth, targetCtrlInfo.gamenJunshiWidth);
}
if ((targetCtrlInfo.isGamenStreamTransfer()) && (this._cAux.getDebugTestMode('B') === 0)) {
if ((junshiWidth & 0x1) !== 0)  junshiWidth--;
}
let canvasAspectRatio = targetCtrlInfo.activeTabJunshiRealAspectRatio;
let canvasHeight = height;
if (targetCtrlInfo.gamenJunshiWidth !== 0) {
canvasHeight = Math.round(junshiWidth / targetCtrlInfo.activeTabJunshiRealAspectRatio);
}
if ((targetCtrlInfo.isGamenStreamTransfer()) && (this._cAux.getDebugTestMode('B') === 0)) {
if (canvasHeight < 18) {
canvasHeight = 18;
}
if ((canvasHeight & 0x1) !== 0)  canvasHeight--;
canvasAspectRatio = junshiWidth / canvasHeight;
}
else {
if (canvasHeight < 18) {
canvasHeight = 18;
canvasAspectRatio = junshiWidth / canvasHeight;
}
}
if (targetCtrlInfo.activeTabJunshiCanvas === null) {
targetCtrlInfo.lastJunshiTime = now;
targetCtrlInfo.isBusyJunshi = false;
return;
}
targetCtrlInfo.activeTabJunshiCanvas.width = junshiWidth;
targetCtrlInfo.activeTabJunshiCanvas.height = canvasHeight;
targetCtrlInfo.activeTabJunshiCanvasAspectRatio = canvasAspectRatio;
let zoomedImage = Utils.resizeImage(image, junshiWidth);
if (targetCtrlInfo.gamenJunshiType !== 'tab') {
if (targetCtrlInfo.isGamenStreamTransfer()) {
Utils.replacePeerVideoStream(targetCtrlInfo.peerConnection, targetCtrlInfo.activeTabJunshiStream);
if (Utils.setMaxPeerVideoFrameRate(targetCtrlInfo.peerConnection, Constants.FRAME_RATE_WHEN_ACTIVE_TAB)) {
targetCtrlInfo.appliedMaxPeerVideoFrameRate = Constants.FRAME_RATE_WHEN_ACTIVE_TAB;
}
}
targetCtrlInfo.gamenJunshiType = 'tab';
this._cComm.sendClientState(targetCtrlInfo.mailAddress);
}
if (targetCtrlInfo.isJunshiCaptured !== true) {
targetCtrlInfo.isJunshiCaptured = true;
if (targetCtrlInfo.isFirebaseJunshi) {
isWriteToFirebaseImage = true;
}
this._cComm.sendClientCapturedResult(targetCtrlInfo);
}
if (targetCtrlInfo.isWatchActiveTab) {
if (zoomedImage) {
if (targetCtrlInfo.activeTabJunshiCanvasAspectRatio === targetCtrlInfo.activeTabJunshiRealAspectRatio) {
Utils.transferImage(targetCtrlInfo.activeTabJunshiCanvas, null, zoomedImage, 0, 0, targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvas.height);
}
else {
const ctx = targetCtrlInfo.activeTabJunshiCanvas.getContext('2d');
ctx.fillStyle = 'rgb(93, 93, 93)';
ctx.fillRect(0, 0, targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvas.height);
const drawHeight = Math.round(targetCtrlInfo.activeTabJunshiCanvas.width / targetCtrlInfo.activeTabJunshiRealAspectRatio);
const drawTop = Math.trunc((targetCtrlInfo.activeTabJunshiCanvas.height - zoomedImage.height) / 2);
Utils.transferImage(null, ctx, zoomedImage, 0, 0, zoomedImage.width, zoomedImage.height, 0, drawTop, targetCtrlInfo.activeTabJunshiCanvas.width, drawHeight);
}
if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
else if (isWriteToFirebaseImage) {
targetCtrlInfo.lastFirebaseJunshiWidth = requestedJunshiWidth;
targetCtrlInfo.lastFirebaseJunshiQuality = requestedJunshiQuality;
this._cAux.writeFirebaseJunshiGamenAsync(this._cFbgJunshi, targetCtrlInfo.mailAddress,
targetCtrlInfo.activeTabJunshiCanvas, requestedJunshiQuality, requestedJunshiWidth)
.then((result) => {
if (! result.skiped) {
if ((result.quality === targetCtrlInfo.lastFirebaseJunshiQuality) &&
(result.width === targetCtrlInfo.lastFirebaseJunshiWidth)) {
targetCtrlInfo.lastJunshiTime = now;
}
}
else {
targetCtrlInfo.lastFirebaseJunshiWidth = -1;
targetCtrlInfo.lastFirebaseJunshiQuality = -1;
this._cAux.adjustLastJunshiTime(targetCtrlInfo);
}
})
.catch(() => {
targetCtrlInfo.lastJunshiTime = now;
})
.finally(() => {
targetCtrlInfo.isBusyJunshi = false;
});
return;
}
}
else {
this._cAux.fillCanvas(targetCtrlInfo.activeTabJunshiCanvas, false);
if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
}
}
else {
this._cAux.fillCanvas(targetCtrlInfo.activeTabJunshiCanvas, false);
if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
}
if (targetCtrlInfo.isGamenStreamTransfer()) {
if ((targetCtrlInfo.activeTabJunshiCanvas) &&
((targetCtrlInfo.appliedActiveTabJunshiWidth !== targetCtrlInfo.activeTabJunshiCanvas.width) ||
(targetCtrlInfo.appliedActiveTabJunshiAspectRatio !== targetCtrlInfo.activeTabJunshiCanvasAspectRatio))) {
Utils.setVideoStreamConstraints(targetCtrlInfo.activeTabJunshiStream,
targetCtrlInfo.activeTabJunshiCanvas.width, targetCtrlInfo.activeTabJunshiCanvasAspectRatio, (result) => {
if (result) {
targetCtrlInfo.appliedActiveTabJunshiWidth = targetCtrlInfo.activeTabJunshiCanvas.width;
targetCtrlInfo.appliedActiveTabJunshiAspectRatio = targetCtrlInfo.activeTabJunshiCanvasAspectRatio;
if (targetCtrlInfo.appliedMaxPeerVideoFrameRate !== Constants.FRAME_RATE_WHEN_ACTIVE_TAB) {
if (Utils.setMaxPeerVideoFrameRate(targetCtrlInfo.peerConnection, Constants.FRAME_RATE_WHEN_ACTIVE_TAB)) {
targetCtrlInfo.appliedMaxPeerVideoFrameRate = Constants.FRAME_RATE_WHEN_ACTIVE_TAB;
}
}
}
});
}
}
}
targetCtrlInfo.lastJunshiTime = now;
targetCtrlInfo.isBusyJunshi = false;
});
}
else if (nowTime < targetCtrlInfo.lastJunshiTime.getTime()) {
this._putLog('アクティブタブ監視処理中に時計の巻き戻り検出.', LogLevels.INFO);
targetCtrlInfo.lastJunshiTime = now;
}
}
catch (err) {
this._putLog(`ERROR - _watchActiveTab() : ${err.message || err || ''}`, LogLevels.INFO);
targetCtrlInfo.isBusyJunshi = false;
}
}
}
_watchDesktopGamen(ctrlMail) {
const targetCtrlInfo = this._cAux.findCtrlInfoByMail(ctrlMail);
if (! targetCtrlInfo) {
this._putLog(`_watchDesktopGamen() - Not found ControllerInfo.  Mail=${ctrlMail}`, LogLevels.INFO);
return;
}
if (! targetCtrlInfo.isWatchDesktopGamen)  return;
if (targetCtrlInfo.isSnapshotWriteWaiting) {
this._cAux.writeSnapshotAsync(this._cFbgSnapshot, ctrlMail).then(() => {});
}
if ((! targetCtrlInfo.isBusyJunshi) || (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED)) {
try {
let nextTime;
if (targetCtrlInfo.gamenJunshiFrameRate > 0) {
if (targetCtrlInfo.isChangedJunshiRequirements) {
targetCtrlInfo.isChangedJunshiRequirements = false;
if (targetCtrlInfo.isFirebaseJunshi) {
targetCtrlInfo.lastFirebaseJunshiWidth = -1;
targetCtrlInfo.lastFirebaseJunshiQuality = -1;
}
nextTime = Date.now();
this._putLog('デスクトップ画面監視処理で画面巡視要件変更により巡視処理時刻を調整しました.', this._cData.getTraceLogLevel());
}
else {
let refreshTime = Math.round(1000 / targetCtrlInfo.gamenJunshiFrameRate);
nextTime = targetCtrlInfo.lastJunshiTime.getTime() + refreshTime;
}
}
else {
nextTime = Number.MAX_VALUE;
}
const now = new Date();
const nowTime = now.getTime();
const elapsedJunshiTime = (nextTime <= nowTime);
let isAcceptedCollabMateCapture = false;
if ((elapsedJunshiTime) || (targetCtrlInfo.snapshotRequestedTime) ||
(targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED)) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.REQUESTED) {
isAcceptedCollabMateCapture = true;
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.ACCEPTED;
}
targetCtrlInfo.isBusyJunshi = true;
this._cAux.captureDesktop(this._cData.desktopCapturedCanvas);
if (isAcceptedCollabMateCapture) {
if (! targetCtrlInfo.isWatchDesktopGamen) {
if (targetCtrlInfo.collabMateCaptureState === CollabMateCaptureStates.ACCEPTED) {
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.REQUESTED;
}
}
else {
targetCtrlInfo.collabMateCapturedCanvas = new OffscreenCanvas(this._cData.desktopCapturedCanvas.width, this._cData.desktopCapturedCanvas.height);
Utils.transferImage(targetCtrlInfo.collabMateCapturedCanvas, null, this._cData.desktopCapturedCanvas);
targetCtrlInfo.collabMateCaptureState = CollabMateCaptureStates.NONE;
}
targetCtrlInfo.isBusyJunshi = false;
isAcceptedCollabMateCapture = false;
return;
}
if (targetCtrlInfo.snapshotRequestedTime) {
targetCtrlInfo.snapshotWriteWaitingImage = this._cData.desktopCapturedCanvas;
targetCtrlInfo.isSnapshotWriteWaiting = true;
this._cAux.writeSnapshotAsync(this._cFbgSnapshot, ctrlMail).then(() => {});
}
if ((! elapsedJunshiTime) || (! targetCtrlInfo.isWatchDesktopGamen)) {
targetCtrlInfo.isBusyJunshi = false;
return;
}
if (! this._cData.desktopCapturedCanvas) {
if (targetCtrlInfo.isJunshiCaptured !== false) {
targetCtrlInfo.isJunshiCaptured = false;
this._cComm.sendClientCapturedResult(targetCtrlInfo);
this._putLog('デスクトップ画面監視処理中にデスクトップ画面キャプチャ用キャンバスの異常検出.', LogLevels.INFO);
}
}
else {
let requestedJunshiWidth = targetCtrlInfo.gamenJunshiWidth;
let requestedJunshiQuality = 1;
let isWriteToFirebaseImage = false;
if (targetCtrlInfo.isFirebaseJunshi) {
requestedJunshiQuality = targetCtrlInfo.firebaseJunshiQuality;
const isSameImage = this._cAux.checkIfSameFirebaseJunshiImage(targetCtrlInfo, this._cData.desktopCapturedCanvas);
isWriteToFirebaseImage = (! isSameImage) ||
(requestedJunshiWidth !== targetCtrlInfo.lastFirebaseJunshiWidth) ||
(requestedJunshiQuality !== targetCtrlInfo.lastFirebaseJunshiQuality);
}
let junshiWidth = this._cData.desktopCapturedWidth;
if (targetCtrlInfo.gamenJunshiWidth !== 0) {
junshiWidth = Math.min(junshiWidth, targetCtrlInfo.gamenJunshiWidth);
}
let zoomedImage = Utils.resizeImage(this._cData.desktopCapturedCanvas, junshiWidth);
if (targetCtrlInfo.gamenJunshiType !== 'screen') {
targetCtrlInfo.gamenJunshiType = 'screen';
this._cComm.sendClientState(targetCtrlInfo.mailAddress);
}
if (targetCtrlInfo.isJunshiCaptured !== true) {
targetCtrlInfo.isJunshiCaptured = true;
if (targetCtrlInfo.isFirebaseJunshi) {
isWriteToFirebaseImage = true;
}
this._cComm.sendClientCapturedResult(targetCtrlInfo);
}
if ((zoomedImage) && (targetCtrlInfo.desktopJunshiCanvas)) {
if (targetCtrlInfo.desktopJunshiCanvas.width !== zoomedImage.width) {
targetCtrlInfo.desktopJunshiCanvas.width = zoomedImage.width;
}
if (targetCtrlInfo.desktopJunshiCanvas.height !== zoomedImage.height) {
targetCtrlInfo.desktopJunshiCanvas.height = zoomedImage.height;
}
const aspectRatio = targetCtrlInfo.desktopJunshiCanvas.width / targetCtrlInfo.desktopJunshiCanvas.height;
Utils.transferImage(targetCtrlInfo.desktopJunshiCanvas, null, zoomedImage);
if (targetCtrlInfo.isGamenStreamTransfer()) {
if (((targetCtrlInfo.appliedDesktopJunshiWidth !== targetCtrlInfo.desktopJunshiCanvas.width) ||
(targetCtrlInfo.appliedDesktopJunshiAspectRatio !== aspectRatio))) {
Utils.setVideoStreamConstraints(targetCtrlInfo.desktopJunshiStream,
targetCtrlInfo.desktopJunshiCanvas.width, aspectRatio, (result) => {
if (result) {
targetCtrlInfo.appliedDesktopJunshiWidth = targetCtrlInfo.desktopJunshiCanvas.width;
targetCtrlInfo.appliedDesktopJunshiAspectRatio = aspectRatio;
}
});
}
}
else if (targetCtrlInfo.isGamenBinaryTransfer()) {
this._cComm.sendGamenBinaryToCtrl(targetCtrlInfo);
}
else if (isWriteToFirebaseImage) {
targetCtrlInfo.lastFirebaseJunshiWidth = requestedJunshiWidth;
targetCtrlInfo.lastFirebaseJunshiQuality = requestedJunshiQuality;
this._cAux.writeFirebaseJunshiGamenAsync(this._cFbgJunshi, targetCtrlInfo.mailAddress,
targetCtrlInfo.desktopJunshiCanvas, requestedJunshiQuality, requestedJunshiWidth)
.then((result) => {
if (! result.skiped) {
if ((result.quality === targetCtrlInfo.lastFirebaseJunshiQuality) &&
(result.width === targetCtrlInfo.lastFirebaseJunshiWidth)) {
targetCtrlInfo.lastJunshiTime = now;
}
}
else {
targetCtrlInfo.lastFirebaseJunshiWidth = -1;
targetCtrlInfo.lastFirebaseJunshiQuality = -1;
this._cAux.adjustLastJunshiTime(targetCtrlInfo);
}
})
.catch(() => {
targetCtrlInfo.lastJunshiTime = now;
})
.finally(() => {
targetCtrlInfo.isBusyJunshi = false;
});
return;
}
}
}
targetCtrlInfo.lastJunshiTime = now;
targetCtrlInfo.isBusyJunshi = false;
}
else if (nowTime < targetCtrlInfo.lastJunshiTime.getTime()) {
this._putLog('デスクトップ画面監視処理中に時計の巻き戻り検出.', LogLevels.INFO);
targetCtrlInfo.lastJunshiTime = now;
}
}
catch (err) {
this._putLog(`ERROR - _watchDesktopGamen() : ${err.message || err || ''}`, LogLevels.INFO);
targetCtrlInfo.isBusyJunshi = false;
}
}
}
_watchClientState() {
try {
if (! this._isWatchClientState)  return;
this._watchClientStateTimerId = TIMER_ID_NONE;
this._cAux.checkClientState(false, (changed) => {
if (changed) {
this._cComm.sendClientState();
}
if (this._isWatchClientState) {
this._isWatchClientState = this.stopWatchClientState();
this._watchClientStateTimerId = this._timer.addTimer(2950, false, this._watchClientState);
}
});
}
catch (err) {
this._putLog(`ERROR - _watchClientState() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_watchCbtMode() {
try {
if (! this._isWatchCbtMode)  return;
this._watchCbtModeTimerId = TIMER_ID_NONE;
const utcTime = Date.now();
const startUTCTime = this._cData.cbtModeInfo.startUTCTime - 60000;
const releaseUTCTime = this._cData.cbtModeInfo.forcedReleaseUTCTime;
if (! this._isBetweenTimeSeconds(utcTime, startUTCTime, releaseUTCTime)) {
if (! this._cData.isNightLimitMode) {
this.terminateCbtModeAsync(false, '解除漏れによる強制解除').then(() => {});
}
this._isWatchCbtMode = false;
return;
}
if (! this._cData.isCbtModeAlwaysBrowserMaximize) {
if (this._isWatchCbtMode) {
let nextWatch = Math.max(0, Math.min(59950, (releaseUTCTime - utcTime - 50)));
this._watchCbtModeTimerId = this._timer.addTimer(nextWatch, false, this._watchCbtMode);
}
return;
}
let allBrowsers = [];
this._cAux.getAllBrowserWindowAsync()
.then((wnds) => {
allBrowsers = wnds;
if (this._cData.isCbtModeAlwaysBrowserOnTop) {
return this.collectTabsIntoBrowserAsync(allBrowsers);
}
})
.then((topWindow) => {
if (topWindow?.focused === false) {
if ((! this._cData.isGamenLockMode) && (! this._cData.isGamenTeijiMode) &&
(! this._cData.isConfirmingJoinClasswork) && (! this._cData.isConfirmingScreenSharing)) {
return ApiWrappers.updateWindowAsync(topWindow.id, { focused: true }, true);
}
}
})
.then(() => {
let promises = [];
for (const wnd of allBrowsers) {
if ((wnd.state !== 'maximized') && (wnd.state !== 'fullscreen')) {
promises.push(ApiWrappers.updateWindowAsync(wnd.id, { state: 'maximized' }, true));
}
}
if (promises.length > 0) {
return Promise.allSettled(promises);
}
})
.then(() => {
if (this._isWatchCbtMode) {
this._isWatchCbtMode = this.stopWatchCbtMode();
this._watchCbtModeTimerId = this._timer.addTimer(950, false, this._watchCbtMode);
}
});
}
catch (err) {
this._putLog(`ERROR - _watchCbtMode() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_watchCbtOpeningMessage() {
try {
if (! this._isWatchCbtOpeningMessage)  return;
if (this._watchCbtOpeningMessageTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchCbtOpeningMessageTimerId);
this._watchCbtOpeningMessageTimerId = TIMER_ID_NONE;
}
let storageData;
ApiWrappers.readSessionStorageDataAsync({
CbtOpeningMessage: '',
CbtOpeningMessageElapsedMsec: 0,
}, true)
.then((storage) => {
storageData = storage;
return navigator.serviceWorker.ready;
})
.then((registration) => {
return registration.getNotifications({ tag: 'CbtOpening' });
})
.then((notifications) => {
if ((notifications?.length) && (storageData.CbtOpeningMessage?.length) && (this._cbtOpeningMessageBaseMsec !== -1)) {
let totalElapsed = storageData.CbtOpeningMessageElapsedMsec;
const nowMsec = Math.floor(performance.now());
totalElapsed += (nowMsec - this._cbtOpeningMessageBaseMsec);
this._cbtOpeningMessageBaseMsec = nowMsec;
if (totalElapsed < Constants.MAX_SHOW_CBT_OPENING_MESSAGE) {
return ApiWrappers.saveSessionStorageDataAsync({ CbtOpeningMessageElapsedMsec: totalElapsed });
}
this._putLog('CBTモード開始メッセージ通知が規定時間を経過したため、通知を閉じます.', LogLevels.INFO);
this._cAux.closeNotificationAsync('CbtOpening').then(() => {});
}
this._isWatchCbtOpeningMessage = false;
this._cbtOpeningMessageBaseMsec = -1;
return ApiWrappers.saveSessionStorageDataAsync({
CbtOpeningMessage: '',
CbtOpeningMessageElapsedMsec: 0,
});
})
.catch((err) => {
const errorMsg = 'ERROR - _watchCbtOpeningMessage()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
})
.finally(() => {
if (this._isWatchCbtOpeningMessage) {
this._watchCbtOpeningMessageTimerId = this._timer.addTimer(950, false, this._watchCbtOpeningMessage);
}
});
}
catch (err) {
this._putLog(`ERROR - _watchCbtOpeningMessage() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_watchAvailableTime() {
try {
if (! this._isWatchAvailableTime)  return;
this._watchAvailableTimeTimerId = TIMER_ID_NONE;
if (this._cData.isAvailableTime) {
const availableNow = this._timeLimit.isAvailableNow();
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog(`利用可能時間制限監視(1)  判定結果値=${availableNow}`, LogLevels.INFO);
}
if (availableNow < 0) {
this._cData.isAvailableTime = false;
this._putLog('利用可能時間外になりました.', LogLevels.INFO);
this._cData.isConnectingFirebase = false;
if (this._cComm.clearReconnectFirebaseTimer()) {
this._putLog('利用可能時間外への移行により再接続処理スケジュールをキャンセルしました.', this._cData.getTraceLogLevel());
}
this.terminateCbtModeAsync(false, '利用可能時間外').then(() => {});
if ((this._cData.onlineNotificationState === 3) || (this._cData.onlineNotificationState === 1)) {
this._cComm.offlineFirebase(() => {
if (this._cData.isJoinedClasswork) {
this._putLog('利用可能時間外への移行により、授業から退出します.', LogLevels.FATAL);
}
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'LeaveClasswork',
stopAllConnection: true,
});
if (this._isWatchAvailableTime) {
this._watchAvailableTimeTimerId = this._timer.addTimer(9950, false, this._watchAvailableTime);
}
this._cAux.notifyChangedClientStatus();
});
}
else if (this._isWatchAvailableTime) {
this._watchAvailableTimeTimerId = this._timer.addTimer(0, false, this._watchAvailableTime);
}
}
else if ((availableNow > 0) && (this._isWatchAvailableTime)) {
let nextWatch = Math.min((availableNow * 1000), Constants.MAX_WATCH_AVAILABLE_TIME_INTERVAL);
this._watchAvailableTimeTimerId = this._timer.addTimer(Math.max(950, (nextWatch - 50)), false, this._watchAvailableTime);
}
}
else {
const availableNow = this._timeLimit.isAvailableNow();
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog(`利用可能時間制限監視(2)  判定結果値=${availableNow}`, LogLevels.INFO);
}
if (availableNow >= 0) {
this._isWatchAvailableTime = false;
this._cData.isAvailableTime = true;
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('利用可能時間制限監視(2)  利用可能時間になったため、Firebaseとの接続処理開始.', LogLevels.INFO);
}
this._cData.failedInitializeSigLibCounter = 0;
this._cData.isWaitingBrowserOnline = false;
this._cData.isConnectingFirebase = true;
this._cComm.connectFirebase();
}
else if ((availableNow != -9999) && (this._isWatchAvailableTime)) {
let nextWatch = Math.min((Math.abs(availableNow) * 1000), Constants.MAX_WATCH_AVAILABLE_TIME_INTERVAL);
this._watchAvailableTimeTimerId = this._timer.addTimer(Math.max(950, (nextWatch - 50)), false, this._watchAvailableTime);
}
}
}
catch (err) {
this._putLog(`ERROR - _watchAvailableTime() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_watchNightLimit() {
const fnCompareNightLimitInfo = (obj1, obj2) => {
const fnMakeSortedJsonString = (obj) => {
if (typeof obj === 'object') {
const tempObj = Object.assign({}, obj);
delete tempObj._sourceYMD;
delete tempObj._lastWarningNoticeTimeSeconds;
return JSON.stringify(Utils.sortObjectProperty(tempObj));
}
return '';
};
const a = fnMakeSortedJsonString(obj1);
const b = fnMakeSortedJsonString(obj2);
return (a === b);
};
const fbGetNightLimitPolicyAsync = (requestedYMD) => {
const fnCloseFirestoreDB = () => {
try {
if (typeof this._firestorePolicyDb?.app?.delete === 'function') {
this._firestorePolicyDb.app.delete();
}
this._firestorePolicyDb = null;
}
catch (err) {
const errorMsg = 'ERROR - fnCloseFirestoreDB()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, this._cData.getTraceLogLevel());
}
};
return new Promise((resolve) => {
try {
this._putLog(`${requestedYMD}分の夜間利用制限＆自動取得のポリシー取得を試みます.`, LogLevels.INFO);
fnCloseFirestoreDB();
this._firestorePolicyDb = firebase.initializeApp(ExtraConstants.Policy_FirebaseConfig, "PolicyDb").firestore();
const docRef = this._firestorePolicyDb.collection("/User").where('Users', 'array-contains', this._cData.signedUserEmail).limit(1);
const getOptions = { source: 'server' };
let yakanSeigenPolicy = null;
docRef.get(getOptions)
.then((querySnapshot) => {
querySnapshot.forEach((doc) => {
if ('Rule' in doc.data()) {
if ('YakanSeigen' in doc.data().Rule) {
yakanSeigenPolicy = doc.data().Rule.YakanSeigen;
}
}
});
if (yakanSeigenPolicy) {
this._putLog(`${requestedYMD}分の夜間利用制限ポリシーを取得しました.`, LogLevels.INFO);
}
else {
this._putLog(`${requestedYMD}分の夜間利用制限ポリシーが存在しませんでした.`, LogLevels.INFO);
yakanSeigenPolicy = { enabled: false };
}
const docRef2 = this._firestorePolicyDb.collection("/ReqEventLog").where('mail', '==', this._cData.signedUserEmail).limit(1);
return docRef2.get(getOptions);
})
.then((querySnapshot) => {
const existsUploadLogPolicy = !!(querySnapshot?.docs?.length);
if (existsUploadLogPolicy) {
this._putLog(`${requestedYMD}分のログ自動取得ポリシーが存在しました.`, LogLevels.INFO);
}
else {
this._putLog(`${requestedYMD}分のログ自動取得ポリシーが存在しませんでした.`, LogLevels.INFO);
}
this._cData.isNeedsAutoUploadLog = existsUploadLogPolicy;
this._cData.changedNightLimitInfo = new NightLimitInfo(requestedYMD, yakanSeigenPolicy);
fnCloseFirestoreDB();
yakanSeigenPolicy.sourceYMD = requestedYMD;
return ApiWrappers.saveLocalStorageDataAsync({ YakanSeigenPolicy: yakanSeigenPolicy });
})
.then(() => {
resolve(true);
})
.catch((err) => {
if ((err?.name === 'FirebaseError') && (err?.code === 'unavailable')) {
this._putLog('FireStoreが利用できません. 夜間利用制限＆ログ自動取得ポリシー取得に失敗しました.', LogLevels.INFO);
}
else {
const errorMsg = 'ERROR - fbGetNightLimitPolicyAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
}
fnCloseFirestoreDB();
resolve(false);
});
}
catch (err) {
const errorMsg = 'ERROR - fbGetNightLimitPolicyAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
fnCloseFirestoreDB();
resolve(false);
}
});
};
const fnProcReadPolicy = (requestedYMD) => {
if (this._readNightLimitPolicyTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._readNightLimitPolicyTimerId);
this._readNightLimitPolicyTimerId = TIMER_ID_NONE;
}
this._cData.nightLimitPolicyRequestedYMD = requestedYMD;
if (! this._isWatchNightLimit)  return;
const currentTime = Utils.getJstDateTime();
const currentSeconds = (currentTime.hours * 60 * 60) + (currentTime.minutes * 60) + currentTime.seconds;
const suspendBeginningSeconds = (Constants.NIGHT_LIMIT_POLICY_APPLIED_BASIS_HOURS * 60 * 60);
const suspendEndingSeconds = suspendBeginningSeconds + this._cData.delayGetNightLimitPolicy;
if (this._isBetweenTimeSeconds(currentSeconds, suspendBeginningSeconds, suspendEndingSeconds)) {
this._readNightLimitPolicyTimerId = this._timer.addTimer(1950, false, fnProcReadPolicy, this._cData.nightLimitPolicyRequestedYMD);
return;
}
fbGetNightLimitPolicyAsync(this._cData.nightLimitPolicyRequestedYMD).then((result) => {
if (result) {
this._cData.nightLimitPolicyRequestedYMD = null;
if (this.stopWatchNightLimit()) {
this._isWatchNightLimit = true;
this._watchNightLimitTimerId = this._timer.addTimer(950, false, this._watchNightLimit);
}
}
else {
this._putLog('夜間利用制限＆ログ自動取得ポリシー取得失敗のため 60秒後に再試行します.', this._cData.getTraceLogLevel());
this._readNightLimitPolicyTimerId = this._timer.addTimer(59950, false, fnProcReadPolicy, this._cData.nightLimitPolicyRequestedYMD);
}
});
}
try {
if (! this._isWatchNightLimit)  return;
this._watchNightLimitTimerId = TIMER_ID_NONE;
this._putLog('Called  _watchNightLimit() - 夜間利用制限の監視処理', this._cData.getTraceLogLevel());
const currentTime = Utils.getJstDateTime();
const tempDate = new Date(currentTime.year, currentTime.month - 1, currentTime.date, currentTime.hours);
tempDate.setHours(tempDate.getHours() - Constants.NIGHT_LIMIT_POLICY_APPLIED_BASIS_HOURS);
const tempYMD = `${String(tempDate.getFullYear()).padStart(4, '0')}/` +
`${String(tempDate.getMonth() + 1).padStart(2, '0')}/${String(tempDate.getDate()).padStart(2, '0')}`;
if ((this._cData.changedNightLimitInfo === null) &&
((this._cData.nightLimitInfo === null) || (this._cData.nightLimitInfo.sourceYMD !== tempYMD))) {
if (this._cData.nightLimitPolicyRequestedYMD !== tempYMD) {
this._cData.isNeedsAutoUploadLog = false;
fnProcReadPolicy(tempYMD);
}
}
if (this._cData.changedNightLimitInfo !== null) {
const oldNightLimitInfo = this._cData.nightLimitInfo;
this._cData.nightLimitInfo = this._cData.changedNightLimitInfo;
this._cData.changedNightLimitInfo = null;
if (fnCompareNightLimitInfo(oldNightLimitInfo, this._cData.nightLimitInfo)) {
this._putLog('夜間利用制限ポリシーは変更されていません.', LogLevels.INFO);
}
else {
this._putLog('夜間利用制限ポリシーの変更が検出されました.', LogLevels.INFO);
if ((this._cData.appliedBrowserSeigen === BrowserSeigens.NIGHT) || (this._cData.isNightLimitMode)) {
this._putLog('夜間利用制限ポリシー変更検出により夜間利用制限の時間帯を抜けます.', LogLevels.INFO);
if (this._cData.appliedBrowserSeigen === BrowserSeigens.NIGHT) {
this._requestChangeBrowserSeigen(BrowserSeigens.NIGHT, false);
}
this._cAux.closeNotificationAsync('NightLimit').then(() => {});
this._cData.isNightLimitMode = false;
this._cAux.notifyChangedClientStatus();
if (this._isWatchNightLimit) {
this._watchNightLimitTimerId = this._timer.addTimer(2950, false, this._watchNightLimit);
}
return;
}
}
}
if ((this._cData.nightLimitInfo) && (this._cData.nightLimitInfo.isEnabled) &&
(this._cData.nightLimitInfo.isWarningNotice || this._cData.nightLimitInfo.isBrowserSeigen)) {
const currentSeconds = (currentTime.hours * 60 * 60) + (currentTime.minutes * 60) + currentTime.seconds;
let noticeMessage = null;
let noticeIcon = null;
if (this._cData.isNightLimitMode) {
if (this._isBetweenTimeSeconds(currentSeconds, this._cData.nightLimitInfo.beginningTimeSeconds, this._cData.nightLimitInfo.endingTimeSeconds)) {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('夜間利用制限監視(1)  判定結果値=継続', LogLevels.INFO);
}
if (this._cData.nightLimitInfo.isWarningNotice) {
let elapsedSeconds = currentSeconds - this._cData.nightLimitInfo.lastWarningNoticeTimeSeconds;
if (elapsedSeconds < 0) {
elapsedSeconds = (currentSeconds + 24 * 60 * 60) - this._cData.nightLimitInfo.lastWarningNoticeTimeSeconds;
}
if (elapsedSeconds >= this._cData.nightLimitInfo.warningNoticeInterval) {
noticeMessage = this._cData.nightLimitInfo.warningNoticeMessage;
noticeIcon = './assets/nightLimit2.png';
this._cData.nightLimitInfo.lastWarningNoticeTimeSeconds = currentSeconds;
}
}
}
else {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('夜間利用制限監視(1)  判定結果値=解除', LogLevels.INFO);
}
this._putLog('夜間利用制限の時間帯を抜けます.', LogLevels.INFO);
if (this._cData.appliedBrowserSeigen === BrowserSeigens.NIGHT) {
this._requestChangeBrowserSeigen(BrowserSeigens.NIGHT, false);
}
this._cAux.closeNotificationAsync('NightLimit').then(() => {});
this._cData.isNightLimitMode = false;
this._cAux.notifyChangedClientStatus();
}
}
else if (this._isBetweenTimeSeconds(currentSeconds, this._cData.nightLimitInfo.beginningTimeSeconds, this._cData.nightLimitInfo.endingTimeSeconds)) {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('夜間利用制限監視(2)  判定結果値=制限時間帯へ突入', LogLevels.INFO);
}
this._putLog('夜間利用制限の時間帯に入りました.', LogLevels.INFO);
this._cAux.closeNotificationAsync('NightLimit')
.then(() => {
return this.terminateCbtModeAsync(true, '夜間利用制限')
})
.then(() => {
if (this._cData.nightLimitInfo.isBrowserSeigen) {
this._requestChangeBrowserSeigen(BrowserSeigens.NIGHT, true, this._cData.nightLimitInfo.whiteList);
}
});
if (this._cData.nightLimitInfo.isWarningNotice) {
noticeMessage = this._cData.nightLimitInfo.warningNoticeMessage;
noticeIcon = './assets/nightLimit2.png';
this._cData.nightLimitInfo.lastWarningNoticeTimeSeconds = currentSeconds;
}
this._cData.isNightLimitMode = true;
this._cAux.notifyChangedClientStatus();
}
else if (this._isBetweenTimeSeconds(currentSeconds, this._cData.nightLimitInfo.priorNoticeTimeSeconds, this._cData.nightLimitInfo.beginningTimeSeconds)) {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('夜間利用制限監視(3)  判定結果値=事前表示時間帯', LogLevels.INFO);
}
if (this._cData.nightLimitInfo.isPriorNotice) {
noticeMessage = this._cData.nightLimitInfo.priorNoticeMessage;
noticeIcon = './assets/nightLimit1.png';
}
}
else {
if (this._cData.debugTraceLevel !== TraceLevels.UNSET) {
this._putLog('夜間利用制限監視(4)  判定結果値=対象時間外', LogLevels.INFO);
}
}
if (noticeMessage) {
this._cAux.closeNotificationAsync('BrowserSeigen')
.then(() => {
return this._cAux.openNotificationAsync('NightLimit', noticeMessage, noticeIcon);
})
.then(() => {
});
}
}
if (this._cData.isNeedsAutoUploadLog) {
ApiWrappers.readSessionStorageValueAsync({ InitializeTime: Date.now() })
.then((initializeTime) => {
const elapsed = Date.now() - initializeTime;
if ((elapsed < -10000) || (elapsed >= 30000)) {
return this._uploadClientLogAsync();
}
return false;
})
.then((result) => {
if (result) {
this._cData.isNeedsAutoUploadLog = false;
}
});
}
if (this._isWatchNightLimit) {
let nextWatch = Math.min(((60 - currentTime.seconds) * 1000), (60 * 1000));
nextWatch = Math.max(nextWatch, (5 * 1000));
this._watchNightLimitTimerId = this._timer.addTimer((nextWatch - 50), false, this._watchNightLimit);
}
}
catch (err) {
this._putLog(`ERROR - _watchNightLimit() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_requestChangeBrowserSeigen(seigenType, enabled, userWhiteList=[]) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'RequestChangeBrowserSeigen',
seigenType: seigenType,
enabled: enabled,
whiteList: userWhiteList,
});
}
_uploadClientLogAsync() {
return new Promise(async (resolve) => {
if (this._cData.isUploadingClientLog) {
resolve(false);
return;
}
this._cData.isUploadingClientLog = true;
let uploaded = false;
let tempFirebaseApp = null;
let logLines = [];
try {
logLines.push(`${Utils.getJstDateTimeStr(true).slice(0, 19)} (JST) に 自動出力した クライアント(${this._cData.signedUserEmail})のログです.`);
const logObj = await LogManager.getAllLogAsync(false);
logLines = logLines.concat(['', '■■■ 重要ログ ■■■']);
logLines = logLines.concat(logObj.fatalLogs);
logLines = logLines.concat(['', '■■■ 情報ログ ■■■']);
logLines = logLines.concat(logObj.infoLogs);
tempFirebaseApp = firebase.initializeApp(ExtraConstants.LogStorage_FirebaseConfig, "JsLogStorage");
const tempFunction = tempFirebaseApp.functions('asia-northeast2');
const pushEvent = tempFunction.httpsCallable('pushEvent');
const arg = {
Email: this._cData.signedUserEmail,
Log: logLines
};
const result = await pushEvent(arg);
if (result?.data?.status !== true) {
throw new Error(result?.data?.error || '');
}
this._putLog('ログを自動アップロードしました.', LogLevels.INFO);
uploaded = true;
}
catch (err) {
this._putLog('ログの自動アップロードに失敗しました.' + ((err) ? `  理由: ${err.message || err}` : ''), LogLevels.INFO);
uploaded = false;
}
finally {
if (tempFirebaseApp) {
try {
tempFirebaseApp.delete();
tempFirebaseApp = null;
}
catch (err) {
console.log(err);
}
}
this._cData.isUploadingClientLog = false;
resolve(uploaded);
}
});
}
_reshowClassworkPagesAsync() {
return new Promise((resolve) => {
try {
this.stopWatchClassworkPages();
this._cData.currentClassworkPages.forEach((pageInfo) => {
if (pageInfo.currentPageTabId !== TAB_ID_NONE) {
ApiWrappers.sendInternalMsgAsync(true, pageInfo.currentPageTabId, { cmd: 'ClosePage' }).then(() => {});
}
});
this.waitClosedClassworkPagesAsync()
.then(() => {
return new Promise((resolve2) => this._timer.addTimer(450, false, resolve2, true));
})
.then(() => {
if ((this._cData.isConfirmingJoinClasswork) || (this._cData.isConfirmingScreenSharing)) {
this._putLog('クライアント画面情報を再取得して授業ページを再表示します.', LogLevels.INFO);
this.showClassworkPages(null, () => {
resolve();
});
}
else {
resolve();
}
})
.finally(() => {
this._cData.isRequestedReshowClassworkPages = false;
})
}
catch (err) {
this._putLog(`ERROR - _reshowClassworkPagesAsync() : ${err.message || err || ''}`, LogLevels.INFO);
resolve();
}
});
}
_reshowAttentionPagesAsync() {
return new Promise((resolve) => {
try {
ApiWrappers.saveSessionStorageDataAsync({ IsNeedsWindowFocusChanged: false })
.then(() => {
this.stopWatchAttentionPages();
this._cData.currentAttentionPages.forEach((pageInfo) => {
if (pageInfo.currentPageTabId !== TAB_ID_NONE) {
ApiWrappers.sendInternalMsgAsync(true, pageInfo.currentPageTabId, { cmd: 'ClosePage' }).then(() => {});
}
});
return this.waitClosedAttentionPagesAsync();
})
.then(() => {
if ((this._cData.isGamenLockMode) || (this._cData.isGamenTeijiMode)) {
this._putLog('クライアント画面情報を再取得してアテンションページを再表示します.', LogLevels.INFO);
this.showAttentionPages(null, () => {
resolve();
});
}
else {
resolve();
}
})
.finally(() => {
this._cData.isRequestedReshowAttentionPages = false;
})
}
catch (err) {
this._putLog(`ERROR - _reshowAttentionPagesAsync() : ${err.message || err || ''}`, LogLevels.INFO);
resolve();
}
});
}
startWatchBrowserSeigenWindow() {
try {
this.stopWatchBrowserSeigenWindow();
this._isWatchBrowserSeigenWindow = true;
this._watchBrowserSeigenWindowTimerId = this._timer.addTimer(450, false, this._watchBrowserSeigenWindow);
}
catch (err) {
this._putLog(`ERROR - startWatchBrowserSeigenWindow() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchBrowserSeigenWindow() {
try {
if (this._isWatchBrowserSeigenWindow) {
this._isWatchBrowserSeigenWindow = false;
if (this._watchBrowserSeigenWindowTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchBrowserSeigenWindowTimerId);
this._watchBrowserSeigenWindowTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchBrowserSeigenWindow() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
showClassworkPages(reshowPageInfo, opt_callback=null) {
const fnWaitShowPageAsync = (id, isPrimary, pageKey, isDuplicate) => {
return new Promise(async(resolve) => {
while (true === await new Promise((resolve) => this._timer.addTimer(75, false, resolve, true))) {
const hitPageInfo = this._cData.currentClassworkPages.find((v) => {
return (v.id === id) && (v.isPrimary === isPrimary) && (v.currentPageKey === pageKey) && (v.isDuplicate === isDuplicate);
});
if (! hitPageInfo) {
break;
}
if ((hitPageInfo.currentPageWindowId !== WINDOW_ID_NONE) || (hitPageInfo.openRequestTimeout === -1)) {
break;
}
}
resolve();
});
};
const fnShowPageAsync = (pageInfo, pageKey) => {
return new Promise((resolve, reject) => {
try {
pageInfo.currentPageKey = pageKey;
pageInfo.currentPageWindowId = WINDOW_ID_NONE;
pageInfo.currentPageTabId = TAB_ID_NONE;
pageInfo.currentWindowState = '';
pageInfo.openRequestTimeout = 3;
let url = `${this._cData.classworkPageAbsoluteUrl}?pid=${pageInfo.id}&primary=${pageInfo.isPrimary}&key=${pageKey}`;
ApiWrappers.readSessionStorageValueAsync({ ClassworkPageBaseTime: performance.now() })
.then((baseTime) => {
if (pageInfo.isPrimary) {
const elapsedTime = Math.max(0, Math.trunc((performance.now() - baseTime) / 1000));
url = `${url}&elapsed=${elapsedTime}`;
const windowFeatures = `left=${pageInfo.workAreaLeft},top=${pageInfo.workAreaTop},width=${pageInfo.workAreaWidth},height=${pageInfo.workAreaHeight}`;
window.open(url, 'wbClassWorkPage', windowFeatures);
return;
}
const createData = {
url: url,
focused: true,
type: 'popup',
state: 'normal',
left: pageInfo.screenLeft,
top: pageInfo.screenTop,
width: pageInfo.screenWidth,
height: pageInfo.screenHeight,
};
return ApiWrappers.createWindowAsync(createData, true);
})
.then(() => {
return fnWaitShowPageAsync(pageInfo.id, pageInfo.isPrimary, pageInfo.currentPageKey, pageInfo.isDuplicate);
})
.then(() => {
resolve();
})
.catch((err) => {
const errorMsg = 'ERROR - showClassworkPages() - fnShowPageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
reject(errorMsg);
});
}
catch (err) {
const errorMsg = 'ERROR - showClassworkPages() - fnShowPageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
reject(errorMsg);
}
});
};
const fnShowAllPage = (callback=null) => {
let pageKey;
let screenInfos;
Utils.assert((this._cData.currentClassworkPages.length === 0), `Implementation Error. -- currentClassworkPages not empty.  length=${this._cData.currentClassworkPages.length}`);
this._cData.currentClassworkPages.length = 0;
this._cAux.flashClientCorePageAsync(false, 100)
.then(() => {
return ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode);
})
.then((results) => {
screenInfos = results;
this._classworkScreenInfoString = this._cAux.makeScreenInfoString(screenInfos);
return this._cAux.makeNewPageKeyAsync();
})
.then((newPageKey) => {
pageKey = newPageKey;
let promises = [];
let pageId = 0;
screenInfos.forEach((info) => {
const pageInfo = new PageScreenInfo(++pageId, info.displayId, info.isPrimary, info.screenBounds, info.workAreaBounds, false);
this._cData.currentClassworkPages.push(pageInfo);
promises.push(fnShowPageAsync(pageInfo, pageKey));
});
return Promise.allSettled(promises);
})
.then(() => {
this.startWatchClassworkPages();
if (callback) { callback(true); }
})
.catch((err) => {
this._putLog(`ERROR - showClassworkPages() - fnShowAllPage() : ${err.message || err || ''}`, LogLevels.FATAL);
if (callback) { callback(false); }
});
};
const fnHideAttentionPagesAsync = async () => {
const fnWaitMaximizedAttentionPagesAsync = () => {
const beginTime = window.performance.now();
let elapsedTime = 0;
return new Promise(async(resolve) => {
while ((this._cData.currentAttentionPages.length > 0) && (elapsedTime < 5000)) {
elapsedTime = Math.trunc(window.performance.now() - beginTime);
let maximizedCount = 0;
this._cData.currentAttentionPages.forEach((pageInfo) => {
if ((pageInfo.currentPageWindowId === WINDOW_ID_NONE) || (pageInfo.currentWindowState !== 'maximized')) {
maximizedCount++;
}
});
if (maximizedCount >= this._cData.currentAttentionPages.length) {
break;
}
await new Promise((resolve) => this._timer.addTimer(75, false, resolve, true));
}
if (elapsedTime > 5000) {
this._putLog('全アテンションページの最大化待ちタイムアウト検出.', LogLevels.INFO);
if (true === await ApiWrappers.readSessionStorageValueAsync({ IsEnabledClient: false })) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ReloadClient',
caller: '5A',
cause: '全アテンションページの最大化待ちタイムアウト'
});
}
}
resolve();
});
};
try {
const isShowedPipGamenTeiji = (WINDOW_ID_NONE !== await ApiWrappers.readSessionStorageValueAsync({ PipGamenTeijiWindowId: WINDOW_ID_NONE }));
await ApiWrappers.saveSessionStorageDataAsync({ IsNeedsWindowFocusChanged: false });
this.stopWatchAttentionPages();
if (isShowedPipGamenTeiji) {
await ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'ClosePipGamenTeijiWindow' });
await fnWaitMaximizedAttentionPagesAsync();
}
let promises = [];
this._cData.currentAttentionPages.forEach((pageInfo) => {
const windowId = pageInfo.currentPageWindowId;
promises.push(ApiWrappers.updateWindowAsync(windowId, { state: 'minimized' }, true));
});
await Promise.allSettled(promises);
return true;
}
catch (err) {
const errorMsg = 'ERROR - showClassworkPages() - fnHideAttentionPagesAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
return false;
}
};
if (reshowPageInfo) {
let pageKey;
this.closeCbtOpeningMessageAsync()
.then(() => {
return this._cAux.makeNewPageKeyAsync();
})
.then((newPageKey) => {
pageKey = newPageKey;
return fnShowPageAsync(reshowPageInfo, pageKey);
})
.then(() => {
if (opt_callback) { opt_callback(true); }
})
.catch((err) => {
this._putLog(`ERROR - showClassworkPages() : ${err.message || err || ''}`, LogLevels.FATAL);
if (opt_callback) { opt_callback(false); }
});
}
else {
this.closeCbtOpeningMessageAsync()
.then(() => {
return this._cAux.getActiveTabAsync();
})
.then((activeTab) => {
return ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenClassworkPageEnds: ((activeTab) ? activeTab.windowId : WINDOW_ID_NONE),
TabIdToActiveWhenClassworkPageEnds: ((activeTab) ? activeTab.id : TAB_ID_NONE),
});
})
.then(() => {
return this._cAux.flashClientCorePageAsync();
})
.then(()=> {
if ((this._cData.isGamenLockMode) || (this._cData.isGamenTeijiMode)) {
return fnHideAttentionPagesAsync();
}
})
.then(()=> {
this._timer.addTimer(100, false, fnShowAllPage, opt_callback);
});
}
};
closeClassworkPagesAsync(isExceptPrimary=false) {
return new Promise((resolve) => {
try {
const primaryPageInfo = this._cData.currentClassworkPages.find((v) => (!! v.isPrimary));
if (! primaryPageInfo) {
isExceptPrimary = false;
}
if (! isExceptPrimary) {
this.stopWatchClassworkPages();
}
if (this._cData.isConfirmingJoinClasswork)  this._cData.isConfirmingJoinClasswork = false;
if (this._cData.isConfirmingScreenSharing)  this._cData.isConfirmingScreenSharing = false;
this._cData.currentClassworkPages.forEach((pageInfo) => {
if ((pageInfo.currentPageTabId !== TAB_ID_NONE) && (! (isExceptPrimary && pageInfo.isPrimary))) {
ApiWrappers.sendInternalMsgAsync(true, pageInfo.currentPageTabId, { cmd: 'ClosePage' }).then(() => {});
}
});
if (isExceptPrimary) {
primaryPageInfo.currentWindowState = 'minimized';
}
ApiWrappers.saveSessionStorageDataAsync({ ClassworkPageMode: '' })
.then(() => {
return this.waitClosedClassworkPagesAsync(isExceptPrimary);
})
.then(() => {
return ApiWrappers.readSessionStorageDataAsync({
WindowIdToActiveWhenClassworkPageEnds: WINDOW_ID_NONE,
TabIdToActiveWhenClassworkPageEnds: TAB_ID_NONE,
});
})
.then((storage) => {
if (('TabIdToActiveWhenClassworkPageEnds' in storage) &&
(storage.TabIdToActiveWhenClassworkPageEnds !== TAB_ID_NONE)) {
return this._cAux.activeWindowTabAsync(storage.WindowIdToActiveWhenClassworkPageEnds, storage.TabIdToActiveWhenClassworkPageEnds);
}
})
.then(() => {
return ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenClassworkPageEnds: WINDOW_ID_NONE,
TabIdToActiveWhenClassworkPageEnds: TAB_ID_NONE,
});
})
.then(() => {
return ApiWrappers.readSessionStorageDataAsync({
ClassworkPageMode: '',
AttentionPageMode: '',
CbtOpeningMessage: ''
}, true);
})
.then((storage) => {
if ((! storage.ClassworkPageMode) && (! storage.AttentionPageMode)) {
if (storage.CbtOpeningMessage) {
return this.showCbtOpeningMessageAsync(storage.CbtOpeningMessage);
}
else if (this._cData.pendingMessengerPushMessage) {
return this.showPendingMessengerPushNotificationAsync();
}
}
})
.then(() => {
resolve();
});
}
catch (err) {
this._putLog(`ERROR - closeClassworkPagesAsync() : ${err.message || err || ''}`, LogLevels.INFO);
resolve();
}
});
}
waitClosedClassworkPagesAsync(isExceptPrimary=false) {
const beginTime = window.performance.now();
let removedWindows = false;
return new Promise(async(resolve) => {
while(((isExceptPrimary) && (this._cData.currentClassworkPages.length > 1)) ||
((! isExceptPrimary) && (this._cData.currentClassworkPages.length > 0))) {
const elapsedTime = Math.trunc(window.performance.now() - beginTime);
if ((! removedWindows) && (elapsedTime > 3000)) {
removedWindows = true;
this._cData.currentClassworkPages.forEach((pageInfo) => {
if ((pageInfo.currentPageWindowId !== WINDOW_ID_NONE) && (! (isExceptPrimary && pageInfo.isPrimary))) {
ApiWrappers.removeWindowAsync(pageInfo.currentPageWindowId).then(() => {});
}
});
}
else if (elapsedTime > 10000) {
this._putLog('授業ページのクローズタイムアウト検出.', LogLevels.INFO);
ApiWrappers.readSessionStorageValueAsync({ IsEnabledClient: false })
.then((isEnabledClient) => {
if (isEnabledClient === true) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ReloadClient',
caller: '5B',
cause: '授業ページのクローズタイムアウト'
});
}
});
break;
}
await new Promise((resolve) => this._timer.addTimer(75, false, resolve, true));
};
resolve();
});
}
startWatchClassworkPages() {
try {
this.stopWatchClassworkPages();
this._isWatchClassworkPages = true;
this._watchClassworkPagesTimerId = this._timer.addTimer(950, false, this._watchClassworkPages);
}
catch (err) {
this._putLog(`ERROR - startWatchClassworkPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchClassworkPages() {
try {
if (this._isWatchClassworkPages) {
this._isWatchClassworkPages = false;
if (this._watchClassworkPagesTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchClassworkPagesTimerId);
this._watchClassworkPagesTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchClassworkPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
showAttentionPages(reshowPageInfo, opt_callback=null) {
const fnWaitShowPageAsync = (id, isPrimary, pageKey, isDuplicate) => {
return new Promise(async(resolve) => {
while (true === await new Promise((resolve) => this._timer.addTimer(75, false, resolve, true))) {
const hitPageInfo = this._cData.currentAttentionPages.find((v) => {
return (v.id === id) && (v.isPrimary === isPrimary) && (v.currentPageKey === pageKey) && (v.isDuplicate === isDuplicate);
});
if (! hitPageInfo) {
break;
}
if ((hitPageInfo.currentPageWindowId !== WINDOW_ID_NONE) || (hitPageInfo.openRequestTimeout === -1)) {
break;
}
}
resolve();
});
};
const fnShowPageAsync = (pageInfo, pageKey) => {
return new Promise((resolve, reject) => {
try {
pageInfo.currentPageKey = pageKey;
pageInfo.currentPageWindowId = WINDOW_ID_NONE;
pageInfo.currentPageTabId = TAB_ID_NONE;
pageInfo.currentWindowState = '';
pageInfo.openRequestTimeout = 3;
const url = `${this._cData.attentionPageAbsoluteUrl}?pid=${pageInfo.id}&primary=${pageInfo.isPrimary}&key=${pageKey}`;
return Promise.resolve()
.then(() => {
if (pageInfo.isPrimary) {
const windowFeatures = `left=${pageInfo.workAreaLeft},top=${pageInfo.workAreaTop},width=${pageInfo.workAreaWidth},height=${pageInfo.workAreaHeight}`;
window.open(url, '_blank', windowFeatures);
return;
}
const createData = {
url: url,
focused: true,
type: 'popup',
state: 'normal',
left: pageInfo.screenLeft,
top: pageInfo.screenTop,
width: pageInfo.screenWidth,
height: pageInfo.screenHeight,
};
return ApiWrappers.createWindowAsync(createData, true);
})
.then(() => {
return fnWaitShowPageAsync(pageInfo.id, pageInfo.isPrimary, pageInfo.currentPageKey, pageInfo.isDuplicate);
})
.then(() => {
resolve();
})
.catch((err) => {
const errorMsg = 'ERROR - showAttentionPages() - fnShowPageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
reject(errorMsg);
});
}
catch (err) {
const errorMsg = 'ERROR - showAttentionPages() - fnShowPageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
reject(errorMsg);
}
});
};
const fnShowAllPage = (callback=null) => {
let pageKey;
let screenInfos;
Utils.assert((this._cData.currentAttentionPages.length === 0), 'Implementation Error. -- currentAttentionPages not empty.');
this._cData.currentAttentionPages.length = 0;
this._cAux.flashClientCorePageAsync(false, 100)
.then(() => {
return ApiWrappers.getClientScreenInfoAsync(this._cData.isDeveloperMode);
})
.then((results) => {
screenInfos = results;
this._attentionScreenInfoString = this._cAux.makeScreenInfoString(screenInfos);
return this._cAux.makeNewPageKeyAsync();
})
.then((newPageKey) => {
pageKey = newPageKey;
let promises = [];
let pageId = 0;
screenInfos.forEach((info) => {
const pageInfo = new PageScreenInfo(++pageId, info.displayId, info.isPrimary, info.screenBounds, info.workAreaBounds, false);
this._cData.currentAttentionPages.push(pageInfo);
promises.push(fnShowPageAsync(pageInfo, pageKey));
if ((this._cData.osType === OsTypes.CHROME) && (info.isPrimary)) {
const pageInfo2 = new PageScreenInfo(++pageId, info.displayId, info.isPrimary, info.screenBounds, info.workAreaBounds, true);
this._cData.currentAttentionPages.push(pageInfo2);
promises.push(fnShowPageAsync(pageInfo2, pageKey));
}
});
return Promise.allSettled(promises);
})
.then(() => {
if (this._cData.isConfirmingScreenSharing) {
let promises = [];
this._cData.currentAttentionPages.forEach((pageInfo) => {
const windowId = pageInfo.currentPageWindowId;
promises.push(ApiWrappers.updateWindowAsync(windowId, { state: 'minimized' }, true));
});
return Promise.allSettled(promises);
}
else {
this.startWatchAttentionPages();
return ApiWrappers.saveSessionStorageDataAsync({ IsNeedsWindowFocusChanged: true });
}
})
.then(() => {
if (callback) { callback(true); }
})
.catch((err) => {
this._putLog(`ERROR - showAttentionPages() - fnShowAllPage() : ${err.message || err || ''}`, LogLevels.FATAL);
if (callback) { callback(false); }
});
};
if (reshowPageInfo) {
let pageKey;
this.closeCbtOpeningMessageAsync()
.then(() => {
return this._cAux.makeNewPageKeyAsync();
})
.then((newPageKey) => {
pageKey = newPageKey;
return fnShowPageAsync(reshowPageInfo, pageKey);
})
.then(() => {
if (opt_callback) { opt_callback(true); }
})
.catch((err) => {
this._putLog(`ERROR - showAttentionPages() : ${err.message || err || ''}`, LogLevels.FATAL);
if (opt_callback) { opt_callback(false); }
});
}
else {
this.closeCbtOpeningMessageAsync()
.then(() => {
return this._cAux.getActiveTabAsync();
})
.then((activeTab) => {
return ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenAttentionPageEnds: ((activeTab) ? activeTab.windowId : WINDOW_ID_NONE),
TabIdToActiveWhenAttentionPageEnds: ((activeTab) ? activeTab.id : TAB_ID_NONE),
});
})
.then(() => {
return this._cAux.flashClientCorePageAsync();
})
.then(()=> {
this._timer.addTimer(100, false, fnShowAllPage, opt_callback);
});
}
}
closeAttentionPagesAsync() {
return new Promise((resolve) => {
try {
ApiWrappers.saveSessionStorageDataAsync({ IsNeedsWindowFocusChanged: false })
.then(() => {
this.stopWatchAttentionPages();
if (this._cData.isGamenLockMode)  this._cData.isGamenLockMode = false;
if (this._cData.isGamenTeijiMode)  this._cData.isGamenTeijiMode = false;
this._cData.currentAttentionPages.forEach((pageInfo) => {
if (pageInfo.currentPageTabId !== TAB_ID_NONE) {
ApiWrappers.sendInternalMsgAsync(true, pageInfo.currentPageTabId, { cmd: 'ClosePage' }).then(() => {});
}
});
return ApiWrappers.saveSessionStorageDataAsync({ AttentionPageMode: '' });
})
.then(() => {
return this.waitClosedAttentionPagesAsync();
})
.then(() => {
return ApiWrappers.readSessionStorageDataAsync({
WindowIdToActiveWhenAttentionPageEnds: WINDOW_ID_NONE,
TabIdToActiveWhenAttentionPageEnds: TAB_ID_NONE,
});
})
.then((storage) => {
if (('TabIdToActiveWhenAttentionPageEnds' in storage) &&
(storage.TabIdToActiveWhenAttentionPageEnds !== TAB_ID_NONE)) {
return this._cAux.activeWindowTabAsync(storage.WindowIdToActiveWhenAttentionPageEnds, storage.TabIdToActiveWhenAttentionPageEnds);
}
})
.then(() => {
return ApiWrappers.saveSessionStorageDataAsync({
WindowIdToActiveWhenAttentionPageEnds: WINDOW_ID_NONE,
TabIdToActiveWhenAttentionPageEnds: TAB_ID_NONE,
});
})
.then(() => {
return ApiWrappers.readSessionStorageDataAsync({
ClassworkPageMode: '',
AttentionPageMode: '',
CbtOpeningMessage: ''
}, true);
})
.then((storage) => {
if ((! storage.ClassworkPageMode) && (! storage.AttentionPageMode)) {
if (storage.CbtOpeningMessage) {
return this.showCbtOpeningMessageAsync(storage.CbtOpeningMessage);
}
else if (this._cData.pendingMessengerPushMessage) {
return this.showPendingMessengerPushNotificationAsync();
}
}
})
.then(() => {
resolve();
});
}
catch (err) {
this._putLog(`ERROR - closeAttentionPagesAsync() : ${err.message || err || ''}`, LogLevels.INFO);
resolve();
}
});
}
waitClosedAttentionPagesAsync() {
const beginTime = window.performance.now();
let removedWindows = false;
return new Promise(async(resolve) => {
while (this._cData.currentAttentionPages.length > 0) {
const elapsedTime = Math.trunc(window.performance.now() - beginTime);
if ((! removedWindows) && (elapsedTime > 3000)) {
removedWindows = true;
this._cData.currentAttentionPages.forEach((pageInfo) => {
if (pageInfo.currentPageWindowId !== WINDOW_ID_NONE) {
ApiWrappers.removeWindowAsync(pageInfo.currentPageWindowId).then(() => {});
}
});
}
else if (elapsedTime > 10000) {
this._putLog('アテンションページのクローズタイムアウト検出.', LogLevels.INFO);
ApiWrappers.readSessionStorageValueAsync({ IsEnabledClient: false })
.then((isEnabledClient) => {
if (isEnabledClient === true) {
Utils.postBroadcastMessage(BcNames.CLIENT_CORE, {
cmd: 'ReloadClient',
caller: '5C',
cause: 'アテンションページのクローズタイムアウト'
});
}
});
break;
}
await new Promise((resolve) => this._timer.addTimer(75, false, resolve, true));
};
resolve();
});
}
requestUpdateAttentionPages() {
ApiWrappers.sendInternalMsgAsync(true, TAB_ID_NONE, { cmd: 'UpdateAttentionPage' }, true)
.catch((err) => {
this._putLog(`ERROR - requestUpdateAttentionPages() : ${err.message || err || ''}`, LogLevels.INFO);
});
}
startWatchAttentionPages() {
try {
this.stopWatchAttentionPages();
this._cData.lastFocusedWindowId = WINDOW_ID_NONE;
this._isWatchAttentionPages = true;
this._watchAttentionPagesTimerId = this._timer.addTimer(0, false, this._watchAttentionPages);
}
catch (err) {
this._putLog(`ERROR - startWatchAttentionPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchAttentionPages() {
try {
if (this._isWatchAttentionPages) {
this._isWatchAttentionPages = false;
if (this._watchAttentionPagesTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchAttentionPagesTimerId);
this._watchAttentionPagesTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchAttentionPages() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchCoreWindowState() {
try {
this.stopWatchCoreWindowState();
this._isWatchCoreWindowState = true;
this._watchCoreWindowStateTimerId = this._timer.addTimer(450, false, this._watchCoreWindowState);
}
catch (err) {
this._putLog(`ERROR - startWatchCoreWindowState() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchCoreWindowState() {
try {
if (this._isWatchCoreWindowState) {
this._isWatchCoreWindowState = false;
if (this._watchCoreWindowStateTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchCoreWindowStateTimerId);
this._watchCoreWindowStateTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchCoreWindowState() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchActiveTab(targetCtrlInfo) {
try {
this.stopWatchActiveTab(targetCtrlInfo);
targetCtrlInfo.isBusyJunshi = false;
targetCtrlInfo.isWatchActiveTab = true;
targetCtrlInfo.watchActiveTabTimerId = this._timer.addTimer(125, true, this._watchActiveTab, targetCtrlInfo.mailAddress);
}
catch (err) {
this._putLog(`ERROR - startWatchActiveTab() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchActiveTab(targetCtrlInfo) {
try {
if (targetCtrlInfo.isWatchActiveTab) {
targetCtrlInfo.isWatchActiveTab = false;
if (targetCtrlInfo.watchActiveTabTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(targetCtrlInfo.watchActiveTabTimerId);
targetCtrlInfo.watchActiveTabTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchActiveTab() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchDesktopGamen(targetCtrlInfo) {
try {
this.stopWatchDesktopGamen(targetCtrlInfo);
targetCtrlInfo.isBusyJunshi = false;
targetCtrlInfo.isWatchDesktopGamen = true;
targetCtrlInfo.watchDesktopGamenTimerId = this._timer.addTimer(1100, false, (ctrlMail) => {
const info = this._cAux.findCtrlInfoByMail(ctrlMail);
if (info) {
info.watchDesktopGamenTimerId = this._timer.addTimer(125, true, this._watchDesktopGamen, ctrlMail);
}
}, targetCtrlInfo.mailAddress);
}
catch (err) {
this._putLog(`ERROR - startWatchDesktopGamen() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchDesktopGamen(targetCtrlInfo) {
try {
if (targetCtrlInfo.isWatchDesktopGamen) {
targetCtrlInfo.isWatchDesktopGamen = false;
if (targetCtrlInfo.watchDesktopGamenTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(targetCtrlInfo.watchDesktopGamenTimerId);
targetCtrlInfo.watchDesktopGamenTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchDesktopGamen() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchClientState() {
try {
this.stopWatchClientState();
this._isWatchClientState = true;
this._watchClientStateTimerId = this._timer.addTimer(0, false, this._watchClientState);
}
catch (err) {
this._putLog(`ERROR - startWatchClientState() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchClientState() {
try {
if (this._isWatchClientState) {
this._isWatchClientState = false;
if (this._watchClientStateTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchClientStateTimerId);
this._watchClientStateTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchClientState() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchCbtMode() {
try {
this.stopWatchCbtMode();
this._isWatchCbtMode = true;
this._watchCbtModeTimerId = this._timer.addTimer(0, false, this._watchCbtMode);
}
catch (err) {
this._putLog(`ERROR - startWatchCbtMode() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchCbtMode() {
try {
if (this._isWatchCbtMode) {
this._isWatchCbtMode = false;
if (this._watchCbtModeTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchCbtModeTimerId);
this._watchCbtModeTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchCbtMode() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchCbtOpeningMessage() {
try {
this.stopWatchCbtOpeningMessage();
this._isWatchCbtOpeningMessage = true;
this._watchCbtOpeningMessage();
}
catch (err) {
this._putLog(`ERROR - startWatchCbtOpeningMessage() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchCbtOpeningMessage() {
try {
if (this._isWatchCbtOpeningMessage) {
this._isWatchCbtOpeningMessage = false;
if (this._watchCbtOpeningMessageTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchCbtOpeningMessageTimerId);
this._watchCbtOpeningMessageTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchCbtOpeningMessage() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
advanceWatchCbtMode() {
try {
if ((this._isWatchCbtMode) && (this._watchCbtModeTimerId !== TIMER_ID_NONE)) {
this._timer.advanceTimer(this._watchCbtModeTimerId);
}
}
catch (err) {
this._putLog(`ERROR - advanceWatchCbtMode() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchAvailableTime() {
try {
this.stopWatchAvailableTime();
this._isWatchAvailableTime = true;
this._watchAvailableTimeTimerId = this._timer.addTimer(0, false, this._watchAvailableTime);
}
catch (err) {
this._putLog(`ERROR - startWatchAvailableTime() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchAvailableTime() {
try {
if (this._isWatchAvailableTime) {
this._isWatchAvailableTime = false;
if (this._watchAvailableTimeTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchAvailableTimeTimerId);
this._watchAvailableTimeTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchAvailableTime() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
startWatchNightLimit() {
try {
this.stopWatchNightLimit();
this._isWatchNightLimit = true;
this._watchNightLimitTimerId = this._timer.addTimer(0, false, this._watchNightLimit);
}
catch (err) {
this._putLog(`ERROR - startWatchNightLimit() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWatchNightLimit() {
try {
if (this._isWatchNightLimit) {
this._isWatchNightLimit = false;
if (this._watchNightLimitTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._watchNightLimitTimerId);
this._watchNightLimitTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWatchNightLimit() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
changeDesktopCapture(delay=250) {
this.cancelChangeDesktopCapture();
this._changeDesktopCaptureTimerId = this._timer.addTimer(delay, false, () => {
try {
this._changeDesktopCaptureTimerId = TIMER_ID_NONE;
if (this._cData.desktopCapturedStream) {
const track = this._cData.desktopCapturedStream.getVideoTracks()[0];
const settings = track.getSettings();
if (settings) {
this._cData.desktopCapturedAspectRatio = settings.width / settings.height;
this._cData.desktopCapturedWidth = settings.width;
}
else {
this._cData.desktopCapturedAspectRatio = screen.width / screen.height;
this._cData.desktopCapturedWidth = screen.width;
}
const tempWidth = this._cData.desktopCapturedWidth;
const tempHeight = Math.round(this._cData.desktopCapturedWidth / this._cData.desktopCapturedAspectRatio);
this._cData.desktopCapturedCanvas = new OffscreenCanvas(tempWidth, tempHeight);
this._cData.desktopCapturedVideo = document.createElement('video');
try {
this._cData.desktopCapturedVideo.srcObject = this._cData.desktopCapturedStream;
this._cData.desktopCapturedVideo.volume = 0;
this._cData.desktopCapturedVideo.play();
}
catch (err) {
const errorMsg = 'ERROR - changeDesktopCapture() - fnChange() : デスクトップ画面キャプチャストリームの再生開始失敗.' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
}
this._cData.connectedCtrlInfos.forEach((info) => {
if (info.gamenJunshiType !== 'none') {
if (info.gamenJunshiType === 'tab') {
this.stopWatchActiveTab(info);
}
else if (info.gamenJunshiType === 'screen') {
this.stopWatchDesktopGamen(info);
this._cAux.stopDesktopJunshiStream(info);
}
this.setDesktopGamenJunshi(info);
}
});
}
}
catch (err) {
this._putLog(`ERROR - changeDesktopCapture() - fnChange() : ${err.message || err || ''}`, LogLevels.INFO);
}
});
}
cancelChangeDesktopCapture() {
if (this._changeDesktopCaptureTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._changeDesktopCaptureTimerId);
this._changeDesktopCaptureTimerId = TIMER_ID_NONE;
}
}
setDesktopGamenJunshi(targetCtrlInfo) {
try {
if (! targetCtrlInfo.desktopJunshiCanvas) {
targetCtrlInfo.desktopJunshiCanvas = new OffscreenCanvas(120, 90);
}
if (targetCtrlInfo.isGamenStreamTransfer()) {
if (! targetCtrlInfo.desktopJunshiStream) {
try {
targetCtrlInfo.desktopJunshiStream = this._cData.desktopCapturedStream.clone();
}
catch (err) {
throw new Error('デスクトップ画面キャプチャストリームのクローン失敗.' + ((err) ? ` : ${err.message || err}` : ''));
}
}
let frameWidth = targetCtrlInfo.gamenJunshiWidth;
if ((frameWidth === 0) || (frameWidth > this._cData.desktopCapturedWidth)) {
frameWidth = this._cData.desktopCapturedWidth;
}
targetCtrlInfo.appliedMaxPeerVideoFrameRate = 0;
Utils.setVideoStreamConstraints(targetCtrlInfo.desktopJunshiStream, frameWidth, this._cData.desktopCapturedAspectRatio, (result) => {
if (result) {
targetCtrlInfo.appliedDesktopJunshiWidth = frameWidth;
targetCtrlInfo.appliedDesktopJunshiAspectRatio = this._cData.desktopCapturedAspectRatio;
Utils.replacePeerVideoStream(targetCtrlInfo.peerConnection, targetCtrlInfo.desktopJunshiStream);
if (Utils.setMaxPeerVideoFrameRate(targetCtrlInfo.peerConnection, targetCtrlInfo.gamenJunshiFrameRate)) {
targetCtrlInfo.appliedMaxPeerVideoFrameRate = targetCtrlInfo.gamenJunshiFrameRate;
}
}
});
}
targetCtrlInfo.gamenJunshiType = 'screen';
if (targetCtrlInfo.isJunshiCaptured !== true) {
targetCtrlInfo.isJunshiCaptured = true;
if (targetCtrlInfo.isFirebaseJunshi) {
targetCtrlInfo.isChangedJunshiRequirements = true;
}
this._cComm.sendClientCapturedResult(targetCtrlInfo);
}
this._cComm.sendClientState(targetCtrlInfo.mailAddress);
this.stopWatchDesktopGamen(targetCtrlInfo);
this._cAux.adjustLastJunshiTime(targetCtrlInfo);
targetCtrlInfo.lastJunshiTime = new Date(0);
this.startWatchDesktopGamen(targetCtrlInfo);
}
catch (err) {
this._putLog(`ERROR - setDesktopGamenJunshi() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
async collectTabsIntoBrowserAsync(allBrowsers) {
Utils.assert((this._cData.isCbtModeAlwaysBrowserMaximize && this._cData._isCbtModeAlwaysBrowserOnTop), 'Implementation Error. -- collectTabsIntoBrowserAsync()');
if (! allBrowsers?.length)  return null;
try {
let alwaysTopWindowId = await ApiWrappers.readSessionStorageValueAsync({ AlwaysBrowserOnTopWindowId: WINDOW_ID_NONE }, true);
let alwaysTopWindowIndex = -1;
if (alwaysTopWindowId !== WINDOW_ID_NONE) {
alwaysTopWindowIndex = allBrowsers.findIndex((wnd) => { return wnd.id === alwaysTopWindowId });
}
if (alwaysTopWindowIndex === -1) {
const lastFocusedWindow = await ApiWrappers.getLastFocusedWindowAsync({ windowTypes: ['normal'] });
alwaysTopWindowIndex = allBrowsers.findIndex((wnd) => { return wnd.id === lastFocusedWindow.id });
if (alwaysTopWindowIndex === -1) {
return null;
}
}
if (alwaysTopWindowId !== allBrowsers[alwaysTopWindowIndex].id) {
alwaysTopWindowId = allBrowsers[alwaysTopWindowIndex].id;
await ApiWrappers.saveSessionStorageDataAsync({ AlwaysBrowserOnTopWindowId: alwaysTopWindowId }, true);
}
if (allBrowsers.length > 1) {
const moveTabIds = [];
for (const wnd of allBrowsers) {
if (wnd.id !== alwaysTopWindowId) {
for (const tab of wnd.tabs) {
moveTabIds.push(tab.id);
}
}
}
if (moveTabIds.length) {
const moveProperties = {
windowId: alwaysTopWindowId,
index: -1
};
await ApiWrappers.moveTabAsync(moveTabIds, moveProperties);
await ApiWrappers.updateTabAsync(moveTabIds[0], { active: true });
}
}
return await ApiWrappers.getWindowAsync(alwaysTopWindowId, { windowTypes: ['normal'] });
}
catch (err) {
this._putLog(`ERROR - collectTabsIntoBrowserAsync() : ${err.message || err || ''}`, LogLevels.INFO);
return null;
}
}
terminateCbtModeAsync(dueToNightLimit, cause) {
const fnGetConfirmScreenSharingCounterAsync = () => {
return new Promise((resolve) => {
CountManager.readAsync('ConfirmScreenSharing')
.then((count) => {
resolve(count);
})
.catch((err) => {
resolve(0);
});
});
};
return new Promise((resolve) => {
try {
if (this._cData.isCbtMode) {
this._putLog(`CBTモードを終了します.  (${cause})`, LogLevels.FATAL);
if (this._cData.cbtModeBlockedInfo !== null) {
const blockedInfo = this._cData.cbtModeBlockedInfo;
blockedInfo['__EndingTime__'] = Date.now();
this._cData.cbtModeBlockedInfo = blockedInfo;
}
if (! dueToNightLimit) {
if (this._cData.appliedBrowserSeigen === BrowserSeigens.CBTMODE) {
this._requestChangeBrowserSeigen(BrowserSeigens.CBTMODE, false);
}
}
this.stopWatchCbtMode();
this.closeCbtOpeningMessageAsync(true)
.then(() => {
return fnGetConfirmScreenSharingCounterAsync();
})
.then((confirmScreenSharingCounter) => {
this._cData.isCbtMode = false;
this._cData.isCbtModeAlwaysDesktopJunshi = false;
this._cData.isCbtModeAlwaysBrowserMaximize = false;
this._cData.isCbtModeAlwaysBrowserOnTop = false;
if (this._cData.isConfirmingScreenSharing) {
if (((this._cData.cbtModeInfo.isFirstDesktopJunshi) && (confirmScreenSharingCounter === 1)) ||
(this._cData.cbtModeInfo.isAlwaysDesktopJunshi)) {
return this.closeClassworkPagesAsync(false);
}
}
if (this._cData.connectedCtrlInfos.length === 0) {
return this.closeClassworkPagesAsync(false);
}
})
.then(() => {
return CountManager.deleteAsync('ConfirmScreenSharing');
})
.finally(() => {
this._cData.cbtModeInfo = null;
this._timer.addTimer(450, false, () => {
this._cAux.checkClientState(false, () => {
this._cComm.sendClientState();
});
});
resolve();
});
}
else {
resolve();
}
}
catch (err) {
const errorMsg = 'ERROR - terminateCbtModeAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.FATAL);
resolve();
}
});
}
showCbtOpeningMessageAsync(message) {
return new Promise(async (resolve) => {
try {
this._cbtOpeningMessageBaseMsec = -1;
await this._cAux.openNotificationAsync('CbtOpening', message);
this._cbtOpeningMessageBaseMsec = Math.floor(performance.now());
this.startWatchCbtOpeningMessage();
resolve();
}
catch (err) {
const errorMsg = 'ERROR - showCbtOpeningMessageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve();
}
});
}
closeCbtOpeningMessageAsync(neverShowAgain=false) {
return new Promise(async (resolve) => {
try {
if (this._cbtOpeningMessageBaseMsec !== -1) {
this.stopWatchCbtOpeningMessage();
if (false === await this._cAux.closeNotificationAsync('CbtOpening')) {
this._putLog('CBTモード開始メッセージ通知は閉じられていました.', LogLevels.INFO);
neverShowAgain = true;
}
else {
let totalElapsed = await ApiWrappers.readSessionStorageValueAsync({ CbtOpeningMessageElapsedMsec: 0 });
if ((typeof totalElapsed === 'number') && (this._cbtOpeningMessageBaseMsec !== -1)) {
const nowMsec = Math.floor(performance.now());
totalElapsed += (nowMsec - this._cbtOpeningMessageBaseMsec);
this._cbtOpeningMessageBaseMsec = nowMsec;
if (totalElapsed >= (Constants.MAX_SHOW_CBT_OPENING_MESSAGE - 1000)) {
this._putLog('CBTモード開始メッセージ通知終了間際の時間のため規定時間経過として扱います.', LogLevels.INFO);
neverShowAgain = true;
}
else {
await ApiWrappers.saveSessionStorageDataAsync({ CbtOpeningMessageElapsedMsec: totalElapsed });
}
}
}
this._cbtOpeningMessageBaseMsec = -1;
}
if (neverShowAgain) {
await ApiWrappers.saveSessionStorageDataAsync({
CbtOpeningMessage: '',
CbtOpeningMessageElapsedMsec: 0,
});
}
resolve();
}
catch (err) {
const errorMsg = 'ERROR - closeCbtOpeningMessageAsync()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve();
}
});
}
showPendingMessengerPushNotificationAsync() {
return new Promise(async (resolve) => {
try {
if (this._cData.pendingMessengerPushMessage) {
await this._cAux.openNotificationAsync('Messenger', this._cData.pendingMessengerPushMessage);
this._cData.pendingMessengerPushMessage= null;
}
resolve();
}
catch (err) {
const errorMsg = 'ERROR - showPendingMessengerPushNotification()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
resolve();
}
});
}
}
