'use strict';
export class WbTimeLimit {
constructor(availableTime=null, isStaggerStartTime=false) {
this._dayOfWeekString = [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ];
this._enabled = false;
this._availableTimetables = [];
this._isStaggerStartTime = isStaggerStartTime;
this._staggerStartConstant = Math.round(Math.random() * 30);
this._currentDelayStart = 0;
if (availableTime) {
this.changeAvailableTime(availableTime);
}
}
changeAvailableTime(availableTime) {
const fnConvertHHMMtoSeconds = (hhmm) => {
if ((typeof hhmm === 'string') && (hhmm.match('^[0-9]{4}$'))) {
const hours = parseInt(hhmm.substring(0, 2), 10);
const minutes = parseInt(hhmm.substring(2, 4), 10);
if ((hours <= 24) && (minutes <= 59) && ((hours !== 24) || (minutes === 0))) {
return ((hours * 60) + minutes) * 60;
}
}
return -1;
};
if (typeof availableTime === 'string') {
try {
availableTime = JSON.parse(availableTime);
}
catch (err) {
availableTime = {"enabled":false};
}
}
this._enabled = false;
this._currentDelayStart = 0;
this._availableTimetables.splice(0);
if (availableTime) {
this._enabled = (!! availableTime.enabled);
if (this._enabled) {
if (typeof availableTime.dayOfWeek === 'string') {
const startSeconds = fnConvertHHMMtoSeconds(availableTime.startTime);
const endSeconds = fnConvertHHMMtoSeconds(availableTime.endTime);
if ((startSeconds !== -1) && (endSeconds !== -1) && (startSeconds < endSeconds)) {
const days = availableTime.dayOfWeek.split(',');
if ((this._isStaggerStartTime) && (startSeconds !== 0) && (endSeconds !== (24 * 60 * 60))) {
this._currentDelayStart = this._staggerStartConstant;
}
for (let dayOfWeekIndex = 0; dayOfWeekIndex < this._dayOfWeekString.length; dayOfWeekIndex++) {
const tempDayOfWeekString = this._dayOfWeekString[dayOfWeekIndex].toLowerCase();
if (days.find((v) => v.toLowerCase() === tempDayOfWeekString)) {
const midnightSeconds = 24 * 60 * 60 * dayOfWeekIndex;
const rangeText = `${availableTime.startTime.substring(0, 2)}:${availableTime.startTime.substring(2, 4)}` +
` - ${availableTime.endTime.substring(0, 2)}:${availableTime.endTime.substring(2, 4)}`;
this._availableTimetables.push({
start: (midnightSeconds + startSeconds + this._currentDelayStart),
end: (midnightSeconds + endSeconds),
dayOfWeekCode: dayOfWeekIndex,
timeRangeText: rangeText
});
}
}
}
}
}
}
}
getAvailableTimeInfo() {
let resultInfo;
if (this._enabled) {
resultInfo = [];
for (const timetable of this._availableTimetables) {
resultInfo.push({
dayOfWeek: this._dayOfWeekString[timetable.dayOfWeekCode],
dayOfWeekCode: timetable.dayOfWeekCode,
timeRangeText: timetable.timeRangeText
});
}
}
else {
resultInfo = null;
}
return resultInfo;
}
getCurrentTime() {
const time = new Date();
time.setUTCHours(time.getUTCHours() + 9);
const result = {
year: time.getUTCFullYear(),
month: time.getUTCMonth() + 1,
date: time.getUTCDate(),
hours: time.getUTCHours(),
minutes: time.getUTCMinutes(),
seconds: time.getUTCSeconds(),
dayOfWeek: this._dayOfWeekString[time.getUTCDay()],
dayOfWeekCode: time.getUTCDay(),
delayStartSeconds: this._currentDelayStart
};
return result;
}
isAvailableNow() {
let result = 0;
if (this._enabled) {
if (this._availableTimetables.length === 0) {
result = -9999;
}
else {
const currentTime = this.getCurrentTime();
let currentSeconds = currentTime.dayOfWeekCode * 24 * 60 * 60;
currentSeconds += currentTime.hours * 60 * 60;
currentSeconds += currentTime.minutes * 60;
currentSeconds += currentTime.seconds;
let tableIndex;
for (tableIndex = 0; tableIndex < this._availableTimetables.length; tableIndex++) {
const tableData = this._availableTimetables[tableIndex];
if (currentSeconds < tableData.start) {
result = Math.max((currentSeconds - tableData.start), -3600);
break;
}
if (currentSeconds < tableData.end) {
if (this._availableTimetables.length >= 2) {
if ((tableData.end % (24 * 60 * 60)) === 0) {
const tempEnd = tableData.end % (7 * 24 * 60 * 60);
const tempStart = this._availableTimetables[(tableIndex + 1) % this._availableTimetables.length].start;
if (tempEnd === tempStart) {
result = 3600;
break;
}
}
}
result = Math.min((tableData.end - currentSeconds), 3600);
break;
}
}
if (result === 0) {
result = Math.min(Math.max((currentSeconds - ((7 * 24 * 60 * 60) + this._availableTimetables[0].start)), -3600), -1);
}
}
}
return result;
}
}
