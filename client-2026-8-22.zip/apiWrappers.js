'use strict';
const JSFILEVER_apiWrappers = '3.2.1.1001';
class ApiWrappers {
static sendInternalMsgAsync(isSendOnly, tabId, message, useReject=false) {
return new Promise((resolve, reject) => {
try {
if (tabId === TAB_ID_NONE) {
chrome.runtime.sendMessage(message, (response) => {
if (chrome.runtime.lastError) {
if (useReject) {
if ((isSendOnly) && (chrome.runtime.lastError.message === 'The message port closed before a response was received.')) {
resolve();
}
else {
reject(`Failed sendInternalMsgAsync() 1 : ${chrome.runtime.lastError.message}`);
}
}
else if (isSendOnly) {
resolve();
}
else {
resolve(null);
}
}
else {
if (isSendOnly) {
resolve();
}
else {
resolve(response);
}
}
});
}
else {
chrome.tabs.sendMessage(tabId, message, (response) => {
if (chrome.runtime.lastError) {
if (useReject) {
if ((isSendOnly) && (chrome.runtime.lastError.message === 'The message port closed before a response was received.')) {
resolve();
}
else {
reject(`Failed sendInternalMsgAsync() 2 : ${chrome.runtime.lastError.message}`);
}
}
else if (isSendOnly) {
resolve();
}
else {
resolve(null);
}
}
else {
if (isSendOnly) {
resolve();
}
else {
resolve(response);
}
}
});
}
}
catch (err) {
if (useReject) {
reject('Failed sendInternalMsgAsync() 3' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
};
static getSignedUserEmailAsync(useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.identity.getProfileUserInfo((userInfo) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getSignedUserEmailAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve('');
}
}
else if (! userInfo) {
if (useReject) {
reject('Failed getSignedUserEmailAsync() : callback parameter (userInfo) is empty.');
}
else {
resolve('');
}
}
else {
resolve(userInfo.email);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getSignedUserEmailAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve('');
}
}
});
}
static readManagedStorageDataAsync(keys, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.managed.get(keys, (result) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed readManagedStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve({});
}
}
else {
resolve(result);
}
});
});
}
static readLocalStorageValueAsync(key, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.local.get(key, (result) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed readLocalStorageValueAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else {
const values = Object.values(result);
if (values?.length === 1) {
resolve(values[0]);
}
else {
resolve(null);
}
}
});
});
}
static readLocalStorageDataAsync(keys, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.local.get(keys, (result) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed readLocalStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve({});
}
}
else {
resolve(result);
}
});
});
}
static saveLocalStorageDataAsync(data, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.local.set(data, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed saveLocalStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
});
}
static removeLocalStorageDataAsync(keys, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.local.remove(keys, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed removeLocalStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
});
}
static readSessionStorageValueAsync(key, useReject=false) {
return new Promise((resolve, reject) => {
if (('session' in chrome.storage) && ('get' in chrome.storage.session)) {
chrome.storage.session.get(key, (result) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed readSessionStorageValueAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else {
const values = Object.values(result);
if (values?.length === 1) {
resolve(values[0]);
}
else {
resolve(null);
}
}
});
}
else {
if (useReject) {
reject('Unsupported chrome.storage.session');
}
else {
resolve(null);
}
}
});
}
static readSessionStorageDataAsync(keys, useReject=false) {
return new Promise((resolve, reject) => {
if (('session' in chrome.storage) && ('get' in chrome.storage.session)) {
chrome.storage.session.get(keys, (result) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed readSessionStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve({});
}
}
else {
resolve(result);
}
});
}
else {
if (useReject) {
reject('Unsupported chrome.storage.session');
}
else {
resolve({});
}
}
});
}
static saveSessionStorageDataAsync(data, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.session.set(data, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed saveSessionStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
});
}
static removeSessionStorageDataAsync(keys, useReject=false) {
return new Promise((resolve, reject) => {
chrome.storage.session.remove(keys, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed removeSessionStorageDataAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
});
}
static getWindowAsync(windowId, queryOptions={}, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.get(windowId, queryOptions, (wnd) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! wnd) {
if (useReject) {
reject('Failed getWindowAsync() : callback parameter (wnd) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(wnd);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static getAllWindowAsync(queryOptions={}, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.getAll(queryOptions, (wnds) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getAllWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve([]);
}
}
else if (! wnds) {
if (useReject) {
reject('Failed getAllWindowAsync() : callback parameter (wnds) is empty.');
}
else {
resolve([]);
}
}
else {
resolve(wnds);
}
});
}
catch (err) {
if (useReject) {
const errorMsg = 'Failed getAllWindowAsync()' + ((err) ? ` : ${err.message || err}` : '');
reject(errorMsg);
}
else {
resolve([]);
}
}
});
}
static getCurrentWindowAsync(queryOptions={}, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.getCurrent(queryOptions, (wnd) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getCurrentWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! wnd) {
if (useReject) {
reject('Failed getCurrentWindowAsync() : callback parameter (wnd) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(wnd);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getCurrentWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static getLastFocusedWindowAsync(queryOptions={}, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.getLastFocused(queryOptions, (wnd) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getLastFocusedWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! wnd) {
if (useReject) {
reject('Failed getLastFocusedWindowAsync() : callback parameter (wnd) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(wnd);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getLastFocusedWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static createWindowAsync(createData, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.create(createData, (wnd) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed createWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! wnd) {
if (useReject) {
reject('Failed createWindowAsync() : callback parameter (wnd) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(wnd);
}
});
}
catch (err) {
if (useReject) {
reject('Failed createWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static updateWindowAsync(windowId, updateInfo, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.update(windowId, updateInfo, (wnd) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed updateWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! wnd) {
if (useReject) {
reject('Failed updateWindowAsync() : callback parameter (wnd) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(wnd);
}
});
}
catch (err) {
if (useReject) {
reject('Failed updateWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static removeWindowAsync(windowId, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.windows.remove(windowId, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed removeWindowAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
}
catch (err) {
if (useReject) {
reject('Failed removeWindowAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(false);
}
}
});
}
static getTabAsync(tabId, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.get(tabId, (tab) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tab) {
if (useReject) {
reject('Failed getTabAsync() : callback parameter (tab) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(tab);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getTabAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static getCurrentTabAsync(useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.getCurrent((tab) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getCurrentTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tab) {
if (useReject) {
reject('Failed getCurrentTabAsync() : callback parameter (tab) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(tab);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getCurrentTabAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static createTabAsync(createProperties, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.create(createProperties, (tab) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed createTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tab) {
if (useReject) {
reject('Failed createTabAsync() : callback parameter (tab) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(tab);
}
});
}
catch (err) {
if (useReject) {
const errorMsg = 'Failed createTabAsync()' + ((err) ? ` : ${err.message || err}` : '');
reject(errorMsg);
}
else {
resolve(null);
}
}
});
}
static queryTabAsync(queryInfo, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.query(queryInfo, (tabs) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed queryTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve([]);
}
}
else if (! tabs) {
if (useReject) {
reject('Failed queryTabAsync() : callback parameter (tabs) is empty.');
}
else {
resolve([]);
}
}
else {
resolve(tabs);
}
});
}
catch (err) {
if (useReject) {
const errorMsg = 'Failed queryTabAsync()' + ((err) ? ` : ${err.message || err}` : '');
reject(errorMsg);
}
else {
resolve([]);
}
}
});
}
static updateTabAsync(tabId, updateProperties, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.get(tabId, (tab) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed updateTabAsync() - get : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tab) {
if (useReject) {
reject('Failed updateTabAsync() - get : callback parameter (tab) is empty.');
}
else {
resolve(null);
}
}
else {
try {
chrome.tabs.update(tabId, updateProperties, (tab) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed updateTabAsync() - update : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tab) {
if (useReject) {
reject('Failed updateTabAsync() - update : callback parameter (tab) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(tab);
}
});
}
catch (err) {
if (useReject) {
reject('Failed updateTabAsync() - update' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
}
});
}
catch (err) {
if (useReject) {
reject('Failed updateTabAsync() - get' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static moveTabAsync(tabIds, moveProperties, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.move(tabIds, moveProperties, (tabs) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed moveTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(null);
}
}
else if (! tabs) {
if (useReject) {
reject('Failed moveTabAsync() : callback parameter (tabs) is empty.');
}
else {
resolve(null);
}
}
else {
resolve(tabs);
}
});
}
catch (err) {
if (useReject) {
reject('Failed moveTabAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(null);
}
}
});
}
static removeTabAsync(tabIds, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.remove(tabIds, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed removeTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
}
catch (err) {
if (useReject) {
reject('Failed removeTabAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(false);
}
}
});
}
static goBackTabAsync(tabId, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.tabs.goBack(tabId, () => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed goBackTabAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve(false);
}
}
else {
resolve(true);
}
});
}
catch (err) {
if (useReject) {
reject('Failed goBackTabAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve(false);
}
}
});
}
static getClientScreenInfoAsync(isPrimaryOnly, useReject=false) {
return new Promise((resolve, reject) => {
try {
chrome.system.display.getInfo((displayInfo) => {
if (chrome.runtime.lastError) {
if (useReject) {
reject(`Failed getClientScreenInfoAsync() : ${chrome.runtime.lastError.message}`);
}
else {
resolve([]);
}
}
else if (! displayInfo) {
if (useReject) {
reject('Failed getClientScreenInfoAsync() : callback parameter (displayInfo) is empty.');
}
else {
resolve([]);
}
}
else {
let results = [];
displayInfo.forEach((info) => {
if ((info.isEnabled) && (! isPrimaryOnly) || (info.isPrimary)) {
let displayId = info.id;
if (! displayId) {
displayId = `wbTemp-${results.length + 1}`;
}
results.push(new ClientScreenInfo(displayId, info.isPrimary, info.bounds, info.workArea));
}
});
results.sort((a, b) => {
if (a.isPrimary !== b.isPrimary) {
return (a.isPrimary) ? -1 : 1;
}
if (a.screenLeft !== b.screenLeft) {
return (a.screenLeft < b.screenLeft) ? -1 : 1;
}
if (a.screenTop !== b.screenTop) {
return (a.screenTop < b.screenTop) ? -1 : 1;
}
return 0;
});
resolve(results);
}
});
}
catch (err) {
if (useReject) {
reject('Failed getClientScreenInfoAsync()' + ((err) ? ` : ${err.message || err}` : ''));
}
else {
resolve([]);
}
}
});
}
}
