'use strict';
const JSFILEVER_clientCoreWebUsageViz = '3.2.1.1001';
import './library/firebase-app.js';
import './library/firebase-functions.js';
export class ClientCoreWebUsageViz {
static getJsFileVersion() {
return (typeof JSFILEVER_clientCoreWebUsageViz === 'string') ? JSFILEVER_clientCoreWebUsageViz : 'Undefined';
}
constructor(cData, cAux, timer) {
this._cData = cData;
this._cAux = cAux;
this._timer = timer;
this._isUploadWebUsage = false;
this._runWebUsageUploadTimerId = TIMER_ID_NONE;
this._putLog = this._putLog.bind(this);
this._runWebUsageUploadTask = this._runWebUsageUploadTask.bind(this);
this._uploadWebUsageAsync = this._uploadWebUsageAsync.bind(this);
this.startWebUsageUploadTask = this.startWebUsageUploadTask.bind(this);
this.stopWebUsageUploadTask = this.stopWebUsageUploadTask.bind(this);
}
_putLog(message, level=LogLevels.DEBUG) {
LogManager.putLog(`【clientCore】${message}`, level);
}
_runWebUsageUploadTask() {
try {
if (! this._isUploadWebUsage)  return;
this._runWebUsageUploadTimerId = TIMER_ID_NONE;
const clientUsageList = []
let isSucceedUpload = false;
let isDataPending = false;
let sigConfigDbName;
let localPcGlobalIp;
ApiWrappers.readSessionStorageDataAsync({
SigConfigDbName: null,
LocalPcGlobalIp: null,
ServerBaseRealTime: 0,
ServerBaseSetTime: 0,
}, true)
.then((storage) => {
sigConfigDbName = storage.SigConfigDbName;
localPcGlobalIp = storage.LocalPcGlobalIp;
if ((! sigConfigDbName) || (! storage?.ServerBaseSetTime)) {
throw new Error('シグナリング設定DB名またはサーバ時刻が未取得');
}
const calculatedRealTime = (Date.now() - storage.ServerBaseSetTime) + storage.ServerBaseRealTime;
return AccessUrlInfoBuffer.readUrlInfoAsync(150, (calculatedRealTime - 180000));
})
.then((result) => {
if ((result.infos.length > 0) && (localPcGlobalIp === null)) {
Utils.postBroadcastMessage(BcNames.OFFSCREEN, { cmd: 'ScheduleCheckGipServerTime', delay: 30000 });
}
isDataPending = (result.undeletedCount > 150);
for (let info of result.infos) {
if ((clientUsageList.length >= 100) || (! info.globalIp)) {
isDataPending = true;
break;
}
if (info.blocked !== true) {
clientUsageList.push({
time: info.time,
global_ip: info.globalIp,
title: info.title,
url: info.url,
});
}
}
if (clientUsageList.length) {
return this._uploadWebUsageAsync(sigConfigDbName, this._cData.signedUserEmail, clientUsageList);
}
return true;
})
.then((succeed) => {
isSucceedUpload = succeed;
if ((isSucceedUpload) && (clientUsageList.length)) {
return AccessUrlInfoBuffer.deleteUrlInfoAsync(clientUsageList.length);
}
})
.then(() => {
if (this._isUploadWebUsage) {
const nextInterval = ((!!isDataPending) || (!isSucceedUpload)) ? 29950 : 599950;
this._runWebUsageUploadTimerId = this._timer.addTimer(nextInterval, false, this._runWebUsageUploadTask);
}
})
.catch((err) => {
const errorMsg = 'ERROR - _runWebUsageUploadTask()' + ((err) ? ` : ${err.message || err}` : '');
this._putLog(errorMsg, LogLevels.INFO);
});
}
catch (err) {
this._putLog(`ERROR - _runWebUsageUploadTask() : ${err.message || err || ''}`, LogLevels.FATAL);
}
}
_uploadWebUsageAsync(dbName, email, usageList=[]) {
return new Promise((resolve) => {
Utils.assert((Array.isArray(usageList) && (usageList.length <= 100)), 'Implementation Error. -- AccessUrlInfoBuffer._uploadWebUsageAsync()');
let workFirebaseApp = null;
return Promise.resolve()
.then(() => {
if (this._cAux.getDebugTestMode('C') & 0x20) {
this._putLog(`URL情報アップロード(SKIP)  情報数=${usageList.length}件  DB=${dbName}  email=${email}`, LogLevels.INFO);
for (let i = 0; i < usageList.length; i++) {
const info = usageList[i];
this._putLog(`  [${i}]  ${Utils.getJstDateTimeStr(true, new Date(info.time)).slice(0, 19)} : [${info.global_ip}] ${Utils.truncateStr(info.url, 200, true)} `, LogLevels.INFO);
}
return { data: { status: true }};
}
try {
workFirebaseApp = firebase.apps.find((v) => (v.name === 'webUsageViz') && (! v.checkDestroyed_()));
if (! workFirebaseApp) {
workFirebaseApp = firebase.initializeApp(ExtraConstants.WebUsageViz_FirebaseConfig, 'webUsageViz');
}
if (! workFirebaseApp) {
throw new Error('Firebase app 取得失敗.');
}
}
catch (err) {
throw new Error(err?.message || '原因不明');
}
const tempFunction = workFirebaseApp.functions('asia-northeast2');
const addClientWebUsageFunc = tempFunction.httpsCallable('addClientWebUsage');
const params = {
funcNo: 0,
data_set: dbName,
email: email,
usage_list: usageList,
};
if ((this._cData.isDeveloperMode === true) || (this._cData.debugTraceLevel === TraceLevels.DEBUG)) {
let tempParams = {
funcNo: params.funcNo,
data_set: params.data_set,
email: params.email,
usage_list_length: params.usage_list.length,
}
this._putLog(`****  (addClientWebUsage) クライアントが表示したURL情報をアップロードします.  ${JSON.stringify(tempParams)}`, LogLevels.INFO);
}
return addClientWebUsageFunc(params);
})
.then((result) => {
if (result?.data?.status !== true) {
throw new Error(result?.data?.error || '');
}
this._putLog(`クライアントが表示したURL情報(${usageList.length}件)をアップロードしました.`, LogLevels.INFO);
resolve(true);
})
.catch((err) => {
this._putLog('クライアントが表示したURL情報のアップロードに失敗しました.' + ((err) ? `  理由: ${err.message || err}` : ''), LogLevels.INFO);
resolve(false);
});
});
}
startWebUsageUploadTask() {
try {
if (! this._isUploadWebUsage) {
this._isUploadWebUsage = true;
this._runWebUsageUploadTimerId = this._timer.addTimer(29950, false, this._runWebUsageUploadTask);
}
}
catch (err) {
this._putLog(`ERROR - startWebUsageUploadTask() : ${err.message || err || ''}`, LogLevels.INFO);
}
}
stopWebUsageUploadTask() {
try {
if (this._isUploadWebUsage) {
this._isUploadWebUsage = false;
if (this._runWebUsageUploadTimerId !== TIMER_ID_NONE) {
this._timer.removeTimer(this._runWebUsageUploadTimerId);
this._runWebUsageUploadTimerId = TIMER_ID_NONE;
}
return true;
}
}
catch (err) {
this._putLog(`ERROR - stopWebUsageUploadTask() : ${err.message || err || ''}`, LogLevels.INFO);
}
return false;
}
}
