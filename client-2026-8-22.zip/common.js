"use strict";
const JSFILEVER_common = '3.2.1.1001';
const COMM_PROTOCOL_VERSION = '1.11';
const WINDOW_ID_NONE = -1;
const TAB_ID_NONE = -1;
const TIMER_ID_NONE = -1;
const Constants = Object.freeze({
MAX_WATCH_AVAILABLE_TIME_INTERVAL: 60000,
MAX_SHOW_CBT_OPENING_MESSAGE: 15000,
WATCH_SIGNALING_CTRL_INTERVAL: 10000,
NIGHT_LIMIT_POLICY_APPLIED_BASIS_HOURS: 18,
MAX_RETRY_WHEN_INITIALIZE_SIGLIB_FAILED: 10,
MAX_RETRY_WHEN_SIGNALING_FAILED: 2,
CHECK_EXIST_FIREBASE_MY_NODE_DELAY: 8000,
TIMEOUT_SIGNALING: 80000,
TIMEOUT_EMIT_TO_JOIN_LOBBY: 120000,
TIMEOUT_CAPTURE_ACTIVE_TAB: 3000,
FRAME_RATE_WHEN_ACTIVE_TAB: 4,
MAX_ICE_COUNT_IN_CANDIDATE_MESSAGE: 50,
FIREBASE_RECONNECT_INTERVAL: 5000,
TIMEOUT_FIREBASE_JUNSHI_REQUEST: 11 * 60000,
MAX_COLLABMATE_CLIENT_ID: 999999,
});
const ExtraConstants = Object.freeze({
INTERNAL_SCHEME_URL: 'chrome://',
NEW_TAB_PAGE_URL: 'chrome://newtab',
MARKER_EXTENSION_ID: 'ajhcdhigekedagafngphjkdbcmfbfhbm',
JS6_REBOOTING_CLIENT_URL: 'https://storage.googleapis.com/jsc-wb-download/js6RebootingClient01.html',
COLLABMATE_URL_1: 'https://collabm24.web.app/',
WEBUSAGEVIZ_FUNC_HOST_URL: 'https://asia-northeast2-jsc23-7b296.cloudfunctions.net/',
WebUsageViz_FirebaseConfig: Object.freeze({
apiKey: "AIzaSyAGivqgwpT1rjxxHHo7QkTvl6VCeP1-Dao",
authDomain: "jsc23-7b296.firebaseapp.com",
projectId: "jsc23-7b296",
}),
Policy_FirebaseConfig: Object.freeze({
apiKey: "AIzaSyA9sopyLQvgShmdx2u5NTb0hJWKy7Zw9ec",
authDomain: "jscpolicy.firebaseapp.com",
projectId: "jscpolicy",
}),
GamenImage_FirebaseConfig: Object.freeze({
apiKey: "AIzaSyCNPCjvfTqsmooR8idB79D6yQOeV7BKGVo",
authDomain: "jsctrl.firebaseapp.com",
projectId: "jsctrl",
}),
LogStorage_FirebaseConfig: Object.freeze({
apiKey: "AIzaSyBxR2EjCfaQnRpMGr4kiGiDwDOuljQACQ4",
authDomain: "jslogStorage.firebaseapp.com",
projectId: "jslogStorage",
}),
CollabMate_FirebaseConfig: Object.freeze({
apiKey: "AIzaSyAHXfGYN4pPOh8RznHluW2gVADTRL_E1hI",
authDomain: "collabm24.firebaseapp.com",
projectId: "collabm24",
}),
});
const LogLevels = Object.freeze({
FATAL: 1,
INFO: 2,
DEBUG: 4,
});
const TraceLevels = Object.freeze({
UNSET: 0,
INFO: 1,
DEBUG: 2,
});
const PageHtmlNames = Object.freeze({
OPTIONS: 'options.html',
CLIENT_CORE: 'clientCore.html',
ATTENTION: 'attention.html',
CLASSWORK: 'classwork.html',
BLOCKED: 'blockedPage.html',
BROWSER_SEIGEN: 'browserSeigenPage.html',
MESSENGER: 'messenger.html',
CLIENT_KICKER: 'clientKicker.html',
CLIENT_PHANTOM: 'phantom.html',
TEMPORARY: 'tempPage.html',
MARKER: 'markerPage.html',
});
const OsTypes = Object.freeze({
UNKNOWN: 0,
CHROME: 1,
WINDOWS: 2,
});
const PeerStates = Object.freeze({
INITIAL: 0,
DISCONNECTED: 1,
PARTICIPATION_PROCEDURE: 2,
SIGNALING_STARTED: 3,
SIGNALING: 4,
SIGNALING_FAILED: 5,
CONNECTED: 6,
ENTRUST_FIREBASE: 7,
});
const BcNames = Object.freeze({
SERVICE_WORKER: 'Worker',
CLIENT_CORE: 'ClientCore',
MESSENGER_PAGE: 'Messenger',
POPUP_PAGE: 'Popup',
OFFSCREEN: 'OffScreen',
});
const BrowserSeigens = Object.freeze({
NONE: 0,
CONTROLLER: 1,
CBTMODE: 2,
NIGHT: 4,
});
const MessengerKinds = Object.freeze({
UNKNOWN: 0,
CONTROLLER: 10,
CLIENT: 20,
CLIENT_PENDING: 21,
CLIENT_ERROR: 22,
});
const CollabMateCaptureStates = Object.freeze({
NONE: 0,
REQUESTED: 1,
ACCEPTED: 2,
});
