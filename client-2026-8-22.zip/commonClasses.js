'use strict';
const JSFILEVER_commonClasses = '3.2.1.1001';
class ClientScreenInfo {
constructor(displayId, isPrimary, screenBounds, workAreaBounds) {
this._displayId = displayId;
this._isPrimary = isPrimary;
this._screenLeft = screenBounds?.left;
this._screenTop = screenBounds?.top;
this._screenWidth = screenBounds?.width;
this._screenHeight = screenBounds?.height;
this._workAreaLeft = workAreaBounds?.left;
this._workAreaTop = workAreaBounds?.top;
this._workAreaWidth = workAreaBounds?.width;
this._workAreaHeight = workAreaBounds?.height;
}
get displayId() {
return this._displayId;
}
get isPrimary() {
return this._isPrimary;
}
get screenLeft() {
return this._screenLeft;
}
get screenTop() {
return this._screenTop;
}
get screenWidth() {
return this._screenWidth;
}
get screenHeight() {
return this._screenHeight;
}
get workAreaLeft() {
return this._workAreaLeft;
}
get workAreaTop() {
return this._workAreaTop;
}
get workAreaWidth() {
return this._workAreaWidth;
}
get workAreaHeight() {
return this._workAreaHeight;
}
get screenBounds() {
const bounds = {
left: this._screenLeft,
top: this._screenTop,
width: this._screenWidth,
height: this._screenHeight,
};
return bounds;
}
get workAreaBounds() {
const bounds = {
left: this._workAreaLeft,
top: this._workAreaTop,
width: this._workAreaWidth,
height: this._workAreaHeight,
};
return bounds;
}
}
class PunycodeDecoder {
static decode(domain) {
const fnFromCode = (str, start, end) => {
if (end <= start) {
return '';
}
let tempStr = unescape(str.substring(start, end));
let d = '';
let flag = 0;
let tmp;
for (let i = 0; i < tempStr.length; i++) {
let code = tempStr.charCodeAt(i);
if (flag == 0) {
if ((code & 0xe0) == 0xe0) {
flag = 2;
tmp = (code & 0x0f) << 12;
}
else if ((code & 0xc0) == 0xc0) {
flag = 1;
tmp = (code & 0x1f) << 6;
}
else if ((code & 0x80) == 0) {
d += tempStr.charAt(i);
}
else {
flag = 0;
}
}
else if (flag == 1) {
flag = 0;
d += String.fromCharCode(tmp | (code & 0x3f));
}
else if (flag == 2) {
flag = 3;
tmp |= (code & 0x3f) << 6;
}
else if (flag == 3) {
flag = 0;
d += String.fromCharCode(tmp | (code & 0x3f));
}
else {
flag = 0;
}
}
return d;
};
const fnDecodeDigit = (cp) => {
if (cp < 58) {
return cp - 22;
}
else if (cp < 91) {
return cp - 65;
}
else if (cp < 123) {
return cp - 97;
}
return 36;
};
const fnAdapt = (delta, numpoints, firsttime) => {
let k;
delta = firsttime ? parseInt(delta / 700) : delta >> 1;
delta += parseInt(delta / numpoints);
for (k = 0;  delta > ((36 - 1) * 26) >> 1;  k += 36) {
delta = parseInt(delta / (36 - 1));
}
return parseInt(k + (36 - 1 + 1) * delta / (delta + 38));
};
let decoded = '';
let text = domain;
let tempS = 0;
for (let i = 0; i < text.length; i++) {
if (text.charCodeAt(i) >= 0x80) {
decoded += fnFromCode(text, tempS, i);
decoded += text.charAt(i);
tempS = i + 1;
}
}
decoded += fnFromCode(text, tempS, text.length);
let resultStr = '';
let i = 0;
for (;;) {
let index;
for (index = i; index + 3 < decoded.length; index++) {
const c1 = decoded.charAt(index);
if (c1 == 'x' || c1 == 'X') {
const c2 = decoded.charAt(index + 1);
if ((c2 == 'n' || c2 == 'N') && decoded.substring(index + 2, index + 4) == '--') {
break;
}
}
}
if (index + 3 >= decoded.length) {
index = -1;
}
if (index >= 0) {
if (index > i) {
resultStr += decoded.substring(i, index);
}
i = index;
for (index += 4; index < decoded.length; index++) {
const code = decoded.charCodeAt(index);
if ((code != 0x2d && code < 0x30) || (code > 0x39 && code < 0x41) || (code > 0x5a && code < 0x61) || code > 0x7a) {
break;
}
}
let j = index - i - 4;
if (j > 0) {
try {
let str = decoded.substring(i + 4, i + 4 + j);
let input = [];
for(let j = 0; j < str.length; j++) {
input.push(str.charCodeAt(j));
}
let output = [];
let n = 0x80;
let bias = 72;
let bcp = 0;
for (let j = input.length; j >= 0; --j) {
if (input[j] == 0x2D) {
bcp = j;
break;
}
}
for (let j = 0;  j < bcp; ++j) {
if (input[j] >= 0x80) {
throw 'bad_input';
}
output.push( input[j] );
}
let wk1 = 0;
let inp = (bcp > 0) ? bcp + 1 : 0;
while (inp < input.length) {
let oldi = wk1;
for (let wk2 = 1, k = 36;  ; k += 36) {
if (inp >= input.length) {
throw 'Invalid Value';
}
let digit = fnDecodeDigit(input[inp++]);
if (digit >= 36) {
throw 'Invalid Value';
}
if (digit > (0x7fffffff - wk1) / wk2) {
throw 'OverFlow';
}
wk1 += digit * wk2;
let t = (k <= bias) ? 1 : (k >= bias + 26) ? 26 : k - bias;
if (digit < t) break;
if (wk2 > 0x7fffffff / (36 - t)) {
throw 'OverFlow';
}
wk2 *= (36 - t);
}
bias = fnAdapt(wk1 - oldi, output.length + 1, oldi == 0);
oldi = parseInt(wk1 / (output.length + 1));
if (oldi > 0x7fffffff - n) {
throw 'OverFlow';
}
n += oldi;
wk1 %= (output.length + 1);
output.splice(wk1++, 0, n);
}
for (let k = 0; k < output.length; k++) {
output[k] = String.fromCharCode(output[k]);
}
resultStr += output.join('');
}
catch (err) {
console.log('exception of punycode decode.');
}
i = index;
}
else {
resultStr += decoded.substring(i, i + 4);
i += 4;
}
}
else {
resultStr += decoded.substring(i, decoded.length);
break;
}
}
return resultStr;
}
}
class MessengerManager {
static _dbPromise = null;
static initializeAsync() {
return new Promise((resolve, reject) => {
MessengerManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Msg'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - initializeAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve();
const store = trans.objectStore('Msg');
const clearReq = store.clear();
clearReq.onsuccess = () => {
const now = new Date();
const mmdd = String(now.getMonth()+1).padStart(2, '0')+String(now.getDate()).padStart(2, '0');
const prefixId = `M${mmdd}${String(Math.trunc(Math.random() * 100000000)).padStart(8, '0')}`;
const msgStore = trans.objectStore('Msg');
let putReq = msgStore.put({seqNo: 0, id:'@', lastSeqNo: 0, prefix: prefixId});
putReq.onsuccess = () => {
console.log('Messenger data initialized.');
}
};
})
.catch((err) => {
reject(`ERROR - initializeAsync() ${err?.message || err || ''}`);
});
});
}
static readAsync(id=null, overSeqNo=1) {
return new Promise((resolve, reject) => {
if ((id !== null) && ((typeof id !== 'string') || (id.length === 0))) {
reject('ERROR - readAsync() Invalid id.');
return;
}
if ((id === null) && (typeof overSeqNo !== 'number')) {
reject('ERROR - readAsync() Invalid overSeqNo.');
return;
}
let resultValue = {};
MessengerManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Msg'], 'readonly');
trans.onerror = (ev) => reject(`ERROR - readAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const msgStore = trans.objectStore('Msg');
const getReq = msgStore.get(0);
getReq.onsuccess = (ev) => {
if ((! ev?.target?.result) || (ev?.target?.result?.id !== '@')) {
reject('ERROR - readAsync() Not initialized.');
return;
}
if (id === null) {
resultValue = [];
const cursorReq = msgStore.openCursor(IDBKeyRange.lowerBound(overSeqNo));
cursorReq.onsuccess = (ev) => {
const cursor = ev.target.result;
if (cursor) {
if (cursor.key !== 0) {
const tempData = Object.assign({}, cursor.value);
resultValue.push(tempData);
}
cursor.continue();
}
};
}
else {
const idIndex = msgStore.index('id');
const getReq = idIndex.get(id);
getReq.onsuccess = (ev) => {
if (ev?.target?.result?.id === id) {
const tempData = Object.assign({}, ev.target.result);
resultValue = tempData;
}
};
}
};
})
.catch((err) => {
reject(`ERROR - readAsync() ${err?.message || err || ''}`);
});
});
}
static writeAsync(id, data) {
return new Promise((resolve, reject) => {
if ((id !== null) && ((typeof id !== 'string') || (id.length === 0))) {
reject('ERROR - writeAsync() Invalid id.');
return;
}
let resultValue = null;
MessengerManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Msg'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - writeAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const msgStore = trans.objectStore('Msg');
const getReq = msgStore.get(0);
getReq.onsuccess = (ev) => {
if ((! ev?.target?.result) || (ev?.target?.result?.id !== '@')) {
reject('ERROR - writeAsync() Not initialized.');
return;
}
let lastSeqNo = ev.target.result.lastSeqNo;
let prefixId = ev.target.result.prefix;
if (id === null) {
lastSeqNo++;
const newId = `${prefixId}${String(Math.trunc(lastSeqNo % 100000000)).padStart(8, '0')}`;
let putReq1 = msgStore.put({seqNo: 0, id:'@', lastSeqNo: lastSeqNo, prefix: prefixId});
putReq1.onsuccess = () => {
let tempData = Object.assign({}, data);
tempData.id = newId;
tempData.seqNo = lastSeqNo;
let putReq2 = msgStore.put(tempData);
putReq2.onsuccess = () => {
resultValue = { seqNo: tempData.seqNo, id: tempData.id };
};
};
}
else {
const idIndex = msgStore.index('id');
const getReq = idIndex.get(id);
getReq.onsuccess = (ev) => {
if ((ev?.target?.result) && (typeof ev?.target?.result?.id === 'string')) {
let tempData = Object.assign({}, ev.target.result);
tempData = Object.assign(tempData, data);
tempData.id = id;
tempData.seqNo = ev.target.result.seqNo;
let putReq1 = msgStore.put(tempData);
putReq1.onsuccess = (ev) => {
resultValue = { seqNo: tempData.seqNo, id: tempData.id };
};
}
else {
lastSeqNo++;
const newId = `${prefixId}${String(Math.trunc(lastSeqNo % 100000000)).padStart(8, '0')}`;
let putReq1 = msgStore.put({seqNo: 0, id:'@', lastSeqNo: lastSeqNo, prefix: prefixId});
putReq1.onsuccess = () => {
let tempData = Object.assign({}, data);
tempData.id = id;
tempData.seqNo = lastSeqNo;
let putReq2 = msgStore.put(tempData);
putReq2.onsuccess = () => {
resultValue = { seqNo: tempData.seqNo, id: tempData.id };
};
};
}
};
getReq.onerror = (ev) => {
console.log(ev);
};
}
};
})
.catch((err) => {
reject(`ERROR - writeAsync() ${err?.message || err || ''}`);
});
});
}
static compareOverwriteAsync(id, data, comparandMsgKind) {
return new Promise((resolve, reject) => {
if (typeof comparandMsgKind !== 'number') {
reject('ERROR - compareOverwriteAsync() Invalid comparandMsgKind.');
return;
}
let resultValue = null;
MessengerManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Msg'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - compareOverwriteAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const msgStore = trans.objectStore('Msg');
const idIndex = msgStore.index('id');
const getReq = idIndex.get(id);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result === 'object') {
if (ev.target.result.msgKind === comparandMsgKind) {
let tempData = Object.assign({}, ev.target.result);
tempData = Object.assign(tempData, data);
tempData.id = ev.target.result.id;
tempData.seqNo = ev.target.result.seqNo;
let putReq = msgStore.put(tempData);
putReq.onsuccess = () => {
resultValue = { seqNo: tempData.seqNo, id: tempData.id };
};
}
}
};
})
.catch((err) => {
reject(`ERROR - compareOverwriteAsync() ${err?.message || err || ''}`);
});
});
}
static _openDbAsync() {
if (this._dbPromise) {
return this._dbPromise;
}
this._dbPromise = new Promise((resolve, reject) => {
try {
const openReq = self.indexedDB.open('Messenger', 1);
openReq.onerror = (ev) => {
this._dbPromise = null;
reject(`Failed open Messenger DB. ${ev?.target?.error?.message || ''}`);
};
openReq.onupgradeneeded = (ev) => {
const db = ev.target.result;
if (ev.oldVersion < 1) {
const store = db.createObjectStore('Msg', { keyPath: 'seqNo' });
store.createIndex('id', 'id', { unique: true });
}
};
openReq.onsuccess = (ev) => {
const db = ev.target.result;
db.onclose = () => {
this._dbPromise = null;
};
db.onversionchange = () => {
db.close();
this._dbPromise = null;
};
resolve(db);
};
}
catch (err) {
this._dbPromise = null;
reject(`Failed open Messenger DB. ${err?.message || err || ''}`);
}
});
return this._dbPromise;
}
}
class CountManager {
static _dbPromise = null;
static readAsync(name) {
return new Promise((resolve, reject) => {
let resultValue = 0;
CountManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Variable'], 'readonly');
trans.onerror = (ev) => reject(`ERROR - readAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const store = trans.objectStore('Variable');
if (name !== null) {
const getReq = store.get(name);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result?.value === 'number')  resultValue = ev.target.result.value;
};
}
else {
resultValue = {};
const cursorReq = store.openCursor();
cursorReq.onsuccess = (ev) => {
const cursor = ev.target.result;
if (cursor) {
resultValue[cursor.key] = cursor.value.value;
cursor.continue();
}
};
}
})
.catch((err) => {
reject(`ERROR - readAsync() ${err?.message || err || ''}`);
});
});
}
static incrementAsync(name) {
return new Promise((resolve, reject) => {
let resultValue = 0;
CountManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Variable'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - incrementAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const store = trans.objectStore('Variable');
const getReq = store.get(name);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result?.value === 'number')  resultValue = ev.target.result.value;
resultValue++;
store.put({ id: name, value: resultValue });
};
})
.catch((err) => {
reject(`ERROR - incrementAsync() ${err?.message || err || ''}`);
});
});
}
static exchangeAsync(name, value) {
return new Promise((resolve, reject) => {
let resultValue = null;
CountManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Variable'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - exchangeAsync() ${ev.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const store = trans.objectStore('Variable');
const getReq = store.get(name);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result?.value === 'number') {
resultValue = ev.target.result.value;
}
store.put({ id: name, value: value });
};
})
.catch((err) => {
reject(`ERROR - exchangeAsync() ${err?.message || err || ''}`);
});
});
}
static compareExchangeAsync(name, value, comparand) {
return new Promise((resolve, reject) => {
let resultValue = 0;
CountManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Variable'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - compareExchangeAsync() ${ev.target?.error?.message || ''}`);
trans.oncomplete = () => resolve(resultValue);
const store = trans.objectStore('Variable');
const getReq = store.get(name);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result?.value === 'number') {
resultValue = ev.target.result.value;
if (resultValue === comparand) {
store.put({ id: name, value: value });
}
}
else {
store.put({ id: name, value: value });
}
};
})
.catch((err) => {
reject(`ERROR - compareExchangeAsync() ${err?.message || err || ''}`);
});
});
}
static deleteAsync(name) {
return new Promise((resolve, reject) => {
if (typeof name !== 'string')  name = '';
if ((name.length === 0) || (name.indexOf(' ') !== -1)) {
reject('ERROR - deleteAsync() Invalid name.');
return;
}
CountManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Variable'], 'readwrite');
trans.onerror = (ev) => reject(`ERROR - deleteAsync() ${ev?.target?.error?.message || ''}`);
trans.oncomplete = () => resolve();
const store = trans.objectStore('Variable');
if (name.endsWith('*')) {
const filter = name.slice(0, -1);
if (filter.length > 0) {
const cursorReq = store.openCursor();
cursorReq.onsuccess = (ev) => {
const cursor = ev.target.result;
if (cursor) {
if (cursor.key.startsWith(filter)) {
store.delete(cursor.key);
}
cursor.continue();
}
};
}
else {
store.clear();
}
}
else {
const getReq = store.get(name);
getReq.onsuccess = (ev) => {
if (typeof ev?.target?.result?.value !== 'undefined') {
store.delete(name);
}
};
}
})
.catch((err) => {
reject(`ERROR - deleteAsync() ${err?.message || err || ''}`);
});
});
}
static _openDbAsync() {
if (this._dbPromise) {
return this._dbPromise;
}
this._dbPromise = new Promise((resolve, reject) => {
try {
const openReq = self.indexedDB.open('Data', 1);
openReq.onerror = (ev) => {
this._dbPromise = null;
reject(`Failed open Data DB. ${ev?.target?.error?.message || ''}`);
};
openReq.onupgradeneeded = (ev) => {
const db = ev.target.result;
if (ev.oldVersion < 1) {
db.createObjectStore('Variable', { keyPath: 'id' });
}
};
openReq.onsuccess = (ev) => {
const db = ev.target.result;
db.onclose = () => {
this._dbPromise = null;
};
db.onversionchange = () => {
db.close();
this._dbPromise = null;
};
resolve(db);
};
}
catch (err) {
this._dbPromise = null;
reject(`Failed open Data DB. ${err?.message || err || ''}`);
}
});
return this._dbPromise;
}
}
class LogManager {
static get MAX_INFO_LOG_COUNT() { return 1000; };
static get MAX_FATAL_LOG_COUNT() { return 50; };
static _dbPromise = null;
static putLog(message, level=LogLevels.DEBUG, autoCutLength=0) {
LogManager.putLogAsync(message, level, autoCutLength).then(() => {});
}
static putLogAsync(message, level=LogLevels.DEBUG, autoCutLength=0) {
const timeOfPut = new Date();
const cuttedMsg = (autoCutLength > 0) ? Utils.truncateStr(message, autoCutLength) : message;
console.log(cuttedMsg);
if (level === LogLevels.DEBUG) {
return Promise.resolve(true);
}
return new Promise((resolve) => {
LogManager._openDbAsync()
.then((db) => {
const trans = db.transaction(['Fatal', 'Info'], 'readwrite');
trans.onerror = (ev) => {
console.log(`ERROR - putLogAsync() : Failed to put log. ${ev?.target?.error?.message || ''}`);
resolve(false);
};
trans.oncomplete = () => resolve(true);
const infoStore = trans.objectStore('Info');
let getReq = infoStore.get(0);
getReq.onsuccess = (ev) => {
let infoMsgId = 1;
if ((ev.target.result) && (typeof ev.target.result.lastMsgId === 'number')) {
infoMsgId = (ev.target.result.lastMsgId % LogManager.MAX_INFO_LOG_COUNT) + 1;
}
let putReq = infoStore.put({id: 0, lastMsgId: infoMsgId});
putReq.onsuccess = () => {
infoStore.put({ id: infoMsgId, time: timeOfPut.getTime(), msg: cuttedMsg });
if (level === LogLevels.FATAL) {
const fatalStore = trans.objectStore('Fatal');
getReq = fatalStore.get(0);
getReq.onsuccess = (ev) => {
let fatalMsgId = 1;
if ((ev.target.result) && (typeof ev.target.result.lastMsgId === 'number')) {
fatalMsgId = (ev.target.result.lastMsgId % LogManager.MAX_FATAL_LOG_COUNT) + 1;
}
putReq = fatalStore.put({id: 0, lastMsgId: fatalMsgId});
putReq.onsuccess = () => {
const msg = cuttedMsg.replace(/^【.*】/g, '');
fatalStore.put({ id: fatalMsgId, time: timeOfPut.getTime(), msg: msg });
};
};
}
};
};
})
.catch((err) => {
console.log(`ERROR - putLogAsync() ${err?.message || err || ''}`);
resolve(false);
});
});
}
static getAllLogAsync(isFatalOnly=true) {
const fnLogRecordToLogArray = (rows) => {
const sortedLogs = [];
const lastMsgId = rows[0].lastMsgId;
let separateIndex = rows.findIndex(item => item.id === lastMsgId);
if (separateIndex < 1)  separateIndex = rows.length - 1;
for (let i = separateIndex; i > 0; i--) {
sortedLogs.push(`${Utils.getJstDateTimeStr(true, new Date(rows[i].time)).slice(5)}  ${rows[i].msg}`);
}
for (let i = rows.length - 1; i > separateIndex; i--) {
sortedLogs.push(`${Utils.getJstDateTimeStr(true, new Date(rows[i].time)).slice(5)}  ${rows[i].msg}`);
}
return sortedLogs;
};
return new Promise((resolve) => {
LogManager._openDbAsync()
.then((db) => {
let fatalLogs = null;
let infoLogs = null;
const trans = db.transaction(['Fatal', 'Info'], 'readonly');
trans.onerror = (ev) => {
console.log(`ERROR - getAllLogAsync() : Failed to get log. ${ev?.target?.error?.message || ''}`);
resolve({});
};
trans.oncomplete = () => {
const resultObj = {};
if (fatalLogs) {
resultObj.fatalLogs = fatalLogs;
}
if (infoLogs) {
resultObj.infoLogs = infoLogs;
}
resolve(resultObj);
};
const fatalStore = trans.objectStore('Fatal');
let getReq = fatalStore.getAll(IDBKeyRange.bound(0, LogManager.MAX_FATAL_LOG_COUNT));
getReq.onsuccess = (ev) => {
const rows = ev.target.result;
if ((rows.length > 1) && (rows[0].id === 0)) {
fatalLogs = fnLogRecordToLogArray(rows);
}
if (! isFatalOnly) {
const infoStore = trans.objectStore('Info');
getReq = infoStore.getAll(IDBKeyRange.bound(0, LogManager.MAX_INFO_LOG_COUNT));
getReq.onsuccess = (ev) => {
const rows = ev.target.result;
if ((rows.length > 1) && (rows[0].id === 0)) {
infoLogs = fnLogRecordToLogArray(rows);
}
};
}
};
})
.catch((err) => {
console.log(`ERROR - getAllLogAsync() ${err?.message || err || ''}`);
resolve({});
});
});
}
static _openDbAsync() {
if (this._dbPromise) {
return this._dbPromise;
}
this._dbPromise = new Promise((resolve, reject) => {
try {
const openReq = self.indexedDB.open('Log', 1);
openReq.onerror = (ev) => {
this._dbPromise = null;
reject(`Failed open Log DB. ${ev?.target?.error?.message || ''}`);
};
openReq.onupgradeneeded = (ev) => {
const db = ev.target.result;
if (ev.oldVersion < 1) {
db.createObjectStore('Fatal', { keyPath: 'id' });
db.createObjectStore('Info', { keyPath: 'id' });
}
};
openReq.onsuccess = (ev) => {
const db = ev.target.result;
db.onclose = () => {
this._dbPromise = null;
};
db.onversionchange = () => {
db.close();
this._dbPromise = null;
};
resolve(db);
};
}
catch (err) {
this._dbPromise = null;
reject(`Failed open Log DB. ${err?.message || err || ''}`);
}
});
return this._dbPromise;
}
}
class AccessUrlInfoBuffer {
static get MAX_URL_INFO_COUNT() { return 1000; };
static _dbPromise = null;
static writeUrlInfoAsync(tabId, time, title, url, globalIp=null) {
return new Promise((resolve) => {
if ((typeof tabId !== 'number') ||
(typeof time !== 'number') ||
(typeof title !== 'string') ||
(typeof url !== 'string') ||
((globalIp != null) && (typeof globalIp !== 'string'))) {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - writeUrlInfoAsync() : Invalid infoObj.  tabId=${tabId}  time=${time}  title="${title}"  url="${url}"`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO, 500).then(() => {});
resolve(false);
return;
}
AccessUrlInfoBuffer._sha256Async(`${tabId}@${url}`)
.then((accessHash) => {
AccessUrlInfoBuffer._openDbAsync()
.then((db) => {
let isSucceed = false;
const trans = db.transaction(['buf'], 'readwrite');
trans.onerror = (ev) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - writeUrlInfoAsync() : Failed to write info. ${ev?.target?.error?.message || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
};
trans.onabort = () => resolve(false);
trans.oncomplete = () => resolve(isSucceed);
const bufStore = trans.objectStore('buf');
let getReq = bufStore.get(0);
getReq.onsuccess = (ev) => {
let infoCount = 1;
let infoId = 1;
if (ev.target.result) {
if ((typeof ev.target.result.infoCount !== 'number') ||
(typeof ev.target.result.lastInfoId !== 'number')) {
const errorMsg = '≪AccessUrlInfoBuffer≫ writeUrlInfoAsync() : Broken indexDB.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
return trans.abort();
}
if (ev.target.result.infoCount >= AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) {
const errorMsg = '≪AccessUrlInfoBuffer≫ writeUrlInfoAsync() : Overflow access url info buffer.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
return trans.abort();
}
infoCount = Math.min((ev.target.result.infoCount + 1), AccessUrlInfoBuffer.MAX_URL_INFO_COUNT);
infoId = (ev.target.result.lastInfoId % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
}
const dataRecord = {
id: infoId,
tabId: tabId,
time: time,
globalIp: globalIp || '',
title: title,
url: AccessUrlInfoBuffer._xor(url, infoId),
accessHash: accessHash,
blocked: false,
};
let putReq = bufStore.put({id: 0, infoCount: infoCount, lastInfoId: infoId});
putReq.onsuccess = () => {
bufStore.put(dataRecord);
isSucceed = true;
};
};
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - writeUrlInfoAsync() (DB) : ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - writeUrlInfoAsync() (Hash) : ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
});
}
static readUrlInfoAsync(maxCount, maxTime=-1) {
const fnReadRecord = (store, top, end, isAscending, onComplete) => {
const resultInfos = [];
const range = IDBKeyRange.bound(top, end);
const cursorReq = store.openCursor(range, (isAscending ? 'next' : 'prev'));
cursorReq.onsuccess = (event) => {
const cursor = event.target.result;
if (cursor) {
const data = cursor.value;
if ((! isAscending) || (maxTime === -1) || (data.time <= maxTime)) {
resultInfos.push({
tabId: data.tabId,
time: data.time,
globalIp: data.globalIp || '',
title: data.title || '',
url: AccessUrlInfoBuffer._xor(data.url, data.id),
blocked: data.blocked,
});
cursor.continue();
}
else {
onComplete(resultInfos);
}
}
else {
onComplete(resultInfos);
}
};
};
return new Promise((resolve) => {
if (maxCount !== Math.trunc(maxCount)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ ERROR - readUrlInfoAsync() Invalid parameter.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve([]);
return;
}
AccessUrlInfoBuffer._openDbAsync()
.then((db) => {
const resultObj = { infos: [], undeletedCount: -1 };
const trans = db.transaction(['buf'], 'readonly');
trans.onerror = (ev) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - readUrlInfoAsync() : Failed to read info. ${ev?.target?.error?.message || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(resultObj);
};
trans.onabort = () => resolve(resultObj);
trans.oncomplete = () => resolve(resultObj);
const bufStore = trans.objectStore('buf');
let getReq = bufStore.get(0);
getReq.onsuccess = (ev) => {
if (ev.target.result) {
if ((typeof ev.target.result.infoCount !== 'number') ||
(typeof ev.target.result.lastInfoId !== 'number') ||
(ev.target.result.infoCount > AccessUrlInfoBuffer.MAX_URL_INFO_COUNT)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ readUrlInfoAsync() : Broken indexDB.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
return trans.abort();
}
if (maxCount > 0) {
const infoCount = ev.target.result.infoCount;
const readCount = Math.min(maxCount, infoCount);
if (readCount > 0) {
const top = ((ev.target.result.lastInfoId + AccessUrlInfoBuffer.MAX_URL_INFO_COUNT - infoCount) % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
const last = (((top - 1) + (readCount - 1)) % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
resultObj.undeletedCount = infoCount;
if (top > last) {
fnReadRecord(bufStore, top, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT, true, (buf1) => {
fnReadRecord(bufStore, 1, last, true, (buf2) => {
resultObj.infos = [ ...buf1, ...buf2 ];
});
});
} else {
fnReadRecord(bufStore, top, last, true, (buf1) => {
resultObj.infos = buf1;
});
}
}
}
else if (maxCount < 0) {
const infoCount = ev.target.result.infoCount;
const readCount = Math.min(Math.abs(maxCount), AccessUrlInfoBuffer.MAX_URL_INFO_COUNT);
if (readCount > 0) {
const last = ev.target.result.lastInfoId;
const top = (((last - 1) - (readCount - 1) + AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
resultObj.undeletedCount = infoCount;
if (top > last) {
fnReadRecord(bufStore, 1, last, false, (buf1) => {
fnReadRecord(bufStore, top, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT, false, (buf2) => {
resultObj.infos = [ ...buf1,  ...buf2 ];
});
});
}
else {
fnReadRecord(bufStore, top, last, false, (buf1) => {
resultObj.infos = buf1;
});
}
}
}
}
};
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - readUrlInfoAsync() : ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve({ infos: [], undeletedCount: -1 });
});
});
}
static deleteUrlInfoAsync(count) {
return new Promise((resolve) => {
if (count !== Math.trunc(count)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ ERROR - deleteUrlInfoAsync() Invalid parameter.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve([]);
return;
}
AccessUrlInfoBuffer._openDbAsync()
.then((db) => {
const trans = db.transaction(['buf'], 'readwrite');
trans.onerror = (ev) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - deleteUrlInfoAsync() : Failed to delete info. ${ev?.target?.error?.message || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
};
trans.onabort = () => resolve(false);
trans.oncomplete = () => resolve(true);
const bufStore = trans.objectStore('buf');
if (count === 0) {
const range = IDBKeyRange.bound(0, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT);
bufStore.delete(range);
}
else {
let getReq = bufStore.get(0);
getReq.onsuccess = (ev) => {
if (ev.target.result) {
try {
if ((typeof ev.target?.result?.infoCount === 'number') &&
(typeof ev.target?.result?.lastInfoId === 'number') &&
(ev.target.result.infoCount > 0)) {
count = Math.min(count, ev.target.result.infoCount);
let infoCount = ev.target.result.infoCount - count;
let lastInfoId = ev.target.result.lastInfoId;
bufStore.put({id: 0, infoCount: infoCount, lastInfoId: lastInfoId});
}
}
catch (err) {}
}
};
}
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - deleteUrlInfoAsync() ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
});
}
static updateEmptyGlobalIpAsync(globalIp) {
const fnUpdateRecord = (store, top, end, onComplete) => {
const range = IDBKeyRange.bound(top, end);
const cursorReq = store.openCursor(range, 'prev');
cursorReq.onsuccess = (event) => {
const cursor = event.target.result;
if (cursor) {
try {
const data = cursor.value;
if (! data.globalIp?.length) {
data.globalIp = globalIp;
cursor.update(data);
}
cursor.continue();
}
catch (err) {
const errorMsg = '≪AccessUrlInfoBuffer≫ ERROR - updateEmptyGlobalIpAsync() - fnUpdateRecord()' + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
onComplete(false);
}
}
else {
onComplete(true);
}
};
};
return new Promise((resolve) => {
if ((typeof globalIp !== 'string') || (globalIp.length === 0)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ ERROR - updateEmptyGlobalIpAsync() Invalid parameter.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
return;
}
AccessUrlInfoBuffer._openDbAsync()
.then((db) => {
const trans = db.transaction(['buf'], 'readwrite');
trans.onerror = (ev) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - updateEmptyGlobalIpAsync() : Failed to update info. ${ev?.target?.error?.message || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
};
trans.onabort = () => resolve(false);
trans.oncomplete = () => resolve(true);
const bufStore = trans.objectStore('buf');
let getReq = bufStore.get(0);
getReq.onsuccess = (ev) => {
if (ev.target.result) {
if ((typeof ev.target.result.infoCount !== 'number') ||
(typeof ev.target.result.lastInfoId !== 'number') ||
(ev.target.result.infoCount > AccessUrlInfoBuffer.MAX_URL_INFO_COUNT)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ updateEmptyGlobalIpAsync() : Broken indexDB.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
return trans.abort();
}
let infoCount = Math.min(ev.target.result.infoCount, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT);
if (infoCount > 0) {
let last = ev.target.result.lastInfoId;
let top = (((last - 1) - (infoCount - 1) + AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
if (top > last) {
fnUpdateRecord(bufStore, 1, last, (isSuccess) => {
if (! isSuccess) {
trans.abort();
}
else {
fnUpdateRecord(bufStore, top, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT, (isSuccess) => {
if (! isSuccess) {
trans.abort();
}
});
}
});
}
else {
fnUpdateRecord(bufStore, top, last, (isSuccess) => {
if (! isSuccess) {
trans.abort();
}
});
}
}
}
};
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - updateEmptyGlobalIpAsync() ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
});
}
static updateBlockedUrlInfoAsync(tabId, time, url) {
return new Promise((resolve) => {
if ((typeof tabId !== 'number') ||
(typeof time !== 'number') ||
(typeof url !== 'string')) {
const errorMsg = '≪AccessUrlInfoBuffer≫ ERROR - updateBlockedUrlInfoAsync() Invalid parameter.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
return;
}
AccessUrlInfoBuffer._sha256Async(`${tabId}@${url}`)
.then((accessHash) => {
AccessUrlInfoBuffer._openDbAsync()
.then((db) => {
let isUpdated = false;
const trans = db.transaction(['buf'], 'readwrite');
trans.onerror = (ev) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - updateBlockedUrlInfoAsync() : Failed to update info. ${ev?.target?.error?.message || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
};
trans.onabort = () => resolve(false);
trans.oncomplete = () => resolve(isUpdated);
const bufStore = trans.objectStore('buf');
let getReq = bufStore.get(0);
getReq.onsuccess = (ev) => {
if (ev.target.result) {
if ((typeof ev.target.result.infoCount !== 'number') ||
(typeof ev.target.result.lastInfoId !== 'number') ||
(ev.target.result.infoCount > AccessUrlInfoBuffer.MAX_URL_INFO_COUNT)) {
const errorMsg = '≪AccessUrlInfoBuffer≫ updateBlockedUrlInfoAsync() : Broken indexDB.';
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
return trans.abort();
}
const infoCount = Math.min(ev.target.result.infoCount, AccessUrlInfoBuffer.MAX_URL_INFO_COUNT);
if (infoCount > 0) {
const lastInfoId = ev.target.result.lastInfoId;
const topInfoId = (((lastInfoId - 1) - (infoCount - 1) + AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) % AccessUrlInfoBuffer.MAX_URL_INFO_COUNT) + 1;
const index = bufStore.index('idx');
const getAllReq = index.getAll([time, accessHash]);
getAllReq.onsuccess = (evAll) => {
const records = evAll.target.result;
if (records.length > 0) {
records.forEach(record => {
const tempId = record.id;
if ((topInfoId > lastInfoId) && (((tempId >= topInfoId) && (tempId <= AccessUrlInfoBuffer.MAX_URL_INFO_COUNT)) || ((tempId >= 1) && (tempId <= lastInfoId))) ||
((topInfoId <= lastInfoId) && (tempId >= topInfoId) && (tempId <= lastInfoId))) {
if (record.blocked !== true) {
record.blocked = true;
bufStore.put(record);
isUpdated = true;
}
}
});
}
};
}
}
};
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - updateBlockedUrlInfoAsync() (DB) ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
})
.catch((err) => {
const errorMsg = `≪AccessUrlInfoBuffer≫ ERROR - updateBlockedUrlInfoAsync() (Hash) : ${err?.message || err || ''}`;
LogManager.putLogAsync(errorMsg, LogLevels.INFO).then(() => {});
resolve(false);
});
});
}
static _xor(s, id) {
const k = Math.floor(Math.abs(id)) % 256;
return s.split('').map(c => String.fromCharCode(c.charCodeAt(0) ^ k)).join('');
}
static _sha256Async(str) {
return new Promise((resolve) => {
const u8 = new TextEncoder().encode(Utils.truncateStr(str, 512, false));
crypto.subtle.digest('SHA-256', u8)
.then((buf) => {
const hashs = Array.from(new Uint8Array(buf));
resolve(hashs.map(b => b.toString(16).padStart(2, '0')).join(''));
})
.catch((err) => {
resolve(Utils.truncateStr(str, 64, false));
});
});
}
static _openDbAsync() {
if (this._dbPromise) {
return this._dbPromise;
}
this._dbPromise = new Promise((resolve, reject) => {
try {
const openReq = self.indexedDB.open('AccessUrl', 1);
openReq.onerror = (ev) => {
this._dbPromise = null;
reject(`Failed open AccessUrl DB. ${ev?.target?.error?.message || ''}`);
};
openReq.onupgradeneeded = (ev) => {
const db = ev.target.result;
if (ev.oldVersion < 1) {
const store = db.createObjectStore('buf', { keyPath: 'id' });
store.createIndex('idx', ['time', 'accessHash'], { unique: false });
}
};
openReq.onsuccess = (ev) => {
const db = ev.target.result;
db.onclose = () => {
this._dbPromise = null;
};
db.onversionchange = () => {
db.close();
this._dbPromise = null;
};
resolve(db);
};
}
catch (err) {
this._dbPromise = null;
reject(`Failed open AccessUrl DB. ${err?.message || err || ''}`);
}
});
return this._dbPromise;
}
}
class MyError extends Error {
constructor(message) {
super(message);
this.name = "MyError";
}
}
