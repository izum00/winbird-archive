'use strict';
const JSFILEVER_clientCoreClasses = '3.2.1.1001';
class ControllerInfo {
constructor(seqNo, mail, teacherName) {
this._seqNo = seqNo;
this._infoId = `${String(Math.trunc(seqNo % 100000000)).padStart(8, '0')}`;
this._mailAddress = mail;
this._teacherName = teacherName;
this._peerConnection = null;
this._lastCommunicationTime = Date.now();
this._signalingSendMessageQueue = [];
this._signalingLogBuffers = [];
this.isAbortedSignaling = false;
this.startClassEntryTime = '';
this.commProtocolMajorVersion = 0;
this.commProtocolMinorVersion = 0;
this.peerConnectionState = PeerStates.INITIAL;
this.peerBinTransferVersion = '';
this.peerSendBinChannel = null;
this.peerReceiveBinChannel = null;
this.peerSendChannel = null;
this.peerReceiveChannel = null;
this.isOpenedSendChannel = false;
this.isOpenedReceiveChannel = false;
this.isAlreadyJoinAnswered = false;
this.isSentFirstClientState = false;
this.isChangedJunshiRequirements = false;
this.isFirebaseJunshi = false;
this.firebaseJunshiQuality = 0.75;
this.firstGamenJunshiType = '';
this.firebaseJunshiRequestTimerId = TIMER_ID_NONE;
this.isActivedMessenger = false;
this.isSimplexMessenger = false;
this.isWatchActiveTab = false;
this.watchActiveTabTimerId = TIMER_ID_NONE;
this.isWatchDesktopGamen = false;
this.watchDesktopGamenTimerId = TIMER_ID_NONE;
this.activeTabJunshiRealWidth = 0;
this.activeTabJunshiRealAspectRatio = 1.0;
this.activeTabJunshiCanvas = null;
this.activeTabJunshiCanvasAspectRatio = 1.0;
this.activeTabJunshiStream = null;
this.desktopJunshiStream = null;
this.desktopJunshiCanvas = null;
this.gamenTeijiStream = null;
this.gamenJunshiType = 'none';
this.gamenJunshiFrameRate = 0;
this.gamenJunshiWidth = 0;
this.snapshotQuality = 0;
this.snapshotRequestedTime = 0;
this.snapshotWriteWaitingImage = null;
this.isSnapshotWriteWaiting = false;
this.appliedActiveTabJunshiWidth = 0;
this.appliedActiveTabJunshiAspectRatio = 0;
this.appliedDesktopJunshiWidth = 0;
this.appliedDesktopJunshiAspectRatio = 0;
this.appliedMaxPeerVideoFrameRate = 0;
this.lastJunshiTime = new Date(0);
this.lastJunshiWidthReductionRate = 0;
this.lastFirebaseJunshiWidth = -1;
this.lastFirebaseJunshiQuality = 1;
this.lastFirebaseJunshiImageWidth = -1;
this.lastFirebaseJunshiImageHeight = -1;
this.lastFirebaseJunshiImageCheckSums = [];
this.isBusyJunshi = false;
this.isJunshiCaptured = false;
this.isRejectedGamenTeiji = false;
this.signalingSendIceQueuingTimerId = TIMER_ID_NONE;
this.signalingSendIceQueue = null;
this.collabMateHostId = null;
this.collabMateRoomId = null;
this.collabMateRtdbName = null;
this.collabMateClientId = null;
this.collabMateCaptureState = CollabMateCaptureStates.NONE;
this.collabMateCapturedCanvas = null;
this.isAcceptedCollabMate1stRequest = false;
}
get infoId() {
return this._infoId;
}
get mailAddress() {
return this._mailAddress;
}
get teacherName() {
return this._teacherName;
}
get peerConnection() {
return this._peerConnection;
}
get elapsedLastCommunication() {
const elapsed = Date.now() - this._lastCommunicationTime;
return elapsed;
}
compareProtocolVersion(majorVer, minorVer) {
if (this.commProtocolMajorVersion === majorVer) {
if (this.commProtocolMinorVersion === minorVer) {
return 0;
}
return (this.commProtocolMinorVersion < minorVer) ? -1 : 1;
}
return (this.commProtocolMajorVersion < majorVer) ? -1 : 1;
}
compareCollabMateRoomInfo(hostId, roomId, clientId=null) {
if ((this.collabMateHostId === hostId) &&
(this.collabMateRoomId === roomId) &&
((clientId === null) || (this.collabMateClientId === clientId))) {
return true;
}
return false;
}
enqueueSignalingSendMessage(message) {
this._signalingSendMessageQueue.push(message);
return this._signalingSendMessageQueue.length;
}
dequeueSignalingSendMessage() {
if (this._signalingSendMessageQueue.length > 0) {
return this._signalingSendMessageQueue.shift();
}
return null;
}
clearSignalingSendMessageQueue() {
this._signalingSendMessageQueue.length = 0;
}
addSignalingLog(kind, msg) {
const logData = {
time: new Date(),
kind: kind,
msg: Utils.truncateStr(msg, 5000)
};
this._signalingLogBuffers.push(logData);
}
clearSignalingLog() {
this._signalingLogBuffers.length = 0;
}
getSignalingLogs() {
let logs = [];
this._signalingLogBuffers.forEach((data) => {
const log = `${Utils.getJstDateTimeStr(true, data.time).slice(11)} シグナリング( ${this._mailAddress} )${data.kind}  ${data.msg}`;
logs.push(log);
});
return logs;
}
isGamenStreamTransfer() {
return (! this.isFirebaseJunshi) && (this.peerBinTransferVersion === '');
}
isGamenBinaryTransfer() {
return (! this.isFirebaseJunshi) && (this.peerBinTransferVersion !== '');
}
createPeerConnection(config, receivedPeerGamenCallback, receivedPeerMessageCallback, changedChannelStateCallback) {
try {
this._peerConnection = new window.RTCPeerConnection(config);
const dataChannelOptions = {
ordered: true,
maxPacketLifeTime: 3000,
};
this.peerSendChannel = this._peerConnection.createDataChannel('sendDataChannel', dataChannelOptions);
this.peerSendChannel.onopen = () => {
changedChannelStateCallback(this._mailAddress, 'sendMsg', this.peerSendChannel?.readyState);
}
this.peerSendChannel.onclose = () => {
changedChannelStateCallback(this._mailAddress, 'sendMsg', (this.peerSendChannel?.readyState || 'closed'));
}
this._peerConnection.ondatachannel = (ev) => {
if (ev.channel.label === 'sendBinChannel') {
this.peerReceiveBinChannel = ev.channel;
this.peerReceiveBinChannel.onmessage = (ev) => {
receivedPeerGamenCallback(this._mailAddress, ev.data);
};
this.peerReceiveBinChannel.onopen = () => {
changedChannelStateCallback(this._mailAddress, 'receiveBin', this.peerReceiveBinChannel?.readyState);
};
this.peerReceiveBinChannel.onclose = () => {
changedChannelStateCallback(this._mailAddress, 'receiveBin', (this.peerReceiveBinChannel?.readyState || 'closed'));
};
}
else if (ev.channel.label === 'sendDataChannel') {
this.peerReceiveChannel = ev.channel;
this.peerReceiveChannel.onmessage = (ev) => {
receivedPeerMessageCallback(this._mailAddress, ev.data);
};
this.peerReceiveChannel.onopen = () => {
changedChannelStateCallback(this._mailAddress, 'receiveMsg', this.peerReceiveChannel?.readyState);
};
this.peerReceiveChannel.onclose = () => {
changedChannelStateCallback(this._mailAddress, 'receiveMsg', (this.peerReceiveChannel?.readyState || 'closed'));
};
}
}
}
catch (err) {
this._peerConnection = null;
this.peerSendBinChannel = null;
this.peerReceiveBinChannel = null;
this.peerSendChannel = null;
this.peerReceiveChannel = null;
this.isOpenedSendChannel = false;
this.isOpenedReceiveChannel = false;
}
return this._peerConnection;
}
createPeerBinChannel(changedChannelStateCallback) {
try {
const dataChannelOptions = {
ordered: true,
maxRetransmits: 5,
};
this.peerSendBinChannel = this._peerConnection.createDataChannel('sendBinChannel', dataChannelOptions);
this.peerSendBinChannel.binaryType = 'arraybuffer';
this.peerSendBinChannel.onopen = () => {
changedChannelStateCallback(this._mailAddress, 'sendBin', this.peerSendBinChannel?.readyState);
}
this.peerSendBinChannel.onclose = () => {
changedChannelStateCallback(this._mailAddress, 'sendBin', (this.peerSendBinChannel?.readyState || 'closed'));
}
}
catch (err) {
this.peerSendBinChannel = null;
}
}
sendMessage(message, logMessageString=null) {
Utils.assert(((typeof message === 'object') || (typeof message === 'string')), 'Implementation Error.');
let result = false;
const messageString = (typeof message === 'object') ? JSON.stringify(message) : message;
const logSendData = logMessageString || messageString;
if ((this.isOpenedSendChannel) && (this.peerSendChannel?.readyState === 'open')) {
try {
this.peerSendChannel.send(messageString);
this.refreshLastCommunicationTime();
result = true;
LogManager.putLog(`コントローラ( ${this._mailAddress} )にP2Pメッセージを送信...  MSG: ${logSendData}`, LogLevels.INFO);
}
catch (err) {
LogManager.putLog(`ERROR - コントローラ( ${this._mailAddress} )へのP2Pメッセージ送信失敗...  MSG: ${logSendData}`, LogLevels.INFO);
}
}
else {
LogManager.putLog(`ERROR - コントローラ( ${this._mailAddress} )へのP2Pメッセージ送信失敗.. Closed sendChannel.  MSG: ${logSendData}`, LogLevels.INFO);
}
return result;
}
refreshLastCommunicationTime() {
this._lastCommunicationTime = Date.now();
}
reset(clientTimer, connectionState=PeerStates.INITIAL) {
if (this.peerReceiveChannel) {
try {
this.peerReceiveChannel.onopen = () => {};
this.peerReceiveChannel.onclose = () => {};
if (this.peerReceiveChannel?.readyState !== 'closed') {
this.peerReceiveChannel.close();
}
}
catch (err) {}
this.peerReceiveChannel = null;
}
this.isOpenedReceiveChannel = false;
if (this.peerSendChannel) {
try {
this.peerSendChannel.onopen = () => {};
this.peerSendChannel.onclose = () => {};
if (this.peerSendChannel?.readyState !== 'closed') {
this.peerSendChannel.close();
}
}
catch (err) {}
this.peerSendChannel = null;
}
this.isOpenedSendChannel = false;
if (this._peerConnection) {
try {
this._peerConnection.close();
}
catch (err) {}
this._peerConnection = null;
}
this.peerBinTransferVersion = '';
this.commProtocolMajorVersion = 0;
this.commProtocolMinorVersion = 0;
this.peerConnectionState = connectionState;
this._lastCommunicationTime = Date.now();
this.isAlreadyJoinAnswered = false;
this.isSentFirstClientState = false;
this.isChangedJunshiRequirements = false;
this.isFirebaseJunshi = false;
this.firebaseJunshiQuality = 0.75;
this.firstGamenJunshiType = '';
if (this.firebaseJunshiRequestTimerId !== TIMER_ID_NONE) {
if (clientTimer)  clientTimer.removeTimer(this.firebaseJunshiRequestTimerId);
this.firebaseJunshiRequestTimerId = TIMER_ID_NONE;
}
this.isActivedMessenger = false;
this.isSimplexMessenger = false;
if (this.isWatchActiveTab) {
if (this.watchActiveTabTimerId !== TIMER_ID_NONE) {
if (clientTimer)  clientTimer.removeTimer(this.watchActiveTabTimerId);
this.watchActiveTabTimerId = TIMER_ID_NONE;
}
this.isWatchActiveTab = false;
}
if (this.isWatchDesktopGamen) {
if (this.watchDesktopGamenTimerId !== TIMER_ID_NONE) {
if (clientTimer)  clientTimer.removeTimer(this.watchDesktopGamenTimerId);
this.watchDesktopGamenTimerId = TIMER_ID_NONE;
}
this.isWatchDesktopGamen = false;
}
this.activeTabJunshiRealWidth = 0;
this.activeTabJunshiRealAspectRatio = 1.0;
this.activeTabJunshiCanvas = null;
this.activeTabJunshiCanvasAspectRatio = 1.0;
this.activeTabJunshiStream = null;
this.desktopJunshiStream = null;
this.desktopJunshiCanvas = null;
this.gamenTeijiStream = null;
this.gamenJunshiType = 'none';
this.gamenJunshiFrameRate = 0;
this.gamenJunshiWidth = 0;
this.snapshotQuality = 0;
this.snapshotRequestedTime = 0;
this.snapshotWriteWaitingImage = null;
this.isSnapshotWriteWaiting = false;
this.appliedActiveTabJunshiWidth = 0;
this.appliedActiveTabJunshiAspectRatio = 0;
this.appliedDesktopJunshiWidth = 0;
this.appliedDesktopJunshiAspectRatio = 0;
this.appliedMaxPeerVideoFrameRate = 0;
this.lastJunshiTime = new Date(0);
this.lastJunshiWidthReductionRate = 0;
this.lastFirebaseJunshiWidth = -1;
this.lastFirebaseJunshiQuality = 1;
this.lastFirebaseJunshiImageWidth = -1;
this.lastFirebaseJunshiImageHeight = -1;
this.lastFirebaseJunshiImageCheckSums.length = 0;
this.isBusyJunshi = false;
this.isJunshiCaptured = false;
this.isRejectedGamenTeiji = false;
if (this.signalingSendIceQueuingTimerId !== TIMER_ID_NONE) {
if (clientTimer)  clientTimer.removeTimer(this.signalingSendIceQueuingTimerId);
this.signalingSendIceQueuingTimerId = TIMER_ID_NONE;
}
this.signalingSendIceQueue = null;
this.clearSignalingSendMessageQueue();
this.clearSignalingLog();
this.collabMateHostId = null;
this.collabMateRoomId = null;
this.collabMateRtdbName = null;
this.collabMateClientId = null;
this.collabMateCaptureState = CollabMateCaptureStates.NONE;
this.collabMateCapturedCanvas = null;
this.isAcceptedCollabMate1stRequest = false;
}
}
class PageScreenInfo extends ClientScreenInfo {
constructor(id, displayId, isPrimary, screenBounds, workAreaBounds, isDuplicate) {
super(displayId, isPrimary, screenBounds, workAreaBounds);
this.currentPageKey = '';
this.currentPageWindowId = WINDOW_ID_NONE;
this.currentPageTabId = TAB_ID_NONE;
this.currentWindowState = '';
this._id = id;
this._isDuplicate = isDuplicate;
this._openRequestTimeout = -1;
}
get id() {
return this._id;
}
get isDuplicate() {
return this._isDuplicate;
}
get openRequestTimeout() {
return this._openRequestTimeout;
}
set openRequestTimeout(value) {
this._openRequestTimeout = value;
}
}
class ClientTimer {
constructor() {
this._isEnabled = false;
this._timers = [];
this._lastAssignedId = 0;
this._insuranceTimerId = -1;
this._start = this._start.bind(this);
this._stop = this._stop.bind(this);
this._onAlarm = this._onAlarm.bind(this);
this.addTimer = this.addTimer.bind(this);
this.removeTimer = this.removeTimer.bind(this);
this.count = this.count.bind(this);
}
_start() {
if ((! this._isEnabled) && (this._timers.length > 0)) {
chrome.alarms.onAlarm.addListener(this._onAlarm);
chrome.alarms.create('ClientCoreAlarm', { when: (Date.now() + 125) });
this._insuranceTimerId = setTimeout(this._onAlarm, 900, { name: 'ClientCoreTimer' });
this._isEnabled = true;
}
}
_stop() {
if (this._isEnabled) {
chrome.alarms.onAlarm.removeListener(this._onAlarm);
chrome.alarms.clear('ClientCoreAlarm').then(()=>{});
if (this._insuranceTimerId !== -1) {
clearTimeout(this._insuranceTimerId);
this._insuranceTimerId = -1;
}
this._isEnabled = false;
}
}
_onAlarm(alarm) {
const fnCallTargetFunction = (func, args) => {
try {
switch (args.length) {
case 0:
func();
break;
case 1:
func(args[0]);
break;
case 2:
func(args[0], args[1]);
break;
case 3:
func(args[0], args[1], args[2]);
break;
case 4:
func(args[0], args[1], args[2], args[3]);
break;
default:
func(args[0], args[1], args[2], args[3], args[4]);
break;
}
}
catch (err) {
console.log(`ERROR - ClientTimer called function: ${err}`);
}
};
if ((alarm.name === 'ClientCoreAlarm') || (alarm.name === 'ClientCoreTimer')) {
this._stop();
const now = performance.now();
for (let i = this._timers.length - 1; i >= 0; i--) {
const target = this._timers[i];
const isBackTime = ((now - target.baseTime) < -5000);
if ((target.raise !== 0) && ((now >= target.raise) || (isBackTime))) {
if (isBackTime) {
LogManager.putLog('タイマー処理中に時計の巻き戻り検出. 待機中のタイマー処理関数を発火します.', LogLevels.INFO);
}
target.raise = 0;
if (target.repeat === 0) {
this._timers.splice(i, 1);
setTimeout((func, args) => { fnCallTargetFunction(func, args); }, 0, target.func, target.args);
}
else {
let nextRaise = now + target.repeat;
fnCallTargetFunction(target.func, target.args);
target.baseTime = performance.now();
target.raise = Math.max(nextRaise, (target.baseTime + 100));
}
}
}
this._start();
}
}
addTimer(msec, isRepeat, func, ...args) {
const fnNewId = () => {
this._lastAssignedId++;
if (this._lastAssignedId >= 10000) {
this._lastAssignedId = 1;
}
return this._lastAssignedId;
};
let timerId = fnNewId();
while(this._timers.some(data => data.id === timerId)) {
timerId = fnNewId();
}
const now = performance.now();
const data = {
id: timerId,
baseTime: now,
raise: now + msec,
repeat: (isRepeat) ? msec : 0,
func: func,
args: args
};
if (1 === this._timers.unshift(data)) {
this._start();
}
return timerId;
}
removeTimer(id) {
const hitIndex = this._timers.findIndex(data => data.id === id);
if (hitIndex !== -1) {
this._timers.splice(hitIndex, 1);
if (this._timers.length === 0) {
this._stop();
}
return true;
}
return false;
}
advanceTimer(id) {
const hitIndex = this._timers.findIndex(data => data.id === id);
if (hitIndex !== -1) {
this._timers[hitIndex].raise = 1;
return true;
}
return false;
}
count() {
return this._timers.length;
}
}
class NightLimitInfo {
constructor(sourceYMD, setting) {
this._sourceYMD = sourceYMD;
this._isEnabled = false;
this._beginningTimeSeconds = 0;
this._endingTimeSeconds = 0;
this._isPriorNotice = false;
this._priorNoticePeriod = 0;
this._priorNoticeTimeSeconds = 0;
this._priorNoticeMessage = 'まもなく利用禁止時間です。作業を終了してください。';
this._isWarningNotice = false;
this._warningNoticeMessage = '夜のパソコン利用は禁止です。';
this._warningNoticeInterval = 15 * 60;
this._isBrowserSeigen = false;
this._whiteList = [];
this._lastWarningNoticeTimeSeconds = 0;
if (typeof setting?.enabled === 'boolean')  this._isEnabled = setting.enabled;
if (typeof setting?.beginningTime === 'string')  this._beginningTimeSeconds = this._convertHHMMtoSeconds(setting.beginningTime);
if (typeof setting?.endingTime === 'string')  this._endingTimeSeconds = this._convertHHMMtoSeconds(setting.endingTime);
if (typeof setting?.priorNotice === 'boolean')  this._isPriorNotice = setting.priorNotice;
if (typeof setting?.priorNoticePeriod === 'number')  this._priorNoticePeriod = setting.priorNoticePeriod;
if (typeof setting?.priorNoticeMessage === 'string')  this._priorNoticeMessage = setting.priorNoticeMessage;
if (typeof setting?.warningNotice === 'boolean')  this._isWarningNotice = setting.warningNotice;
if (typeof setting?.warningNoticeMessage === 'string')  this._warningNoticeMessage = setting.warningNoticeMessage;
if (typeof setting?.warningNoticeInterval === 'number')  this._warningNoticeInterval = setting.warningNoticeInterval * 60;
if (typeof setting?.browserSeigen === 'boolean')  this._isBrowserSeigen = setting.browserSeigen;
if (('whiteList' in setting) && Array.isArray(setting.whiteList))  Array.prototype.push.apply(this._whiteList, setting.whiteList);
this._priorNoticeTimeSeconds = ((this._beginningTimeSeconds + ((24 * 60 - this._priorNoticePeriod) * 60)) % (24 * 60 * 60));
}
get sourceYMD() {
return this._sourceYMD;
}
get isEnabled() {
return this._isEnabled;
}
get beginningTimeSeconds() {
return this._beginningTimeSeconds;
}
get endingTimeSeconds() {
return this._endingTimeSeconds;
}
get isPriorNotice() {
return this._isPriorNotice;
}
get priorNoticePeriod() {
return this._priorNoticePeriod;
}
get priorNoticeTimeSeconds() {
return this._priorNoticeTimeSeconds;
}
get priorNoticeMessage() {
return this._priorNoticeMessage;
}
get isWarningNotice() {
return this._isWarningNotice;
}
get warningNoticeMessage() {
return this._warningNoticeMessage;
}
get warningNoticeInterval() {
return this._warningNoticeInterval;
}
get isBrowserSeigen() {
return this._isBrowserSeigen;
}
get whiteList() {
return this._whiteList;
}
get lastWarningNoticeTimeSeconds() {
return this._lastWarningNoticeTimeSeconds;
}
set lastWarningNoticeTimeSeconds(value) {
this._lastWarningNoticeTimeSeconds = value;
}
_convertHHMMtoSeconds(hhmm) {
if ((typeof hhmm === 'string') && (hhmm.match(/^([01]?[0-9]|2[0-3])([0-5][0-9])$/))) {
const hours = parseInt(hhmm.substring(0, 2), 10);
const minutes = parseInt(hhmm.substring(2, 4), 10);
return ((hours * 60) + minutes) * 60;
}
return 0;
}
_convertSecondsToHHMM(timeSeconds) {
const hours = Math.trunc(timeSeconds / (60 * 60));
const minutes = Math.trunc((timeSeconds - (hours * 60 * 60)) / 60);
return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}
makeSettingLog() {
let logs = [];
logs.push(`夜間利用制限ポリシー適用日: ${this._sourceYMD}分`);
if (this._isEnabled) {
logs.push('夜間利用制限を行うかどうか: する');
logs.push(`夜間利用制限の開始時刻: ${this._convertSecondsToHHMM(this._beginningTimeSeconds)}`);
logs.push(`夜間利用制限の終了時刻: ${this._convertSecondsToHHMM(this._endingTimeSeconds)}`);
logs.push(`夜間利用制限の開始前に事前表示を行うかどうか: ${this._isPriorNotice ? 'する' :'しない'}`);
logs.push(`事前表示を何分前から行うか: ${this._priorNoticePeriod}分前`);
logs.push(`事前表示のメッセージ: ${this._priorNoticeMessage}`);
logs.push(`夜間利用制限中に警告表示メッセージを出力するかどうか: ${this._isWarningNotice ? 'する' :'しない'}`);
logs.push(`警告表示メッセージ: ${this._warningNoticeMessage}`);
logs.push(`警告を表示する間隔: ${Math.trunc(this._warningNoticeInterval / 60)}分`);
logs.push(`夜間利用制限中にブラウザ制限を行うかどうか: ${this._isBrowserSeigen ? 'する' :'しない'}`);
logs.push(`夜間ブラウザ制限のホワイトリスト: ${this._whiteList.length} 件`);
this._whiteList.forEach((url) => {
logs.push(`  ${url}`);
});
}
else {
logs.push('夜間利用制限を行うかどうか: しない');
}
return logs;
}
}
class AntiCheatInfo {
constructor(settings) {
this._gamenJunshiType = 'tab';
if ((settings.gamenJunshiType === 'screen') || (settings.gamenJunshiType === 'screen2')) {
this._gamenJunshiType = settings.gamenJunshiType;
}
this._isBrowserMax = !!(settings.isBrowserMax);
this._isBrowserTop = !!(settings.isBrowserTop);
this._releaseMinutes = Math.max(0, settings.releaseMinutes);
this._whiteList = [];
if (settings.whiteList?.length) {
this._whiteList = settings.whiteList.sort();
}
this._startUTCTime;
if ('startUTCTime' in settings) {
this._startUTCTime = settings.startUTCTime;
}
else {
this._startUTCTime = Date.now();
}
this._forcedReleaseUTCTime = 8640000000000000;
if (this._releaseMinutes > 0) {
this._forcedReleaseUTCTime = (Math.round(this._startUTCTime / 1000) * 1000) + (this._releaseMinutes * 60000);
}
};
get isFirstDefaultJunshi() {
return (this._gamenJunshiType === 'tab');
}
get isFirstDesktopJunshi() {
return ((this._gamenJunshiType === 'screen') || (this._gamenJunshiType === 'screen2'));
}
get isAlwaysDesktopJunshi() {
return (this._gamenJunshiType === 'screen2');
}
get isBrowserMax() {
return this._isBrowserMax;
}
get isBrowserTop() {
return this._isBrowserMax && this._isBrowserTop;
}
get releaseMinutes() {
return this._releaseMinutes;
}
get whiteList() {
return this._whiteList.slice();
}
get startUTCTime() {
return this._startUTCTime;
}
get forcedReleaseUTCTime() {
return this._forcedReleaseUTCTime;
}
toString(isSettingsOnly=false) {
const tempSettings = {
gamenJunshiType: this._gamenJunshiType,
isBrowserMax: this._isBrowserMax,
isBrowserTop: this._isBrowserTop,
releaseMinutes: this._releaseMinutes,
whiteList: this._whiteList,
};
if (! isSettingsOnly) {
tempSettings.startUTCTime = this._startUTCTime;
}
return JSON.stringify(tempSettings);
}
makeSettingLog() {
const logs = [];
let junshiType = '？';
if (this._gamenJunshiType === 'tab') {
junshiType = 'アクティブタブ';
}
else if (this._gamenJunshiType === 'screen') {
junshiType = 'デスクトップ画面';
}
else if (this._gamenJunshiType === 'screen2') {
junshiType = 'デスクトップ画面の強制';
}
logs.push(`巡視方式: ${junshiType}`);
logs.push(`ブラウザ画面の最大化: ${this._isBrowserMax ? 'する' : 'しない'}`);
if (this._isBrowserMax) {
logs.push(`ブラウザ画面の最前面化: ${this._isBrowserTop ? 'する' : 'しない'}`);
}
logs.push(`強制解除: ${(this._releaseMinutes > 0) ? `${this._releaseMinutes} 分` : 'なし'}`);
logs.push(`ブラウザ制限のホワイトリスト: ${this._whiteList.length} 件`);
this._whiteList.forEach((url) => {
logs.push(`  ${url}`);
});
logs.push(' ');
logs.push(`開始時刻(JST): ${Utils.getJstDateTimeStr(true, new Date(this.startUTCTime)).slice(0, 19)}`);
if (this._releaseMinutes > 0) {
logs.push(`強制解除時刻(JST): ${Utils.getJstDateTimeStr(true, new Date(this.forcedReleaseUTCTime)).slice(0, 19)}`);
}
return logs;
}
}
class WhiteListChecker {
constructor() {
this._httpWhiteList = [];
this._httpsWhiteList = [];
this._chromeWhiteList = [];
this._isAsciiDomainOnly = true;
}
addWhiteList(urls) {
let result = false;
try {
if (!Array.isArray(urls)) {
throw new Error('追加するURLが配列でない');
}
let isAsciiDomainOnly = true;
let tempHttpList = [];
let tempHttpsList = [];
let tempChromeList = [];
for (let i = 0; i < urls.length; i++) {
const url = urls[i];
if (typeof url !== 'string') {
throw new Error(`URLが文字列でない (index:${i})`);
}
const urlParts = Utils.classifyUrl(url, true);
if (! urlParts) {
throw new Error(`URL構造が異常 (index:${i})`);
}
let targetList;
if (urlParts[0] === 'http://') {
targetList = tempHttpList;
}
else if (urlParts[0] === 'https://') {
targetList = tempHttpsList;
}
else if (urlParts[0] === 'chrome://') {
if (urlParts[1].startsWith('*.'))  throw new Error(`不正なワイルドカード (index:${i})`);
targetList = tempChromeList;
}
else {
throw new Error(`URLスキームが異常 (index:${i})`);
}
if (! urlParts[2].endsWith('/')) {
urlParts[2] += '/';
}
const isWildCard = urlParts[1].startsWith('*.');
const hostDomain = urlParts[1].substring(isWildCard ? 2 : 0);
const isAsciiDomain = (null === hostDomain.match(/[^\x01-\x7E]/));
isAsciiDomainOnly = isAsciiDomainOnly && isAsciiDomain;
targetList.push({
isWildCard: isWildCard,
hostDomain: hostDomain,
isAsciiDomain: isAsciiDomain,
followingPath: urlParts[2]
});
}
if (tempHttpList.length > 0) {
Array.prototype.push.apply(this._httpWhiteList, tempHttpList);
}
if (tempHttpsList.length > 0) {
Array.prototype.push.apply(this._httpsWhiteList, tempHttpsList);
}
if (tempChromeList.length > 0) {
Array.prototype.push.apply(this._chromeWhiteList, tempChromeList);
}
this._isAsciiDomainOnly = this._isAsciiDomainOnly && isAsciiDomainOnly;
result = true;
}
catch (err) {
const errorMsg = `ERROR - ホワイトリストの登録失敗` + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
return result;
}
check(targetUrl) {
let result = false;
try {
const targetUrlParts = Utils.classifyUrl(targetUrl, true);
if (targetUrlParts) {
let targetHostDomain = targetUrlParts[1];
let targetDecodedPunycodeDomain = null;
if ((! this._isAsciiDomainOnly) && (targetHostDomain.includes('xn--'))) {
targetDecodedPunycodeDomain = PunycodeDecoder.decode(targetHostDomain);
}
let targetFollowingPath = targetUrlParts[2];
if (! targetFollowingPath.endsWith('/')) {
targetFollowingPath += '/';
}
let targetDecodedFollowingPath = decodeURI(targetFollowingPath);
if (targetDecodedFollowingPath === targetFollowingPath) {
targetDecodedFollowingPath = null;
}
let whiteList = [];
if (targetUrlParts[0] === 'http://') {
whiteList = this._httpWhiteList;
}
else if (targetUrlParts[0] === 'https://') {
whiteList = this._httpsWhiteList;
}
else if (targetUrlParts[0] === 'chrome://') {
whiteList = this._chromeWhiteList;
}
for (let tempInfo of whiteList) {
let isMatchHostDomain = false;
if (tempInfo.hostDomain === targetHostDomain) {
isMatchHostDomain = true;
}
else if ((! tempInfo.isAsciiDomain) && (targetDecodedPunycodeDomain) &&
(tempInfo.hostDomain === targetDecodedPunycodeDomain)) {
isMatchHostDomain = true;
}
else if (tempInfo.isWildCard) {
if (targetHostDomain.endsWith('.' + tempInfo.hostDomain)) {
isMatchHostDomain = true;
}
else if ((! tempInfo.isAsciiDomain) && (targetDecodedPunycodeDomain) &&
(targetDecodedPunycodeDomain.endsWith('.' + tempInfo.hostDomain))) {
isMatchHostDomain = true;
}
}
if (isMatchHostDomain) {
if (targetFollowingPath.startsWith(tempInfo.followingPath)) {
result = true;
break;
}
else if ((targetDecodedFollowingPath) &&
(targetDecodedFollowingPath.startsWith(tempInfo.followingPath))) {
result = true;
break;
}
}
}
}
}
catch (err) {
const errorMsg = `ERROR - ホワイトリストチェック失敗` + ((err) ? ` : ${err.message || err}` : '');
LogManager.putLog(errorMsg, LogLevels.INFO);
}
return result;
}
}
