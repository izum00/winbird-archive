'use strict';
const JSFILEVER_browserSeigenPage = '3.2.1.1001';
window.addEventListener('load', async () => {
const fnProcError = (errorMsg) => {
LogManager.putLogAsync(errorMsg, LogLevels.INFO)
.finally(() => {
window.close();
});
};
const fnCheckProgramFileVersionAsync = () => {
return new Promise((resolve) => {
let logLevel = LogLevels.INFO;
let logMsg = '';
try {
let currentVersion = '';
const manifestData = chrome.runtime.getManifest();
if (manifestData.version) currentVersion = manifestData.version;
let verBrowserSeigenPage = (typeof JSFILEVER_browserSeigenPage === 'string') ? JSFILEVER_browserSeigenPage : 'Undefined';
if (verBrowserSeigenPage === currentVersion) {
logMsg = `★Program file check <6> -- cleared.  [currentVer=${currentVersion}]`;
}
else {
logLevel = LogLevels.FATAL;
logMsg = `★★Program file not match <6> -- [currentVer=${currentVersion}]  browserSeigenPage.js=${verBrowserSeigenPage}`;
}
}
catch (err) {
logMsg = 'ERROR - fnCheckProgramFileVersionAsync()' + ((err) ? ` : ${err.message || err}` : '');
}
LogManager.putLogAsync(`【browserSeigenPage】${logMsg}`, logLevel)
.finally(() => {
resolve();
});
});
};
try {
let selfPageKey = '';
const tempIndex = document.location.href.indexOf('?');
if (tempIndex > 0) {
const urlArgs = document.location.href.substring(tempIndex + 1).split('&');
urlArgs.forEach((arg) => {
if (arg.startsWith('key=')) {
selfPageKey = arg.substring(4);
}
});
}
if (! selfPageKey) {
throw new Error('Invalid url parameter.');
}
const clientCoreTabId = await ApiWrappers.readSessionStorageValueAsync({ ClientCoreTabId: TAB_ID_NONE }, true);
let currentWindow = await ApiWrappers.getCurrentWindowAsync({ populate: true }, true);
const selfWindowId = currentWindow.id;
let selfTabId = TAB_ID_NONE;
if (currentWindow.tabs) {
for (const tab of currentWindow.tabs) {
if (tab.url === document.location.href) {
selfTabId = tab.id;
break;
}
}
}
ApiWrappers.sendInternalMsgAsync(false, clientCoreTabId, {
cmd: 'ShownBrowserSeigenPage',
pageKey: selfPageKey,
windowId: selfWindowId,
tabId: selfTabId
})
.then((msgResponse) => {
if ((typeof msgResponse !== 'object') || (msgResponse?.accepted !== true)) {
LogManager.putLogAsync('【browserSeigenPage】Rejected ShownBrowserSeigenPage.', LogLevels.INFO)
.then(() => {
return ApiWrappers.updateWindowAsync(selfWindowId, {
state: 'normal',
focused: true
});
})
.finally(() => {
window.close();
});
return;
}
document.title = Utils.getLocaleMessage('title_limitedBrowsing');
document.getElementById('labelMessage').innerHTML = Utils.getLocaleMessage('msg_limitedBrowsing');
ApiWrappers.readLocalStorageValueAsync({ ProgramVersionCheckedFlags: 0 })
.then((programVersionCheckedFlags) => {
if (programVersionCheckedFlags === null)  programVersionCheckedFlags = 0;
if (0 === (programVersionCheckedFlags & 0x20)) {
programVersionCheckedFlags = (programVersionCheckedFlags & ~0x20) | 0x20;
ApiWrappers.saveLocalStorageDataAsync({ ProgramVersionCheckedFlags: programVersionCheckedFlags }).then(() => {});
if (! Utils.isSkipCheckProgramFileVersion()) {
fnCheckProgramFileVersionAsync().then(() => {});
}
}
});
})
.catch((err) => {
const errorMsg = '【browserSeigenPage】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
fnProcError(errorMsg);
});
}
catch (err) {
const errorMsg = '【browserSeigenPage】ERROR - load()' + ((err) ? ` : ${err.message || err}` : '');
fnProcError(errorMsg);
}
});
window.addEventListener('error', (ev) => {
const errorMsg = '【browserSeigenPage】WINDOW ERROR (B.S.Page) - ' + ((ev) ? ` : ${ev.message || ev}` : '');
LogManager.putLogAsync(errorMsg, LogLevels.FATAL)
.finally(() => {
window.close();
});
});
